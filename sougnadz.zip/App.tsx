import React, { useEffect } from 'react';
import { createHashRouter, RouterProvider, Outlet, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import CategoryPage from './pages/CategoryPage';
import BlogPage from './pages/BlogPage';
import HelpPage from './pages/HelpPage';
import ProfilePage from './pages/ProfilePage';
import MyAdsPage from './pages/MyAdsPage';
import ListingDetailsPage from './pages/ListingDetailsPage';
import PostAdPage from './pages/PostAdPage';
import PostAdFormPage from './pages/PostAdFormPage';
import { useLocalization } from './hooks/useLocalization';
import FavoritesPage from './pages/FavoritesPage';
import { ReportAdProvider } from './hooks/useReportAd';
import ReportAdModal from './components/ReportAdModal';

// This component ensures that the page scrolls to the top on every navigation change.
const ScrollToTop = () => {
    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    return null;
};


// The main layout component that includes shared elements like Header and Footer.
const Layout: React.FC = () => {
    const { language } = useLocalization();

    useEffect(() => {
        document.documentElement.lang = language;
        document.documentElement.dir = 'ltr';
    }, [language]);

    return (
        <div className="min-h-screen flex flex-col bg-white dark:bg-[#070b18] font-sans">
            <ScrollToTop />
            <Header />
            <main className="flex-grow">
                <Outlet /> {/* Child routes will be rendered here */}
            </main>
            <Footer />
            <ReportAdModal />
        </div>
    );
};

// Define the application's routes using the modern react-router-dom API.
const router = createHashRouter([
    {
        path: '/',
        element: <Layout />,
        children: [
            { index: true, element: <HomePage /> },
            { path: 'category/:categorySlug', element: <CategoryPage /> },
            // FIX: The original code had a separate `/automobiles` route, which is now handled
            // by the dynamic `/category/:categorySlug` route. This was removed to prevent redundancy
            // and streamline the routing logic.
            { path: 'listing/:listingId', element: <ListingDetailsPage /> },
            { path: 'post-ad', element: <PostAdPage /> },
            { path: 'post-ad/:categorySlug', element: <PostAdFormPage /> },
            { path: 'blog', element: <BlogPage /> },
            { path: 'help', element: <HelpPage /> },
            { path: 'profile', element: <ProfilePage /> },
            { path: 'myAds', element: <MyAdsPage /> },
            { path: 'favorites', element: <FavoritesPage /> },
            // A simple catch-all to redirect to home for any unknown routes
            { path: '*', element: <HomePage /> }
        ]
    }
]);

// The root App component now provides the router and context providers.
const App: React.FC = () => (
    <ReportAdProvider>
        <RouterProvider router={router} />
    </ReportAdProvider>
);

export default App;
