

import React from 'react';
import { useLocalization } from '../hooks/useLocalization';
import NavbarLogo from './NavbarLogo';

interface AuthModalProps {
    isOpen: boolean;
    onClose: () => void;
    onLoginSuccess: () => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLoginSuccess }) => {
    const { t } = useLocalization();

    if (!isOpen) return null;

    const handleSocialLogin = () => {
        // Mocking successful login
        console.log("Simulating social login...");
        onLoginSuccess();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity duration-300" onClick={onClose}>
            <div
                className="bg-white dark:bg-[#0f1429] rounded-lg shadow-xl p-8 w-full max-w-md m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex flex-col items-center text-center">
                    <div className="mb-6">
                        <NavbarLogo className="text-5xl" />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white mt-6 mb-2">{t('login')}</h2>
                    <p className="text-gray-600 dark:text-gray-400 mb-8">Connectez-vous pour publier des annonces et gérer votre profil.</p>
                    
                    <div className="w-full space-y-4">
                        <button onClick={handleSocialLogin} className="w-full flex items-center justify-center gap-3 bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors">
                            {/* Google Icon SVG */}
                            <svg className="w-6 h-6" viewBox="0 0 24 24"><path fill="currentColor" d="M21.35,11.1H12.18V13.83H18.69C18.36,17.64 15.19,19.27 12.19,19.27C8.36,19.27 5,16.25 5,12C5,7.9 8.2,4.73 12.19,4.73C14.03,4.73 15.69,5.36 16.95,6.58L19.05,4.58C17.22,2.91 14.88,2 12.19,2C6.42,2 2.03,6.8 2.03,12C2.03,17.05 6.16,22 12.19,22C17.6,22 21.54,18.33 21.54,12.29C21.54,11.77 21.48,11.44 21.35,11.1Z"></path></svg>
                            {t('continueWithGoogle')}
                        </button>
                        
                        <button onClick={handleSocialLogin} className="w-full flex items-center justify-center gap-3 bg-blue-700 hover:bg-blue-800 text-white font-semibold py-3 px-4 rounded-lg transition-colors">
                            {/* Facebook Icon SVG */}
                            <svg className="w-6 h-6" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2.04C6.5 2.04 2 6.53 2 12.06C2 17.06 5.66 21.21 10.44 21.96V14.96H7.9V12.06H10.44V9.85C10.44 7.32 11.93 5.96 14.22 5.96C15.31 5.96 16.45 6.15 16.45 6.15V8.62H15.19C13.95 8.62 13.56 9.39 13.56 10.18V12.06H16.34L15.89 14.96H13.56V21.96A10 10 0 0 0 12 2.04Z"></path></svg>
                            {t('continueWithFacebook')}
                        </button>
                    </div>

                    <button onClick={onClose} className="absolute top-4 end-4 text-gray-400 dark:text-gray-500 hover:text-gray-800 dark:hover:text-white">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                {/* Fix: Replaced <style jsx> with <style> to fix TypeScript error regarding invalid 'jsx' prop. */}
                <style>{`
                    @keyframes modal-pop {
                        from { transform: scale(0.9); opacity: 0; }
                        to { transform: scale(1); opacity: 1; }
                    }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </div>
        </div>
    );
};

export default AuthModal;