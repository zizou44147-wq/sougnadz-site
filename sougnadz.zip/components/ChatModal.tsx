
import React, { useState, useEffect, useRef } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { User } from '../services/types';

interface ChatModalProps {
    isOpen: boolean;
    onClose: () => void;
    seller: User;
}

interface Message {
    id: number;
    text: string;
    sender: 'user' | 'seller';
    timestamp: string;
}

const ChatModal: React.FC<ChatModalProps> = ({ isOpen, onClose, seller }) => {
    const { t } = useLocalization();
    const [messages, setMessages] = useState<Message[]>([]);
    const [newMessage, setNewMessage] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen) {
            // Initial mock message from seller
            setMessages([
                { id: 1, text: `Bonjour ! Je suis ${seller.name}. Comment puis-je vous aider concernant cette annonce ?`, sender: 'seller', timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }
            ]);
        }
    }, [isOpen, seller.name]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim() === '') return;

        const userMessage: Message = {
            id: Date.now(),
            text: newMessage,
            sender: 'user',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };

        setMessages(prev => [...prev, userMessage]);
        setNewMessage('');

        // Simulate seller's auto-reply
        setTimeout(() => {
            const sellerReply: Message = {
                id: Date.now() + 1,
                text: "Merci pour votre message ! Je vous répondrai dès que possible.",
                sender: 'seller',
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };
            setMessages(prev => [...prev, sellerReply]);
        }, 1500);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity duration-300" onClick={onClose}>
            <div
                className="bg-white dark:bg-[#0f1429] rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative flex flex-col"
                style={{ height: '70vh', maxHeight: '600px' }}
                onClick={(e) => e.stopPropagation()}
            >
                {/* Header */}
                <div className="flex-shrink-0 p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                     <div className="flex items-center gap-3">
                        <img src={seller.avatarUrl} alt={seller.name} className="w-10 h-10 rounded-full" />
                        <div>
                            <h2 className="text-lg font-bold text-gray-900 dark:text-white">{t('chatModalTitle', { sellerName: seller.name })}</h2>
                            {seller.isOnline && <p className="text-xs text-green-500">{t('online')}</p>}
                        </div>
                    </div>
                    <button onClick={onClose} className="text-gray-400 dark:text-gray-500 hover:text-gray-800 dark:hover:text-white">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>

                {/* Messages Body */}
                <div className="flex-grow p-4 overflow-y-auto bg-gray-50 dark:bg-gray-900/50">
                    <div className="space-y-4">
                        {messages.map((msg) => (
                            <div key={msg.id} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                {msg.sender === 'seller' && <img src={seller.avatarUrl} alt={seller.name} className="w-6 h-6 rounded-full" />}
                                <div className={`max-w-xs md:max-w-md px-4 py-2 rounded-2xl ${msg.sender === 'user' ? 'bg-blue-600 text-white rounded-br-lg' : 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white rounded-bl-lg'}`}>
                                    <p className="text-sm">{msg.text}</p>
                                    <p className={`text-xs mt-1 opacity-70 ${msg.sender === 'user' ? 'text-blue-200' : 'text-gray-500 dark:text-gray-400'}`}>{msg.timestamp}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                    <div ref={messagesEndRef} />
                </div>

                {/* Input Form */}
                <div className="flex-shrink-0 p-4 border-t border-gray-200 dark:border-gray-700">
                    <form onSubmit={handleSendMessage} className="flex items-center gap-3">
                        <input
                            type="text"
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            placeholder={t('typeYourMessage')}
                            className="flex-grow bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-full shadow-sm py-2 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-bold p-3 rounded-full transition-colors flex-shrink-0">
                             <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 transform rotate-90" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
                        </button>
                    </form>
                </div>
                
                <style>{`
                    @keyframes modal-pop {
                        from { transform: scale(0.9); opacity: 0; }
                        to { transform: scale(1); opacity: 1; }
                    }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </div>
        </div>
    );
};

export default ChatModal;