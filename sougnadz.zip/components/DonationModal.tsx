

import React from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { Listing } from '../services/types';

interface DonationModalProps {
    isOpen: boolean;
    onClose: () => void;
    donationInfo: Listing['donationInfo'];
    listingTitle: string;
}

const DonationModal: React.FC<DonationModalProps> = ({ isOpen, onClose, donationInfo, listingTitle }) => {
    const { t } = useLocalization();

    if (!isOpen || !donationInfo) return null;
    
    const { name, ccp } = donationInfo.baridiMob;
    const qrData = `CCP: ${ccp}, Name: ${name}`;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity duration-300" onClick={onClose}>
            <div
                className="bg-white dark:bg-[#0f1429] rounded-lg shadow-xl p-8 w-full max-w-md m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{t('donateWithBaridiMob')}</h2>
                    <button onClick={onClose} className="text-gray-400 dark:text-gray-500 hover:text-gray-800 dark:hover:text-white absolute top-8 end-8">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>

                <div className="text-center">
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{t('supportCause')}: <span className="font-semibold text-gray-900 dark:text-white">{listingTitle}</span></p>
                    
                    <div className="bg-white p-4 rounded-lg inline-block">
                         <img 
                            src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(qrData)}`} 
                            alt="BaridiMob QR Code"
                            className="w-48 h-48"
                        />
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">{t('scanQrCode')}</p>

                    <div className="my-6">
                        <div className="h-px bg-gray-200 dark:bg-gray-700 w-1/2 mx-auto"></div>
                        <p className="text-gray-500 dark:text-gray-400 bg-white dark:bg-[#0f1429] -mt-3 px-2 inline-block">{t('orUseCcp')}</p>
                    </div>

                    <div className="bg-gray-100 dark:bg-gray-800/50 p-4 rounded-lg text-start">
                        <div className="mb-2">
                            <p className="text-sm text-gray-500 dark:text-gray-400">{t('accountHolder')}:</p>
                            <p className="text-lg font-mono text-gray-900 dark:text-white">{name}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{t('accountNumber')} (CCP):</p>
                            <p className="text-lg font-mono text-gray-900 dark:text-white tracking-wider">{ccp}</p>
                        </div>
                    </div>
                </div>

                <button onClick={onClose} className="mt-8 w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md transition-colors">
                    {t('close')}
                </button>
                
                {/* Fix: Replaced <style jsx> with <style> to fix TypeScript error regarding invalid 'jsx' prop. */}
                <style>{`
                    @keyframes modal-pop {
                        from { transform: scale(0.9); opacity: 0; }
                        to { transform: scale(1); opacity: 1; }
                    }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </div>
        </div>
    );
};

export default DonationModal;
