import React, { useState, useEffect, useCallback, useMemo, ReactNode } from 'react';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { CATEGORY_FILTERS } from '../constants/filterConfig';
import { CAR_DATA } from '../constants/carData';
import { FilterDefinition, ListingFilters } from '../services/types';

interface AccordionProps {
    title: string;
    children: ReactNode;
    defaultOpen?: boolean;
}

const Accordion: React.FC<AccordionProps> = ({ title, children, defaultOpen = false }) => {
    const [isOpen, setIsOpen] = useState(defaultOpen);
    return (
        <div className="border-b border-gray-200 dark:border-gray-700">
            <button onClick={() => setIsOpen(!isOpen)} className="w-full flex justify-between items-center py-4 text-start">
                <span className="font-semibold text-gray-800 dark:text-gray-200">{title}</span>
                <svg className={`w-5 h-5 text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
            </button>
            <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-[1000px] pb-4' : 'max-h-0'}`}>
                {children}
            </div>
        </div>
    );
};


interface FiltersSidebarProps {
    categorySlug: string;
    onApplyFilters: (filters: ListingFilters) => void;
    initialFilters?: ListingFilters;
    // FIX: Made isOpen and onClose optional as they are injected by the parent layout.
    isOpen?: boolean;
    onClose?: () => void;
    isMobile?: boolean;
}

const FiltersSidebar: React.FC<FiltersSidebarProps> = ({ categorySlug, onApplyFilters, initialFilters, isOpen, onClose = () => {}, isMobile = false }) => {
    const { t } = useLocalization();
    const [filters, setFilters] = useState<ListingFilters>(initialFilters || {});

    useEffect(() => {
        setFilters(initialFilters || {});
    }, [initialFilters]);

    const categoryFilterDefs = useMemo(() => CATEGORY_FILTERS[categorySlug] || [], [categorySlug]);
    
    const carBrands = useMemo(() => CAR_DATA.map(c => c.brand), []);
    const carModels = useMemo(() => {
        if (filters.marque) {
            return CAR_DATA.find(c => c.brand === filters.marque)?.models || [];
        }
        return [];
    }, [filters.marque]);

    const handleFilterChange = useCallback((key: string, value: any) => {
        setFilters(prev => {
            const newFilters = { ...prev };
            if (Array.isArray(prev[key])) { // Checkbox logic
                const currentValues = prev[key] as string[];
                const newValues = currentValues.includes(value) ? currentValues.filter(v => v !== value) : [...currentValues, value];
                newFilters[key] = newValues;
            } else { // Radio or other input logic
                 newFilters[key] = value;
            }
            if (key === 'marque') delete newFilters.modele;
            return newFilters;
        });
    }, []);

    const handleApply = () => {
        onApplyFilters(filters);
        onClose();
    };

    const handleReset = () => {
        setFilters({});
        onApplyFilters({});
        onClose();
    };
    
    const renderFilterControl = (def: FilterDefinition) => {
        const key = def.key;
        const baseClasses = "block w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500";
        switch(def.type) {
            case 'radio-group':
            case 'checkbox-group':
                const type = def.type === 'radio-group' ? 'radio' : 'checkbox';
                return (
                    <div className="space-y-3">
                        {def.options?.map(opt => (
                            <label key={opt.value} className="flex items-center gap-2 cursor-pointer text-gray-700 dark:text-gray-300">
                                <input type={type} name={key} value={opt.value} 
                                    checked={type === 'radio' ? filters[key] === opt.value : (filters[key] as string[] || []).includes(opt.value)}
                                    onChange={() => handleFilterChange(key, opt.value)}
                                    className={`h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-900 ${type === 'checkbox' ? 'rounded' : ''}`} 
                                />
                                <span>{t(opt.labelKey as TranslationKey)}</span>
                            </label>
                        ))}
                    </div>
                );
            case 'select':
                let options = (def.key === 'marque') ? carBrands.map(b => ({ label: b, value: b })) : (def.key === 'modele') ? carModels.map(m => ({ label: m, value: m })) : (def.options || []).map(o => ({ label: t(o.labelKey as TranslationKey), value: o.value}));
                return (
                    <select id={key} name={key} value={filters[key] || ''} onChange={(e) => handleFilterChange(key, e.target.value)} className={baseClasses} disabled={def.key === 'modele' && !filters.marque}>
                        <option value="">{t('sellerAll')}</option>
                        {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                    </select>
                );
            case 'range-number':
                const minKey = def.minKey || `${def.key}Min`;
                const maxKey = def.maxKey || `${def.key}Max`;
                return (
                    <div className="flex gap-2">
                        <input type="number" min="0" placeholder={t('filterMin')} value={filters[minKey] || ''} onChange={e => handleFilterChange(minKey, e.target.value)} className={baseClasses} />
                        <input type="number" min="0" placeholder={t('filterMax')} value={filters[maxKey] || ''} onChange={e => handleFilterChange(maxKey, e.target.value)} className={baseClasses} />
                    </div>
                );
            default: return null;
        }
    };

    const content = (
        <div className={`bg-white dark:bg-[#10162b] text-gray-900 dark:text-white flex flex-col ${isMobile ? 'h-full w-full' : 'rounded-lg border border-gray-200 dark:border-gray-800'}`}>
            <div className="flex-shrink-0 flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
                <h3 className="text-xl font-bold">{t('filterResults')}</h3>
                {isMobile && (
                    <button onClick={onClose} className="p-2">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                )}
            </div>

            <div className="flex-grow overflow-y-auto px-4">
                {categoryFilterDefs.map(group => (
                    <Accordion key={group.key} title={t(group.labelKey as TranslationKey)} defaultOpen={true}>
                        <div className="space-y-4">
                            {group.subFilters?.map(def => (
                                <div key={def.key}>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t(def.labelKey as TranslationKey)}</label>
                                    {renderFilterControl(def)}
                                </div>
                            ))}
                        </div>
                    </Accordion>
                ))}
            </div>

            <div className="flex-shrink-0 p-4 border-t border-gray-200 dark:border-gray-700 space-y-3">
                 <button onClick={handleApply} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-md transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-blue-500/40 active:translate-y-0 active:scale-95">{t('applyFilters')}</button>
                 <button onClick={handleReset} className="w-full bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-white font-bold py-2 px-6 rounded-md transition-all duration-200 active:scale-95">{t('resetFilters')}</button>
            </div>
        </div>
    );
    
    return isMobile ? content : <div className="sticky top-24">{content}</div>;
};

export default FiltersSidebar;