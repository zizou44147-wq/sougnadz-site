

import React from 'react';
import NavbarLogo from './NavbarLogo';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';

const Footer: React.FC = () => {
    const { t } = useLocalization();
    
    const links: {
        store: { key: TranslationKey; href: string }[];
        about: { key: TranslationKey; href: string }[];
    } = {
        store: [
            { key: 'createStore', href: '#/help' }, 
            { key: 'advertise', href: '#/help' },
            { key: 'howToPost', href: '#/help' },
        ],
        about: [
            { key: 'contactUs', href: '#/help' },
            { key: 'privacyPolicy', href: '#/help' },
            { key: 'terms', href: '#/help' },
        ]
    };

    return (
        <footer className="bg-gray-50 dark:bg-black/50 border-t border-gray-200 dark:border-gray-800 text-gray-600 dark:text-gray-400">
            <div className="container mx-auto px-4 py-12">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                    {/* Column 1: Logo & About */}
                    <div className="md:col-span-2">
                        <NavbarLogo className="text-3xl" />
                        <p className={`mt-4 max-w-md text-start`}>
                            sougnadz.com est votre plateforme de confiance pour acheter et vendre des produits et services partout en Algérie.
                        </p>
                    </div>
                    
                    {/* Column 2: Store Links */}
                    <div>
                        <h3 className={`font-bold text-gray-900 dark:text-white text-lg mb-4 text-start`}>{t('createStore')}</h3>
                        <ul className={`space-y-2 text-start`}>
                             {links.store.map(link => (
                                <li key={link.key}>
                                    <a href={link.href} className="hover:text-gray-900 dark:hover:text-white transition-colors">
                                        {t(link.key)}
                                    </a>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* Column 3: About Links */}
                    <div>
                        <h3 className={`font-bold text-gray-900 dark:text-white text-lg mb-4 text-start`}>À propos</h3>
                         <ul className={`space-y-2 text-start`}>
                            {links.about.map(link => (
                                <li key={link.key}>
                                     <a href={link.href} className="hover:text-gray-900 dark:hover:text-white transition-colors">
                                        {t(link.key)}
                                    </a>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>

                <div className="mt-12 border-t border-gray-200 dark:border-gray-800 pt-8 flex flex-col sm:flex-row justify-between items-center">
                    <p className="text-sm">© {new Date().getFullYear()} sougnadz.com. {t('rightsReserved')}</p>
                    <div className="flex gap-4 mt-4 sm:mt-0">
                       {/* Social Icons would go here */}
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;