import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import NavbarLogo from './NavbarLogo';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { useTheme } from '../hooks/useTheme';
import AlgeriaFlagIcon from './icons/AlgeriaFlagIcon';
import FranceFlagIcon from './icons/FranceFlagIcon';
import SunIcon from './icons/SunIcon';
import MoonIcon from './icons/MoonIcon';
import RefreshIcon from './icons/RefreshIcon';
import AuthModal from './AuthModal';
import { Language } from '../services/types';
import { CATEGORIES } from '../constants/categories';

const Header: React.FC = () => {
    const { language, setLanguage, t } = useLocalization();
    const { theme, toggleTheme } = useTheme();
    const navigate = useNavigate();
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
    const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
    const [isCategoryMenuOpen, setIsCategoryMenuOpen] = useState(false);
    
    const userMenuRef = useRef<HTMLDivElement>(null);
    const categoryMenuRef = useRef<HTMLDivElement>(null);
    
    const handleLoginSuccess = () => {
        setIsLoggedIn(true);
        setIsAuthModalOpen(false);
    };

    const handleLogout = () => {
        setIsLoggedIn(false);
        setIsUserMenuOpen(false);
        navigate('/');
    };
    
    const handlePublishClick = () => {
        if (isLoggedIn) {
            navigate('/post-ad');
        } else {
            setIsAuthModalOpen(true);
        }
    };

    const toggleLanguage = (lang: Language) => {
        setLanguage(lang);
    };

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
                setIsUserMenuOpen(false);
            }
            if (categoryMenuRef.current && !categoryMenuRef.current.contains(event.target as Node)) {
                setIsCategoryMenuOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const navLinks: { key: TranslationKey, path: string }[] = [
        { key: 'home', path: '/' },
        { key: 'blog', path: '/blog' },
        { key: 'help', path: '/help' },
    ];
    
    return (
        <>
            <header className="bg-white/80 dark:bg-[#070b18]/80 backdrop-blur-sm sticky top-0 z-50 border-b border-gray-200 dark:border-gray-800">
                <div className="container mx-auto px-4">
                    <div className="flex items-center justify-between h-16">
                        <div className="flex items-center gap-8">
                            <NavbarLogo className="text-3xl" />
                            <nav className="hidden md:flex items-center gap-6">
                                {navLinks.map(link => (
                                    <Link 
                                        key={link.key} 
                                        to={link.path}
                                        className="cursor-pointer text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors duration-300"
                                    >
                                        {t(link.key)}
                                    </Link>
                                ))}
                                <div className="relative" ref={categoryMenuRef}>
                                    <button onClick={() => setIsCategoryMenuOpen(!isCategoryMenuOpen)} className="text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors duration-300 flex items-center gap-1">
                                        {t('categories')}
                                        <svg className={`w-4 h-4 transition-transform ${isCategoryMenuOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                                    </button>
                                    <div className={`absolute mt-2 w-56 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg py-1 start-0 transition-all duration-300 ease-out origin-top-left ${isCategoryMenuOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
                                        {CATEGORIES.map(cat => (
                                            <Link 
                                                key={cat.slug} 
                                                to={`/category/${cat.slug}`}
                                                onClick={() => setIsCategoryMenuOpen(false)}
                                                className={`w-full block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 text-start`}
                                            >
                                                {t(cat.labelKey)}
                                            </Link>
                                        ))}
                                    </div>
                                </div>
                            </nav>
                        </div>

                        <div className="flex items-center gap-4">
                             <div className="flex items-center border border-gray-200 dark:border-gray-700 rounded-full text-sm">
                                <button
                                    onClick={() => toggleLanguage('fr')}
                                    className={`flex items-center gap-2 px-3 py-1 rounded-full transition-colors ${language === 'fr' ? 'bg-blue-600 text-white' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'}`}
                                >
                                    <FranceFlagIcon className="w-4 h-4 rounded-sm" />
                                    <span>Français</span>
                                </button>
                                <button
                                    onClick={() => toggleLanguage('ar')}
                                    className={`flex items-center gap-2 px-3 py-1 rounded-full transition-colors ${language === 'ar' ? 'bg-blue-600 text-white' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'}`}
                                >
                                    <AlgeriaFlagIcon className="w-4 h-4 rounded-sm" />
                                    <span>العربية</span>
                                </button>
                            </div>

                             <button
                                onClick={toggleTheme}
                                className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                                aria-label="Toggle theme"
                            >
                                {theme === 'dark' ? <SunIcon className="w-5 h-5" /> : <MoonIcon className="w-5 h-5" />}
                            </button>

                            <button
                                onClick={() => window.location.reload()}
                                className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                                aria-label={t('refreshPage')}
                            >
                                <RefreshIcon className="w-5 h-5" />
                            </button>

                            <button onClick={handlePublishClick} className="hidden sm:block bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded-full transition-all duration-300 ease-in-out transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-orange-500/40 active:translate-y-0 active:scale-95">
                                {t('publishAd')}
                            </button>

                            {isLoggedIn ? (
                                <div className="relative" ref={userMenuRef}>
                                    <button onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}>
                                        <img src="https://i.pravatar.cc/150?u=mockuser" alt="User Avatar" className="w-9 h-9 rounded-full border-2 border-blue-500" />
                                    </button>
                                    <div className={`absolute mt-2 w-48 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg py-1 end-0 transition-all duration-300 ease-out origin-top-right ${isUserMenuOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
                                        <Link to="/profile" onClick={() => setIsUserMenuOpen(false)} className={`w-full block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 text-start`}>{t('profile')}</Link>
                                        <Link to="/myAds" onClick={() => setIsUserMenuOpen(false)} className={`w-full block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 text-start`}>{t('myAds')}</Link>
                                        <Link to="/favorites" onClick={() => setIsUserMenuOpen(false)} className={`w-full block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 text-start`}>{t('favorites')}</Link>
                                        <div className="border-t border-gray-200 dark:border-gray-700 my-1"></div>
                                        <button onClick={handleLogout} className={`w-full block px-4 py-2 text-sm text-red-500 hover:bg-gray-100 dark:hover:bg-gray-800 text-start`}>{t('logout')} </button>
                                    </div>
                                </div>
                            ) : (
                                <button onClick={() => setIsAuthModalOpen(true)} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full transition-all duration-300 ease-in-out transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-blue-500/40 active:translate-y-0 active:scale-95">
                                    {t('login')}
                                </button>
                            )}
                        </div>
                    </div>
                </div>
            </header>
            <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} onLoginSuccess={handleLoginSuccess} />
        </>
    );
};

export default Header;