import React, { useState, useRef, useEffect } from 'react';
import { Listing, ListingBadge } from '../services/types';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { useNavigate } from 'react-router-dom';
import { formatTimeAgo } from '../utils/time';
import MoreIcon from './icons/MoreIcon';
import FlagIcon from './icons/FlagIcon';
import { useReportAd } from '../hooks/useReportAd';

// --- HELPER COMPONENTS ---

const Badge: React.FC<{ badge: ListingBadge }> = ({ badge }) => {
    const badgeMap = {
        [ListingBadge.New]: { color: 'bg-blue-600', text: 'Nouveau' },
        [ListingBadge.Top]: { color: 'bg-yellow-400 text-black', text: 'Top' },
        [ListingBadge.Promo]: { color: 'bg-green-500', text: 'Promo' },
        [ListingBadge.Urgent]: { color: 'bg-red-500', text: 'Urgent' },
    };
    const currentBadge = badgeMap[badge];

    return (
        <span className={`absolute top-2.5 left-2.5 text-xs font-semibold text-white px-2.5 py-1 rounded-md z-10 ${currentBadge.color}`}>
            {currentBadge.text}
        </span>
    );
};

const UserStatus: React.FC<{ isOnline: boolean }> = ({ isOnline }) => {
    const { t } = useLocalization();
    const statusTextKey = isOnline ? 'online' : 'offline';
    const color = isOnline ? 'bg-emerald-400' : 'bg-red-400';
    return (
        <span className="inline-flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400">
            <span className={`h-2 w-2 rounded-full ${color}`} />
            <span className="capitalize">{t(statusTextKey)}</span>
        </span>
    );
};


// --- MAIN COMPONENT ---

const ListingCard: React.FC<{ listing: Listing }> = ({ listing }) => {
    const { t, language } = useLocalization();
    const navigate = useNavigate();
    const { openReportAdModal } = useReportAd();
    const [isFavorited, setIsFavorited] = useState(listing.isFavorite || false);
    const [isAnimating, setIsAnimating] = useState(false);
    const [isOptionsOpen, setIsOptionsOpen] = useState(false);
    const optionsMenuRef = useRef<HTMLDivElement>(null);


    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (optionsMenuRef.current && !optionsMenuRef.current.contains(event.target as Node)) {
                setIsOptionsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleCardClick = () => {
        navigate(`/listing/${listing.id}`);
    };
    
    const toggleFavorite = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (!isFavorited) {
            setIsAnimating(true);
        }
        setIsFavorited(!isFavorited);
    };

    const handleOptionsClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsOptionsOpen(prev => !prev);
    };

    const handleReportClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        openReportAdModal(listing);
        setIsOptionsOpen(false);
    }

    const priceTypeTranslation: { [key: string]: TranslationKey } = {
        fixe: 'priceFixe',
        negociable: 'priceNegociable',
        offre: 'priceOffre',
    };
    
    const renderDetails = () => {
        const meta = listing.meta;
        const valueTranslationMap: { [key: string]: { [val: string]: TranslationKey } } = {
            fuel: { 'essence': 'fuelEssence', 'diesel': 'fuelDiesel', 'gpl': 'fuelGpl', 'hybride': 'fuelHybrid', 'electrique': 'fuelElectric', 'autre': 'fuelOther' },
        };

        if (listing.category === 'Automobiles & Véhicules') {
            const fuelKey = valueTranslationMap.fuel[meta.fuel as string];
            const details = [
                meta.year,
                meta.km ? `${(meta.km as number).toLocaleString(language === 'fr' ? 'fr-FR' : 'ar-DZ')} km` : null,
                fuelKey ? t(fuelKey) : meta.fuel,
            ].filter(Boolean);

            return (
                 <div className="space-y-1">
                     <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                       {details.map((detail, index) => (
                           <React.Fragment key={index}>
                               <span className="capitalize">{detail}</span>
                               {index < details.length - 1 && <span className="opacity-50 text-base leading-none">&middot;</span>}
                           </React.Fragment>
                       ))}
                    </div>
                    <UserStatus isOnline={listing.user.isOnline} />
                </div>
            );
        }
        
        const postedAgo = formatTimeAgo(listing.createdAt, t, language);
        return (
            <div className="space-y-1">
                <p className="text-sm">
                    {listing.location}{listing.commune ? `, ${listing.commune}` : ''} &middot; {postedAgo}
                </p>
                <UserStatus isOnline={listing.user.isOnline} />
            </div>
        );
    };


    return (
        <div 
            onClick={handleCardClick}
            className="group relative overflow-hidden rounded-xl bg-white dark:bg-[#10162b] shadow-md dark:shadow-black/25 h-full flex flex-col cursor-pointer border border-gray-200 dark:border-gray-800/50 hover:border-blue-500/80 transition-all duration-300 transform hover:-translate-y-1"
        >
            <div className="relative">
                <img
                    src={listing.imageUrl}
                    alt={listing.title}
                    className="h-52 w-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                {listing.badge && <Badge badge={listing.badge} />}
                
                 <div className="absolute top-2.5 right-2.5 z-20 flex flex-col gap-2" ref={optionsMenuRef}>
                    <div className="relative">
                        <button
                            onClick={handleOptionsClick}
                            aria-label="More options"
                            className="p-2 bg-gray-900/50 rounded-full text-white hover:bg-black/60 transition-colors"
                        >
                            <MoreIcon className="w-5 h-5" />
                        </button>
                         <div className={`absolute mt-2 w-40 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg py-1 end-0 transition-all duration-300 ease-out origin-top-right ${isOptionsOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
                            <button onClick={handleReportClick} className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-800 text-start">
                                <FlagIcon className="w-4 h-4" />
                                <span>{t('report')}</span>
                            </button>
                        </div>
                    </div>
                </div>

                <button
                    onClick={toggleFavorite}
                    onAnimationEnd={() => setIsAnimating(false)}
                    aria-label={t(isFavorited ? 'removeFromFavorites' : 'addToFavorites')}
                    className="absolute bottom-2.5 right-2.5 z-10 p-2 bg-gray-900/50 rounded-full text-white hover:bg-black/60 transition-colors"
                >
                    <svg className={`w-5 h-5 ${isAnimating ? 'heart-popping' : ''}`} fill={isFavorited ? '#ef4444' : 'none'} stroke={isFavorited ? 'none' : 'currentColor'} strokeWidth={2} viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 016.364 0L12 7.636l1.318-1.318a4.5 4.5 0 016.364 6.364L12 20.364l-7.682-7.682a4.5 4.5 0 010-6.364z" />
                    </svg>
                </button>
            </div>

            <div className="p-4 flex-grow flex flex-col">
                <div className="flex-grow">
                    <h3 className="font-semibold text-gray-900 dark:text-white line-clamp-2">{listing.title}</h3>
                    <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                        {renderDetails()}
                    </div>
                </div>
                
                <div className="mt-auto pt-2 flex items-baseline justify-between gap-2">
                    <p className="text-lg font-bold text-yellow-600 dark:text-yellow-500 truncate">
                        {listing.price}
                    </p>
                    {listing.meta.priceType && (
                        <span className="text-xs flex-shrink-0 font-semibold text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-gray-700/50 px-2 py-1 rounded-full">
                            {t(priceTypeTranslation[listing.meta.priceType])}
                        </span>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ListingCard;
