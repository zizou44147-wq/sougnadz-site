import React, { FC } from "react";
import { useNavigate } from "react-router-dom";

interface NavbarLogoProps {
  className?: string;
}

const NavbarLogo: FC<NavbarLogoProps> = ({ className }) => {
  const navigate = useNavigate();

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    navigate('/');
  };

  return (
    <div
      onClick={handleClick}
      className={`inline-flex cursor-pointer transition-transform duration-300 ease-in-out hover:scale-105 font-black text-white rounded-md overflow-hidden shadow-md ${className}`}
      style={{ fontFamily: "'Nunito', sans-serif" }}
      aria-label="Go to sougnadz.com homepage"
    >
      <span className="bg-blue-600 px-3 py-1 overline decoration-black decoration-2">sougna</span>
      <span className="bg-orange-600 px-3 py-1 overline decoration-black decoration-2">dz.com</span>
    </div>
  );
};

export default NavbarLogo;