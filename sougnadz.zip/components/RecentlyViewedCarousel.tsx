import React, { useEffect, useState } from 'react';
import { MOCK_LISTINGS } from '../constants/mockData';
import { Listing } from '../services/types';
import ListingCard from './ListingCard';
import { useLocalization } from '../hooks/useLocalization';

const RecentlyViewedCarousel: React.FC = () => {
    const [listings, setListings] = useState<Listing[]>([]);
    const { t } = useLocalization();

    useEffect(() => {
        try {
            const viewedIds: number[] = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
            if (viewedIds.length > 0) {
                const viewedListings = viewedIds
                    .map(id => MOCK_LISTINGS.find(listing => listing.id === id))
                    .filter((listing): listing is Listing => Boolean(listing));
                setListings(viewedListings);
            }
        } catch (error) {
            console.error("Failed to parse recently viewed listings from localStorage", error);
        }
    }, []);

    if (listings.length === 0) {
        return null;
    }

    return (
        <section className="py-12">
            <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">{t('recentlyViewed')}</h2>
                <div className="relative">
                    <div
                        className="flex items-start gap-6 overflow-x-auto snap-x snap-mandatory scroll-smooth hide-scrollbar -mx-4 px-4"
                    >
                        {listings.map((listing) => (
                            <div key={`recent-${listing.id}`} className="w-[300px] sm:w-[320px] md:w-[350px] flex-shrink-0 snap-start">
                                <ListingCard listing={listing} />
                            </div>
                        ))}
                    </div>
                    <style>{`
                        .hide-scrollbar {
                            -ms-overflow-style: none; /* IE and Edge */
                            scrollbar-width: none; /* Firefox */
                        }
                        .hide-scrollbar::-webkit-scrollbar {
                            display: none; /* Chrome, Safari and Opera */
                        }
                    `}</style>
                </div>
            </div>
        </section>
    );
};

export default RecentlyViewedCarousel;
