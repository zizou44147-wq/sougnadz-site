import React, { useState } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { useReportAd } from '../hooks/useReportAd';
import FlagIcon from './icons/FlagIcon';

const ReportAdModal: React.FC = () => {
    const { t } = useLocalization();
    const { isReportModalOpen, closeReportAdModal, listingToReport } = useReportAd();
    const [reason, setReason] = useState('');
    const [details, setDetails] = useState('');
    const [submitted, setSubmitted] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        console.log({
            listingId: listingToReport?.id,
            reason,
            details
        });
        setSubmitted(true);
        setTimeout(() => {
            handleClose();
        }, 2500);
    };

    const handleClose = () => {
        setSubmitted(false);
        setReason('');
        setDetails('');
        closeReportAdModal();
    };

    if (!isReportModalOpen) return null;

    const reasons = [
        'reportReasonFraud',
        'reportReasonInappropriate',
        'reportReasonDuplicate',
        'reportReasonSold',
        'reportReasonWrongCategory',
        'reportReasonOther'
    ];

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-[100] transition-opacity duration-300" onClick={handleClose}>
            <div
                className="bg-white dark:bg-[#0f1429] rounded-lg shadow-xl p-8 w-full max-w-lg m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative"
                onClick={(e) => e.stopPropagation()}
            >
                 <button onClick={handleClose} className="absolute top-4 end-4 text-gray-400 dark:text-gray-500 hover:text-gray-800 dark:hover:text-white">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
                
                {submitted ? (
                     <div className="text-center py-10">
                        <div className="w-16 h-16 bg-green-100 dark:bg-green-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
                             <svg className="w-10 h-10 text-green-600 dark:text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                        </div>
                        <p className="text-2xl text-green-600 dark:text-green-400 font-semibold">{t('reportSentSuccess')}</p>
                        <p className="mt-2 text-gray-600 dark:text-gray-400">{t('reportSentMessage')}</p>
                    </div>
                ) : (
                    <>
                        <div className="flex items-center gap-3 mb-6">
                            <FlagIcon className="w-8 h-8 text-red-500" />
                            <div>
                                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{t('reportAdTitle')}</h2>
                                <p className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-sm">{listingToReport?.title}</p>
                            </div>
                        </div>
                       
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('reportAdReason')}</label>
                                <div className="space-y-2">
                                    {reasons.map(reasonKey => (
                                         <label key={reasonKey} className="flex items-center gap-3 cursor-pointer p-3 bg-gray-50 dark:bg-slate-800/50 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors">
                                            <input 
                                                type="radio" 
                                                name="reason" 
                                                value={reasonKey}
                                                checked={reason === reasonKey}
                                                onChange={(e) => setReason(e.target.value)}
                                                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-900" 
                                            />
                                            <span className="text-gray-900 dark:text-gray-100">{t(reasonKey as any)}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                            
                            {reason === 'reportReasonOther' && (
                                <div>
                                    <label htmlFor="details" className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('reportDetails')}</label>
                                    <textarea 
                                        id="details" 
                                        rows={3} 
                                        value={details}
                                        onChange={(e) => setDetails(e.target.value)}
                                        placeholder={t('reportDetailsPlaceholder')}
                                        className="mt-1 block w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                    />
                                </div>
                            )}

                            <button 
                                type="submit" 
                                disabled={!reason}
                                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-md transition-colors disabled:bg-red-400/50 disabled:cursor-not-allowed"
                            >
                                {t('submitReport')}
                            </button>
                        </form>
                    </>
                )}
                
                <style>{`
                    @keyframes modal-pop {
                        from { transform: scale(0.9); opacity: 0; }
                        to { transform: scale(1); opacity: 1; }
                    }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </div>
        </div>
    );
};

export default ReportAdModal;
