

import React, { useRef, useState, useEffect, useCallback } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { TranslationKey } from '../hooks/useLocalization';

interface SubCategory {
    slug: string;
    labelKey: TranslationKey;
    imageUrl: string;
}

interface SubCategoryCarouselProps {
    subCategories: SubCategory[];
    onSelect: (slug: string | null) => void;
    selectedSlug?: string;
}

// Chevron Icon for navigation
const ChevronIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
    </svg>
);


const SubCategoryCarousel: React.FC<SubCategoryCarouselProps> = ({ subCategories, onSelect, selectedSlug }) => {
    const { t, direction } = useLocalization();
    const scrollerRef = useRef<HTMLDivElement>(null);
    const [canScrollLeft, setCanScrollLeft] = useState(false);
    const [canScrollRight, setCanScrollRight] = useState(false);
    
    const checkScrollability = useCallback(() => {
        const el = scrollerRef.current;
        if (el) {
            const tolerance = 2;
            const hasHorizontalScroll = el.scrollWidth > el.clientWidth;

            if (!hasHorizontalScroll) {
                setCanScrollLeft(false);
                setCanScrollRight(false);
                return;
            }

            const scrollLeft = el.scrollLeft;

            const atStart = scrollLeft <= tolerance;
            const atEnd = scrollLeft >= el.scrollWidth - el.clientWidth - tolerance;

            setCanScrollLeft(!atStart);
            setCanScrollRight(!atEnd);
        }
    }, []);

    useEffect(() => {
        const el = scrollerRef.current;
        if (el) {
            checkScrollability();
            const resizeObserver = new ResizeObserver(checkScrollability);
            resizeObserver.observe(el);
            el.addEventListener('scroll', checkScrollability, { passive: true });

            return () => {
                resizeObserver.unobserve(el);
                el.removeEventListener('scroll', checkScrollability);
            };
        }
    }, [subCategories, checkScrollability]);

    const handleNav = (scrollDirection: 'prev' | 'next') => {
        const el = scrollerRef.current;
        if (el) {
            const scrollAmount = el.clientWidth * 0.7;
            let finalAmount = scrollDirection === 'prev' ? -scrollAmount : scrollAmount;
            el.scrollBy({ left: finalAmount, behavior: 'smooth' });
        }
    };
    
    // Add "All Categories" option at the beginning
    const allItems = [{ slug: '', labelKey: 'categoryToutesLesCategories' as TranslationKey, imageUrl: 'https://picsum.photos/seed/all-cats/200' }, ...subCategories];


    return (
        <div className="relative group">
            <button
                onClick={() => handleNav('prev')}
                aria-label="Previous categories"
                className={`hidden md:flex items-center justify-center absolute top-1/2 -translate-y-1/2 z-20 w-10 h-10 bg-white/80 dark:bg-black/50 rounded-full text-gray-800 dark:text-white shadow-md hover:bg-white dark:hover:bg-black/80 transition-opacity duration-300 start-0 group-hover:opacity-100 ${!canScrollLeft ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
            >
                <ChevronIcon className={`w-6 h-6 rotate-180`} />
            </button>
            <button
                onClick={() => handleNav('next')}
                aria-label="Next categories"
                className={`hidden md:flex items-center justify-center absolute top-1/2 -translate-y-1/2 z-20 w-10 h-10 bg-white/80 dark:bg-black/50 rounded-full text-gray-800 dark:text-white shadow-md hover:bg-white dark:hover:bg-black/80 transition-opacity duration-300 end-0 group-hover:opacity-100 ${!canScrollRight ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
            >
                <ChevronIcon className={`w-6 h-6`} />
            </button>
            
            <div
                ref={scrollerRef}
                className="flex items-center gap-6 overflow-x-auto snap-x snap-mandatory scroll-smooth p-4 -m-4 hide-scrollbar"
            >
                {allItems.map((cat) => {
                    const isSelected = cat.slug === (selectedSlug || '');
                    return (
                        <div key={cat.slug} className="text-center snap-start flex-shrink-0 w-24">
                            <button
                                onClick={() => onSelect(cat.slug || null)}
                                className="flex flex-col items-center gap-2 group/item"
                            >
                                <div className={`w-20 h-20 rounded-full overflow-hidden border-2 transition-colors duration-300 ${isSelected ? 'border-orange-500' : 'border-gray-300 dark:border-gray-700 group-hover/item:border-orange-400'}`}>
                                    <img
                                        src={cat.imageUrl}
                                        alt={t(cat.labelKey)}
                                        className="w-full h-full object-cover"
                                        loading="lazy"
                                    />
                                </div>
                                <span className={`text-xs font-semibold transition-colors duration-300 ${isSelected ? 'text-orange-600 dark:text-orange-400' : 'text-gray-700 dark:text-gray-300 group-hover/item:text-orange-500'}`}>
                                    {t(cat.labelKey)}
                                </span>
                            </button>
                        </div>
                    );
                })}
            </div>
             <style>{`
                .hide-scrollbar {
                    -ms-overflow-style: none;
                    scrollbar-width: none;
                }
                .hide-scrollbar::-webkit-scrollbar {
                    display: none;
                }
             `}</style>
        </div>
    );
};

export default SubCategoryCarousel;