import React from 'react';

const AlgeriaFlagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 600" {...props}>
        <path fill="#fff" d="M0 0h900v600H0z"/>
        <path fill="#006233" d="M0 0h450v600H0z"/>
        <path fill="#d21034" d="M675 300a150 150 0 1 0-300 0 150 150 0 0 0 300 0z"/>
        {/* Fix: The original path element had a duplicate 'fill' attribute which is invalid in JSX. It has been split into two paths for the crescent and the star with their respective colors. */}
        <path fill="#fff" d="M562.5 300a112.5 112.5 0 1 0-225 0 112.5 112.5 0 0 0 225 0z"/>
        <path fill="#d21034" d="M525 150l-37.5 112.5h125L550 150l-25-75z" transform="rotate(-18 525 300)"/>
    </svg>
);

export default AlgeriaFlagIcon;