
import React from 'react';

const FranceFlagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 600" {...props}>
        <path fill="#fff" d="M0 0h900v600H0z"/>
        <path fill="#002654" d="M0 0h300v600H0z"/>
        <path fill="#ce1126" d="M600 0h300v600H600z"/>
    </svg>
);

export default FranceFlagIcon;
