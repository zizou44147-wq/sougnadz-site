// src/constants/categories.ts
import { TranslationKey } from '../hooks/useLocalization';

export interface Category {
  slug: string;
  labelKey: TranslationKey;
  apiName: string;
  color: string;
  subCategories?: {
    slug: string;
    labelKey: TranslationKey;
    imageUrl: string;
  }[];
}

export const CATEGORIES: Category[] = [
  { 
    slug: 'boutiques', 
    labelKey: 'categoryBoutiques', 
    apiName: 'Boutiques', 
    color: 'from-pink-500 to-rose-500',
    subCategories: [
        { slug: 'boutiques-informatique', labelKey: 'categoryBoutiquesInformatique', imageUrl: 'https://picsum.photos/seed/shop-it/200' },
        { slug: 'boutiques-telephonie', labelKey: 'categoryBoutiquesTelephonie', imageUrl: 'https://picsum.photos/seed/shop-phones/200' },
        { slug: 'boutiques-electromenager', labelKey: 'categoryBoutiquesElectromenager', imageUrl: 'https://picsum.photos/seed/shop-electro/200' },
        { slug: 'boutiques-meubles', labelKey: 'categoryBoutiquesMeubles', imageUrl: 'https://picsum.photos/seed/shop-furniture/200' },
        { slug: 'boutiques-vetements', labelKey: 'categoryBoutiquesVetements', imageUrl: 'https://picsum.photos/seed/shop-fashion/200' },
        { slug: 'boutiques-cosmetiques', labelKey: 'categoryBoutiquesCosmetiques', imageUrl: 'https://picsum.photos/seed/shop-cosmetics/200' },
    ]
  },
  { 
    slug: 'immobilier', 
    labelKey: 'categoryImmobilier', 
    apiName: 'Immobilier', 
    color: 'from-emerald-500 to-teal-600',
    subCategories: [
        { slug: 'vente', labelKey: 'categoryImmobilierVente', imageUrl: 'https://picsum.photos/seed/immo-vente/200' },
        { slug: 'location', labelKey: 'categoryImmobilierLocation', imageUrl: 'https://picsum.photos/seed/immo-location/200' },
        { slug: 'colocation', labelKey: 'categoryImmobilierColocation', imageUrl: 'https://picsum.photos/seed/immo-colocation/200' },
        { slug: 'location-vacances', labelKey: 'categoryImmobilierLocationVacances', imageUrl: 'https://picsum.photos/seed/immo-vacances/200' },
        { slug: 'bureaux-commerces', labelKey: 'categoryImmobilierBureauxCommerces', imageUrl: 'https://picsum.photos/seed/immo-bureaux/200' },
    ]
  },
  { 
    slug: 'automobiles-vehicules', 
    labelKey: 'categoryAutomobilesVehicules', 
    apiName: 'Automobiles & Véhicules', 
    color: 'from-sky-500 to-blue-600',
    subCategories: [
        { slug: 'voitures', labelKey: 'carCatVoitures', imageUrl: 'https://picsum.photos/seed/auto-voitures/200' },
        { slug: 'motos_scooters', labelKey: 'carCatMotosScooters', imageUrl: 'https://picsum.photos/seed/auto-motos/200' },
        { slug: 'utilitaires', labelKey: 'carCatUtilitaires', imageUrl: 'https://picsum.photos/seed/auto-utilitaires/200' },
        { slug: 'camion', labelKey: 'carCatCamion', imageUrl: 'https://picsum.photos/seed/auto-camions/200' },
        { slug: 'engin', labelKey: 'carCatEngin', imageUrl: 'https://picsum.photos/seed/auto-engin/200' },
        { slug: 'bateaux-barques', labelKey: 'carCatBateauxBarques', imageUrl: 'https://picsum.photos/seed/auto-bateaux/200' },
    ]
  },
  { 
    slug: 'pieces-detachees', 
    labelKey: 'categoryPiecesDetachees', 
    apiName: 'Pièces détachées', 
    color: 'from-gray-500 to-slate-600',
    subCategories: [
        { slug: 'pneus-jantes', labelKey: 'categoryPiecesPneusJantes', imageUrl: 'https://picsum.photos/seed/pieces-pneus/200' },
        { slug: 'moteurs-boites', labelKey: 'categoryPiecesMoteursBoites', imageUrl: 'https://picsum.photos/seed/pieces-moteurs/200' },
        { slug: 'carrosserie', labelKey: 'categoryPiecesCarrosserie', imageUrl: 'https://picsum.photos/seed/pieces-carrosserie/200' },
        { slug: 'eclairage', labelKey: 'categoryPiecesEclairage', imageUrl: 'https://picsum.photos/seed/pieces-eclairage/200' },
        { slug: 'interieur-son', labelKey: 'categoryPiecesInterieur', imageUrl: 'https://picsum.photos/seed/pieces-interieur/200' },
    ]
  },
  { 
    slug: 'telephones-accessoires', 
    labelKey: 'categoryTelephonesAccessoires', 
    apiName: 'Téléphones & Accessoires', 
    color: 'from-fuchsia-500 to-pink-600',
    subCategories: [
        { slug: 'smartphones', labelKey: 'categorySmartphones', imageUrl: 'https://picsum.photos/seed/smartphones/200' },
        { slug: 'tablettes', labelKey: 'categoryTablettes', imageUrl: 'https://picsum.photos/seed/tablets/200' },
        { slug: 'smartwatches', labelKey: 'categorySmartwatches', imageUrl: 'https://picsum.photos/seed/smartwatch/200' },
        { slug: 'ecouteurs-son', labelKey: 'categoryEcouteursSon', imageUrl: 'https://picsum.photos/seed/headphones/200' },
        { slug: 'protection-antichoc', labelKey: 'categoryProtectionAntichoc', imageUrl: 'https://picsum.photos/seed/cases/200' },
        { slug: 'chargeurs-cables', labelKey: 'categoryChargeursCables', imageUrl: 'https://picsum.photos/seed/chargers/200' },
    ]
  },
  { 
    slug: 'informatique', 
    labelKey: 'categoryInformatique', 
    apiName: 'Informatique', 
    color: 'from-cyan-500 to-indigo-600',
    subCategories: [
        { slug: 'ordinateurs-portables', labelKey: 'categoryInformatiqueLaptops', imageUrl: 'https://picsum.photos/seed/info-laptops/200' },
        { slug: 'ordinateurs-de-bureau', labelKey: 'categoryInformatiqueDesktops', imageUrl: 'https://picsum.photos/seed/info-desktops/200' },
        { slug: 'composants', labelKey: 'categoryInformatiqueComposants', imageUrl: 'https://picsum.photos/seed/info-composants/200' },
        { slug: 'stockage', labelKey: 'categoryInformatiqueStockage', imageUrl: 'https://picsum.photos/seed/info-stockage/200' },
        { slug: 'peripheriques', labelKey: 'categoryInformatiquePeripheriques', imageUrl: 'https://picsum.photos/seed/info-peripheriques/200' },
        { slug: 'reseaux', labelKey: 'categoryInformatiqueReseaux', imageUrl: 'https://picsum.photos/seed/info-reseaux/200' },
    ]
  },
  { 
    slug: 'electromenager-electronique', 
    labelKey: 'categoryElectromenagerElectronique', 
    apiName: 'Électroménager & Électronique', 
    color: 'from-blue-400 to-purple-500',
    subCategories: [
      { slug: 'gros-electromenager', labelKey: 'categoryElectroGros', imageUrl: 'https://picsum.photos/seed/electro-gros/200' },
      { slug: 'petit-electromenager', labelKey: 'categoryElectroPetit', imageUrl: 'https://picsum.photos/seed/electro-petit/200' },
      { slug: 'tv-son', labelKey: 'categoryElectroTvSon', imageUrl: 'https://picsum.photos/seed/electro-tv/200' },
      { slug: 'photo-video', labelKey: 'categoryElectroPhotoVideo', imageUrl: 'https://picsum.photos/seed/electro-photo/200' },
      { slug: 'climatisation-chauffage', labelKey: 'categoryElectroChauffageClim', imageUrl: 'https://picsum.photos/seed/electro-clim/200' },
    ]
  },
  { 
    slug: 'vetements-mode', 
    labelKey: 'categoryVetementsMode', 
    apiName: 'Vêtements & Mode', 
    color: 'from-rose-400 to-fuchsia-500',
    subCategories: [
        { slug: 'vetements-homme', labelKey: 'categoryVetementsHomme', imageUrl: 'https://picsum.photos/seed/mode-homme/200' },
        { slug: 'vetements-femme', labelKey: 'categoryVetementsFemme', imageUrl: 'https://picsum.photos/seed/mode-femme/200' },
        { slug: 'vetements-enfant', labelKey: 'categoryVetementsEnfant', imageUrl: 'https://picsum.photos/seed/mode-enfant/200' },
        { slug: 'chaussures', labelKey: 'categoryChaussures', imageUrl: 'https://picsum.photos/seed/mode-chaussures/200' },
        { slug: 'montres-bijoux', labelKey: 'categoryMontresBijoux', imageUrl: 'https://picsum.photos/seed/mode-bijoux/200' },
        { slug: 'sacs-accessoires', labelKey: 'categorySacsAccessoires', imageUrl: 'https://picsum.photos/seed/mode-sacs/200' },
    ]
  },
  { 
    slug: 'sante-beaute', 
    labelKey: 'categorySanteBeaute', 
    apiName: 'Santé & Beauté', 
    color: 'from-green-400 to-lime-500',
    subCategories: [
      { slug: 'parfums', labelKey: 'categorySanteParfums', imageUrl: 'https://picsum.photos/seed/sante-parfum/200' },
      { slug: 'maquillage', labelKey: 'categorySanteMaquillage', imageUrl: 'https://picsum.photos/seed/sante-makeup/200' },
      { slug: 'soins', labelKey: 'categorySanteSoins', imageUrl: 'https://picsum.photos/seed/sante-soins/200' },
      { slug: 'materiel-medical', labelKey: 'categorySanteMaterielMedical', imageUrl: 'https://picsum.photos/seed/sante-medical/200' },
      { slug: 'complements-alimentaires', labelKey: 'categorySanteComplements', imageUrl: 'https://picsum.photos/seed/sante-complements/200' },
    ]
  },
  { 
    slug: 'meubles-maison', 
    labelKey: 'categoryMeublesMaison', 
    apiName: 'Meubles & Maison', 
    color: 'from-amber-600 to-yellow-700',
    subCategories: [
      { slug: 'salons-sejours', labelKey: 'categoryMeublesSalons', imageUrl: 'https://picsum.photos/seed/meubles-salons/200' },
      { slug: 'chambres-a-coucher', labelKey: 'categoryMeublesChambres', imageUrl: 'https://picsum.photos/seed/meubles-chambres/200' },
      { slug: 'cuisines-salles-de-bain', labelKey: 'categoryMeublesCuisines', imageUrl: 'https://picsum.photos/seed/meubles-cuisines/200' },
      { slug: 'decoration-luminaires', labelKey: 'categoryMeublesDecoration', imageUrl: 'https://picsum.photos/seed/meubles-deco/200' },
      { slug: 'jardin-exterieur', labelKey: 'categoryMeublesJardin', imageUrl: 'https://picsum.photos/seed/meubles-jardin/200' },
    ]
  },
  { 
    slug: 'loisirs-divertissements', 
    labelKey: 'categoryLoisirsDivertissements', 
    apiName: 'Loisirs & Divertissements', 
    color: 'from-red-500 to-orange-600',
    subCategories: [
      { slug: 'livres-magazines', labelKey: 'categoryLoisirsLivres', imageUrl: 'https://picsum.photos/seed/loisirs-livres/200' },
      { slug: 'musique-instruments', labelKey: 'categoryLoisirsMusique', imageUrl: 'https://picsum.photos/seed/loisirs-musique/200' },
      { slug: 'films-series', labelKey: 'categoryLoisirsFilms', imageUrl: 'https://picsum.photos/seed/loisirs-films/200' },
      { slug: 'jeux-jouets', labelKey: 'categoryLoisirsJeux', imageUrl: 'https://picsum.photos/seed/loisirs-jeux/200' },
      { slug: 'collections', labelKey: 'categoryLoisirsCollections', imageUrl: 'https://picsum.photos/seed/loisirs-collections/200' },
      { slug: 'art-antiquites', labelKey: 'categoryLoisirsArt', imageUrl: 'https://picsum.photos/seed/loisirs-art/200' },
    ]
  },
  { 
    slug: 'sport', 
    labelKey: 'categorySport', 
    apiName: 'Sport', 
    color: 'from-indigo-500 to-purple-600',
    subCategories: [
      { slug: 'velos-cyclisme', labelKey: 'categorySportVelos', imageUrl: 'https://picsum.photos/seed/sport-velos/200' },
      { slug: 'fitness-musculation', labelKey: 'categorySportFitness', imageUrl: 'https://picsum.photos/seed/sport-fitness/200' },
      { slug: 'sports-collectifs', labelKey: 'categorySportCollectifs', imageUrl: 'https://picsum.photos/seed/sport-collectifs/200' },
      { slug: 'sports-de-combat', labelKey: 'categorySportCombat', imageUrl: 'https://picsum.photos/seed/sport-combat/200' },
      { slug: 'sports-nautiques', labelKey: 'categorySportNautiques', imageUrl: 'https://picsum.photos/seed/sport-nautiques/200' },
    ]
  },
  { 
    slug: 'emploi', 
    labelKey: 'categoryEmploi', 
    apiName: 'Emploi', 
    color: 'from-lime-500 to-emerald-600',
    subCategories: [
      { slug: 'offres-emploi', labelKey: 'categoryEmploiOffres', imageUrl: 'https://picsum.photos/seed/emploi-offres/200' },
      { slug: 'informatique-telecom', labelKey: 'categoryEmploiInformatique', imageUrl: 'https://picsum.photos/seed/emploi-it/200' },
      { slug: 'commercial-vente', labelKey: 'categoryEmploiCommercial', imageUrl: 'https://picsum.photos/seed/emploi-vente/200' },
      { slug: 'administratif-secretariat', labelKey: 'categoryEmploiAdministratif', imageUrl: 'https://picsum.photos/seed/emploi-admin/200' },
      { slug: 'sante', labelKey: 'categoryEmploiSante', imageUrl: 'https://picsum.photos/seed/emploi-sante/200' },
      { slug: 'industrie-btp', labelKey: 'categoryEmploiIndustrie', imageUrl: 'https://picsum.photos/seed/emploi-industrie/200' },
      { slug: 'hotellerie-restauration', labelKey: 'categoryEmploiHotellerie', imageUrl: 'https://picsum.photos/seed/emploi-hotel/200' },
    ]
  },
  { 
    slug: 'materiaux-equipement', 
    labelKey: 'categoryMateriauxEquipement', 
    apiName: 'Matériaux & Équipement', 
    color: 'from-yellow-700 to-amber-800',
    subCategories: [
      { slug: 'materiaux-construction', labelKey: 'categoryMateriauxConstruction', imageUrl: 'https://picsum.photos/seed/mat-construction/200' },
      { slug: 'equipement-industriel', labelKey: 'categoryMateriauxEquipementIndus', imageUrl: 'https://picsum.photos/seed/mat-indus/200' },
      { slug: 'materiel-agricole', labelKey: 'categoryMateriauxAgricole', imageUrl: 'https://picsum.photos/seed/mat-agri/200' },
      { slug: 'equipement-de-bureau', labelKey: 'categoryMateriauxBureau', imageUrl: 'https://picsum.photos/seed/mat-bureau/200' },
    ]
  },
  { 
    slug: 'alimentaires', 
    labelKey: 'categoryAlimentaires', 
    apiName: 'Alimentaires', 
    color: 'from-orange-500 to-red-600',
    subCategories: [
      { slug: 'produits-frais', labelKey: 'categoryAlimentairesFrais', imageUrl: 'https://picsum.photos/seed/food-frais/200' },
      { slug: 'epicerie-seche', labelKey: 'categoryAlimentairesEpicerie', imageUrl: 'https://picsum.photos/seed/food-epicerie/200' },
      { slug: 'boissons', labelKey: 'categoryAlimentairesBoissons', imageUrl: 'https://picsum.photos/seed/food-boissons/200' },
      { slug: 'produits-du-terroir', labelKey: 'categoryAlimentairesTerroir', imageUrl: 'https://picsum.photos/seed/food-terroir/200' },
    ]
  },
  { 
    slug: 'voyages', 
    labelKey: 'categoryVoyages', 
    apiName: 'Voyages', 
    color: 'from-teal-400 to-cyan-500',
    subCategories: [
      { slug: 'billets-avion', labelKey: 'categoryVoyagesBillets', imageUrl: 'https://picsum.photos/seed/voyage-billets/200' },
      { slug: 'sejours-hotels', labelKey: 'categoryVoyagesSejours', imageUrl: 'https://picsum.photos/seed/voyage-hotels/200' },
      { slug: 'voyages-organises', labelKey: 'categoryVoyagesOrganises', imageUrl: 'https://picsum.photos/seed/voyage-organises/200' },
      { slug: 'hajj-omra', labelKey: 'categoryVoyagesHajjOmra', imageUrl: 'https://picsum.photos/seed/voyage-hajj/200' },
    ]
  },
  { 
    slug: 'services', 
    labelKey: 'categoryServices', 
    apiName: 'Services', 
    color: 'from-amber-500 to-orange-600',
    subCategories: [
        { slug: 'services-entreprises', labelKey: 'categoryServicesEntreprises', imageUrl: 'https://picsum.photos/seed/serv-entreprise/200' },
        { slug: 'cours-formation', labelKey: 'categoryServicesCoursFormation', imageUrl: 'https://picsum.photos/seed/serv-formation/200' },
        { slug: 'reparation-maintenance', labelKey: 'categoryServicesReparation', imageUrl: 'https://picsum.photos/seed/serv-reparation/200' },
        { slug: 'evenements', labelKey: 'categoryServicesEvenements', imageUrl: 'https://picsum.photos/seed/serv-evenements/200' },
        { slug: 'sante-bien-etre', labelKey: 'categoryServicesSanteBienEtre', imageUrl: 'https://picsum.photos/seed/serv-sante/200' },
        { slug: 'transport-demenagement', labelKey: 'categoryServicesTransport', imageUrl: 'https://picsum.photos/seed/serv-transport/200' },
        { slug: 'services-domicile', labelKey: 'categoryServicesDomicile', imageUrl: 'https://picsum.photos/seed/serv-domicile/200' },
    ]
  },
];