

import { CategoryFilterConfig, FilterDefinition } from '../services/types';

// FIX: Explicitly typed `GENERIC_FILTERS` as `FilterDefinition[]` to ensure its
// properties conform to the correct types, preventing type inference errors
// when spreading it into other configurations.
const GENERIC_FILTERS: FilterDefinition[] = [
    {
        key: 'state',
        labelKey: 'filterState',
        type: 'accordion-group',
        subFilters: [{
            key: 'etat',
            labelKey: 'filterState',
            type: 'radio-group',
            options: [
                { labelKey: 'sellerAll', value: '' },
                { labelKey: 'stateNew', value: 'neuf' },
                { labelKey: 'stateUsed', value: 'occasion' },
                { labelKey: 'stateLikeNew', value: 'comme_neuf' },
            ]
        }]
    },
    {
        key: 'seller',
        labelKey: 'filterSellerType',
        type: 'accordion-group',
        subFilters: [{
            key: 'sellerType',
            labelKey: 'filterSellerType',
            type: 'radio-group',
            options: [
                { labelKey: 'sellerAll', value: '' },
                { labelKey: 'sellerParticulier', value: 'particulier' },
                { labelKey: 'sellerStore', value: 'store' },
            ]
        }]
    },
];

const PRICE_FILTER: FilterDefinition = {
    key: 'price',
    labelKey: 'filterPrice',
    type: 'accordion-group',
    subFilters: [{
        key: 'price',
        labelKey: 'filterPrice',
        type: 'range-number',
        minKey: 'priceMin',
        maxKey: 'priceMax'
    }]
};

const GENERIC_FILTERS_WITH_PRICE = [PRICE_FILTER, ...GENERIC_FILTERS];


export const CATEGORY_FILTERS: CategoryFilterConfig = {
    'automobiles-vehicules': [
        {
            key: 'category',
            labelKey: 'filterCategory',
            type: 'accordion-group',
            subFilters: [{
                key: 'subCategory',
                labelKey: 'filterCategory',
                type: 'radio-group',
                options: [
                    { labelKey: 'carCatVoitures', value: 'voitures' },
                    { labelKey: 'carCatUtilitaires', value: 'utilitaires' },
                    { labelKey: 'carCatMotosScooters', value: 'motos_scooters' },
                    { labelKey: 'carCatQuads', value: 'quads' },
                    { labelKey: 'carCatFourgon', value: 'fourgon' },
                    { labelKey: 'carCatCamion', value: 'camion' },
                    { labelKey: 'carCatBus', value: 'bus' },
                    { labelKey: 'carCatEngin', value: 'engin' },
                    { labelKey: 'carCatTracteurs', value: 'tracteurs' },
                    { labelKey: 'carCatRemorques', value: 'remorques' },
                    { labelKey: 'carCatBateauxBarques', value: 'bateaux_barques' },
                ],
            }]
        },
        {
            key: 'price',
            labelKey: 'filterPriceMillions',
            type: 'accordion-group',
            subFilters: [{
                key: 'price',
                labelKey: 'filterPriceMillions',
                type: 'range-number',
                minKey: 'priceMinMillions',
                maxKey: 'priceMaxMillions'
            }]
        },
        {
            key: 'exchange',
            labelKey: 'filterExchange',
            type: 'accordion-group',
            subFilters: [{
                key: 'echange',
                labelKey: 'filterExchange',
                type: 'radio-group',
                options: [
                    { labelKey: 'exchangeAccepts', value: 'accepte' },
                    { labelKey: 'exchangeOnly', value: 'uniquement' },
                    { labelKey: 'exchangeNone', value: 'aucun' },
                ]
            }]
        },
        {
            key: 'year',
            labelKey: 'filterYear',
            type: 'accordion-group',
            subFilters: [{
                key: 'year',
                labelKey: 'filterYear',
                type: 'range-number',
                minKey: 'yearMin',
                maxKey: 'yearMax'
            }]
        },
        {
            key: 'brandModel',
            labelKey: 'filterBrand', // Main accordion title
            type: 'accordion-group',
            subFilters: [
                { key: 'marque', labelKey: 'filterBrand', type: 'select' },
                { key: 'modele', labelKey: 'filterModel', type: 'select' }
            ]
        },
        {
            key: 'fuel',
            labelKey: 'filterFuel',
            type: 'accordion-group',
            subFilters: [{
                key: 'energie',
                labelKey: 'filterFuel',
                type: 'checkbox-group',
                options: [
                    { labelKey: 'fuelEssence', value: 'essence' },
                    { labelKey: 'fuelDiesel', value: 'diesel' },
                    { labelKey: 'fuelGpl', value: 'gpl' },
                    { labelKey: 'fuelHybrid', value: 'hybride' },
                    { labelKey: 'fuelElectric', value: 'electrique' },
                    { labelKey: 'fuelOther', value: 'autre' },
                ]
            }]
        },
        {
            key: 'gearbox',
            labelKey: 'filterTransmission',
            type: 'accordion-group',
            subFilters: [{
                key: 'boite',
                labelKey: 'filterTransmission',
                type: 'checkbox-group',
                options: [
                    { labelKey: 'gearboxManual', value: 'manuelle' },
                    { labelKey: 'gearboxAutomatic', value: 'automatique' },
                    { labelKey: 'gearboxSemiAutomatic', value: 'semi_automatique' },
                ]
            }]
        },
        {
            key: 'km',
            labelKey: 'filterKm',
            type: 'accordion-group',
            subFilters: [{
                key: 'km',
                labelKey: 'filterKm',
                type: 'range-number',
                minKey: 'kmMin',
                maxKey: 'kmMax'
            }]
        },
        {
            key: 'papers',
            labelKey: 'filterPapers',
            type: 'accordion-group',
            subFilters: [{
                key: 'papiers',
                labelKey: 'filterPapers',
                type: 'checkbox-group',
                options: [
                    { labelKey: 'papersCard', value: 'carte_grise_safia' },
                    { labelKey: 'papersLicense', value: 'licence_delai' },
                ]
            }]
        },
        {
            key: 'seller',
            labelKey: 'filterSellerType',
            type: 'accordion-group',
            subFilters: [{
                key: 'sellerType',
                labelKey: 'filterSellerType',
                type: 'radio-group',
                options: [
                    { labelKey: 'sellerAll', value: '' },
                    { labelKey: 'sellerParticulier', value: 'particulier' },
                    { labelKey: 'sellerStore', value: 'store' },
                ]
            }]
        },
    ],
    'immobilier': [
        {
            key: 'transaction',
            labelKey: 'filterTransactionType',
            type: 'accordion-group',
            subFilters: [{
                key: 'transactionType',
                labelKey: 'filterTransactionType',
                type: 'radio-group',
                options: [
                    { labelKey: 'transactionVente', value: 'vente' },
                    { labelKey: 'transactionLocation', value: 'location' },
                    { labelKey: 'transactionColocation', value: 'colocation' },
                    { labelKey: 'transactionLocationVacances', value: 'location_vacances' },
                ],
            }]
        },
        {
            key: 'property',
            labelKey: 'filterPropertyType',
            type: 'accordion-group',
            subFilters: [{
                key: 'propertyType',
                labelKey: 'filterPropertyType',
                type: 'radio-group',
                options: [
                    { labelKey: 'propertyAppartement', value: 'appartement' },
                    { labelKey: 'propertyMaison', value: 'maison' },
                    { labelKey: 'propertyVilla', value: 'villa' },
                    { labelKey: 'propertyTerrain', value: 'terrain' },
                    { labelKey: 'propertyBureau', value: 'bureau' },
                    { labelKey: 'propertyLocal', value: 'local' },
                ]
            }]
        },
        {
            key: 'price',
            labelKey: 'filterPrice',
            type: 'accordion-group',
            subFilters: [{
                key: 'price',
                labelKey: 'filterPrice',
                type: 'range-number',
                minKey: 'priceMin',
                maxKey: 'priceMax'
            }]
        },
        {
            key: 'surface',
            labelKey: 'filterSurface',
            type: 'accordion-group',
            subFilters: [{
                key: 'surface',
                labelKey: 'filterSurface',
                type: 'range-number',
                minKey: 'surfaceMin',
                maxKey: 'surfaceMax'
            }]
        },
        {
            key: 'rooms',
            labelKey: 'filterRooms',
            type: 'accordion-group',
            subFilters: [{
                key: 'rooms',
                labelKey: 'filterRooms',
                type: 'range-number',
                minKey: 'roomsMin',
                maxKey: 'roomsMax'
            }]
        },
        {
            key: 'furnished',
            labelKey: 'filterFurnished',
            type: 'accordion-group',
            subFilters: [{
                key: 'furnished',
                labelKey: 'filterFurnished',
                type: 'radio-group',
                options: [
                    { labelKey: 'sellerAll', value: '' },
                    { labelKey: 'furnishedYes', value: 'oui' },
                    { labelKey: 'furnishedNo', value: 'non' },
                ]
            }]
        }
    ],
    'telephones-accessoires': [
        {
            key: 'category',
            labelKey: 'filterCategory',
            type: 'accordion-group',
            subFilters: [{
                key: 'subCategory',
                labelKey: 'filterCategory',
                type: 'radio-group',
                options: [
                    { labelKey: 'categorySmartphones', value: 'smartphones' },
                    { labelKey: 'categoryTelephonesCellulaires', value: 'telephones-cellulaires' },
                    { labelKey: 'categoryTablettes', value: 'tablettes' },
                    { labelKey: 'categoryFixesFax', value: 'fixes-fax' },
                    { labelKey: 'categorySmartwatches', value: 'smartwatches' },
                    { labelKey: 'categoryProtectionAntichoc', value: 'protection-antichoc' },
                    { labelKey: 'categoryEcouteursSon', value: 'ecouteurs-son' },
                    { labelKey: 'categoryChargeursCables', value: 'chargeurs-cables' },
                    { labelKey: 'categorySupportsStabilisateurs', value: 'supports-stabilisateurs' },
                    { labelKey: 'categoryManettes', value: 'manettes' },
                    { labelKey: 'categoryVR', value: 'vr' },
                ],
            }]
        },
        ...GENERIC_FILTERS_WITH_PRICE
    ],
    'informatique': [
         {
            key: 'category',
            labelKey: 'filterCategory',
            type: 'accordion-group',
            subFilters: [{
                key: 'subCategory',
                labelKey: 'filterCategory',
                type: 'radio-group',
                options: [
                    { labelKey: 'categoryInformatiqueLaptops', value: 'ordinateurs-portables' },
                    { labelKey: 'categoryInformatiqueDesktops', value: 'ordinateurs-de-bureau' },
                    { labelKey: 'categoryInformatiqueComposants', value: 'composants' },
                    { labelKey: 'categoryInformatiqueStockage', value: 'stockage' },
                    { labelKey: 'categoryInformatiquePeripheriques', value: 'peripheriques' },
                    { labelKey: 'categoryInformatiqueReseaux', value: 'reseaux' },
                ],
            }]
        },
        ...GENERIC_FILTERS_WITH_PRICE
    ],
    'vetements-mode': [
        {
            key: 'category',
            labelKey: 'filterCategory',
            type: 'accordion-group',
            subFilters: [{
                key: 'subCategory',
                labelKey: 'filterCategory',
                type: 'radio-group',
                options: [
                    { labelKey: 'categoryVetementsHomme', value: 'vetements-homme' },
                    { labelKey: 'categoryVetementsFemme', value: 'vetements-femme' },
                    { labelKey: 'categoryVetementsEnfant', value: 'vetements-enfant' },
                    { labelKey: 'categoryChaussures', value: 'chaussures' },
                    { labelKey: 'categoryMontresBijoux', value: 'montres-bijoux' },
                    { labelKey: 'categorySacsAccessoires', value: 'sacs-accessoires' },
                ],
            }]
        },
         {
            key: 'price',
            labelKey: 'filterPrice',
            type: 'accordion-group',
            subFilters: [{
                key: 'price',
                labelKey: 'filterPrice',
                type: 'range-number',
                minKey: 'priceMin',
                maxKey: 'priceMax'
            }]
        },
        ...GENERIC_FILTERS
    ],
    // Add configurations for all other categories to prevent empty filters
    'boutiques': GENERIC_FILTERS_WITH_PRICE,
    'pieces-detachees': GENERIC_FILTERS_WITH_PRICE,
    'electromenager-electronique': GENERIC_FILTERS_WITH_PRICE,
    'sante-beaute': GENERIC_FILTERS_WITH_PRICE,
    'meubles-maison': GENERIC_FILTERS_WITH_PRICE,
    'loisirs-divertissements': GENERIC_FILTERS_WITH_PRICE,
    'sport': GENERIC_FILTERS_WITH_PRICE,
    'materiaux-equipement': GENERIC_FILTERS_WITH_PRICE,
    'alimentaires': GENERIC_FILTERS_WITH_PRICE,
    'voyages': GENERIC_FILTERS_WITH_PRICE,
    'emploi': GENERIC_FILTERS,
    'services': GENERIC_FILTERS,
};