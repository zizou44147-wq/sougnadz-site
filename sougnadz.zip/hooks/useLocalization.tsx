

import React, { createContext, useState, useContext, ReactNode, useCallback } from 'react';
import { Language } from '../services/types';

const translations = {
    fr: {
        // Header
        home: 'Accueil',
        categories: 'Catégories',
        blog: 'Blog',
        help: 'Aide',
        publishAd: 'Publier une annonce',
        login: 'Connexion',
        refreshPage: 'Actualiser la page',
        profile: 'Profil',
        myAds: 'Mes annonces',
        logout: 'Se déconnecter',
        favorites: 'Favoris',

        // Auth Modal
        continueWithGoogle: 'Continuer avec Google',
        continueWithFacebook: 'Continuer avec Facebook',

        // Hero
        heroTitle: 'Découvrez les meilleures offres en Algérie',
        heroSubtitle: 'Vendez et achetez facilement dans toutes les wilayas algériennes',
        publishAdFree: 'Publier une annonce gratuitement',
        searchPlaceholder: 'Rechercher une offre...',
        smartSearchPlaceholder: 'Recherche IA : "Clio 4 bon état à Alger"...',
        allWilayas: 'Toutes les wilayas',
        selectCommune: 'Choisir une commune',

        // Sections
        latestCarDeals: 'Dernières offres automobiles',
        seeAllOffers: 'Voir toutes les offres',
        
        // Main Category Keys
        categoryBoutiques: 'Boutiques',
        categoryImmobilier: 'Immobilier',
        categoryAutomobilesVehicules: 'Automobiles & Véhicules',
        categoryPiecesDetachees: 'Pièces détachées',
        categoryTelephonesAccessoires: 'Téléphones & Accessoires',
        categoryInformatique: 'Informatique',
        categoryElectromenagerElectronique: 'Électroménager & Électronique',
        categoryVetementsMode: 'Vêtements & Mode',
        categorySanteBeaute: 'Santé & Beauté',
        categoryMeublesMaison: 'Meubles & Maison',
        categoryLoisirsDivertissements: 'Loisirs & Divertissements',
        categorySport: 'Sport',
        // FIX: Renamed `categoryEmmobil` to `categoryEmploi` to align with usage in the app.
        categoryEmploi: 'Emploi',
        categoryMateriauxEquipement: 'Matériaux & Équipement',
        categoryAlimentaires: 'Alimentaires',
        categoryVoyages: 'Voyages',
        categoryServices: 'Services',
        demandesEmploi: 'Demandes d\'emploi',
        actionsCaritatives: 'Actions caritatives',
        
        // Sub-Category Keys
        categoryToutesLesCategories: 'Toutes les catégories',
        // -- Boutiques
        categoryBoutiquesInformatique: 'Boutiques Informatique',
        categoryBoutiquesTelephonie: 'Boutiques Téléphonie',
        categoryBoutiquesElectromenager: 'Boutiques Électroménager',
        categoryBoutiquesMeubles: 'Boutiques Meubles',
        categoryBoutiquesVetements: 'Boutiques Vêtements',
        categoryBoutiquesCosmetiques: 'Boutiques Cosmétiques',
        // -- Immobilier
        categoryImmobilierVente: 'Vente',
        categoryImmobilierLocation: 'Location',
        categoryImmobilierColocation: 'Colocation',
        categoryImmobilierLocationVacances: 'Location vacances',
        categoryImmobilierBureauxCommerces: 'Bureaux & Commerces',
        // -- Pièces détachées
        categoryPiecesPneusJantes: 'Pneus & Jantes',
        categoryPiecesMoteursBoites: 'Moteurs & Boites',
        categoryPiecesCarrosserie: 'Carrosserie',
        categoryPiecesEclairage: 'Éclairage & Optiques',
        categoryPiecesInterieur: 'Intérieur & Son',
        // -- Téléphones
        categorySmartphones: 'Smartphones',
        categoryTelephonesCellulaires: 'Téléphones cellulaires',
        categoryTablettes: 'Tablettes',
        categoryFixesFax: 'Fixes & Fax',
        categorySmartwatches: 'Smartwatches',
        categoryProtectionAntichoc: 'Protection & Antichoc',
        categoryEcouteursSon: 'Ecouteurs & Son',
        categoryChargeursCables: 'Chargeurs & Câbles',
        categorySupportsStabilisateurs: 'Supports & Stabilisateurs',
        categoryManettes: 'Manettes',
        categoryVR: 'VR',
        // -- Informatique
        categoryInformatiqueLaptops: 'Ordinateurs portables',
        categoryInformatiqueDesktops: 'Ordinateurs de bureau',
        categoryInformatiqueComposants: 'Composants',
        categoryInformatiqueStockage: 'Stockage',
        categoryInformatiquePeripheriques: 'Périphériques',
        categoryInformatiqueReseaux: 'Réseaux',
        // -- Électroménager & Électronique
        categoryElectroGros: 'Gros Électroménager',
        categoryElectroPetit: 'Petit Électroménager',
        categoryElectroTvSon: 'TV & Son',
        categoryElectroPhotoVideo: 'Photo & Vidéo',
        categoryElectroChauffageClim: 'Chauffage & Climatisation',
        // -- Vêtements & Mode
        categoryVetementsHomme: 'Vêtements Homme',
        categoryVetementsFemme: 'Vêtements Femme',
        categoryVetementsEnfant: 'Vêtements Enfant',
        categoryChaussures: 'Chaussures',
        categoryMontresBijoux: 'Montres & Bijoux',
        categorySacsAccessoires: 'Sacs & Accessoires',
        // -- Santé & Beauté
        categorySanteParfums: 'Parfums',
        categorySanteMaquillage: 'Maquillage',
        categorySanteSoins: 'Soins du corps & visage',
        categorySanteMaterielMedical: 'Matériel Médical',
        categorySanteComplements: 'Compléments Alimentaires',
        // -- Meubles & Maison
        categoryMeublesSalons: 'Salons & Séjours',
        categoryMeublesChambres: 'Chambres à coucher',
        categoryMeublesCuisines: 'Cuisines & Salles de bain',
        categoryMeublesDecoration: 'Décoration & Luminaires',
        categoryMeublesJardin: 'Jardin & Extérieur',
        // -- Loisirs & Divertissements
        categoryLoisirsLivres: 'Livres & Magazines',
        categoryLoisirsMusique: 'Musique & Instruments',
        categoryLoisirsFilms: 'Films & Séries',
        categoryLoisirsJeux: 'Jeux & Jouets',
        categoryLoisirsCollections: 'Collections',
        categoryLoisirsArt: 'Art & Antiquités',
        // -- Sport
        categorySportVelos: 'Vélos & Cyclisme',
        categorySportFitness: 'Fitness & Musculation',
        categorySportCollectifs: 'Sports Collectifs',
        categorySportCombat: 'Sports de Combat',
        categorySportNautiques: 'Sports Nautiques',
        // -- Emploi
        categoryEmploiOffres: 'Offres d\'emploi',
        categoryEmploiInformatique: 'Informatique & Télécom',
        categoryEmploiCommercial: 'Commercial & Vente',
        categoryEmploiAdministratif: 'Administratif & Secrétariat',
        categoryEmploiSante: 'Santé',
        categoryEmploiIndustrie: 'Industrie & BTP',
        categoryEmploiHotellerie: 'Hôtellerie & Restauration',
        // -- Matériaux & Équipement
        categoryMateriauxConstruction: 'Matériaux de Construction',
        categoryMateriauxEquipementIndus: 'Équipement Industriel',
        categoryMateriauxAgricole: 'Matériel Agricole',
        categoryMateriauxBureau: 'Équipement de Bureau',
        // -- Alimentaires
        categoryAlimentairesFrais: 'Produits Frais',
        categoryAlimentairesEpicerie: 'Épicerie Sèche',
        categoryAlimentairesBoissons: 'Boissons',
        categoryAlimentairesTerroir: 'Produits du Terroir',
        // -- Voyages
        categoryVoyagesBillets: 'Billets d\'avion',
        categoryVoyagesSejours: 'Séjours & Hôtels',
        categoryVoyagesOrganises: 'Voyages Organisés',
        categoryVoyagesHajjOmra: 'Hajj & Omra',
        // -- Services
        categoryServicesEntreprises: 'Services aux entreprises',
        categoryServicesCoursFormation: 'Cours & Formation',
        categoryServicesReparation: 'Réparation & Maintenance',
        categoryServicesEvenements: 'Événements',
        categoryServicesSanteBienEtre: 'Santé & Bien-être',
        categoryServicesTransport: 'Transport & Déménagement',
        categoryServicesDomicile: 'Services à domicile',

        // Listing Card
        sendMessage: 'Envoyer un message',
        contactSeller: 'Contacter le vendeur',
        online: 'En ligne',
        offline: 'Hors ligne',
        addToFavorites: 'Ajouter aux favoris',
        removeFromFavorites: 'Retirer des favoris',
        call: 'Appeler',
        comment: 'Commenter',
        compare: 'Comparer',
        report: 'Signaler',

        // Time Ago
        justNow: "à l'instant",
        minutesAgo: 'il y a {count} min',
        hoursAgo: 'il y a {count} h',
        yesterday: 'Hier',
        daysAgo: 'il y a {count} jours',


        // Page Titles & Content
        listingDetails: 'Détails de l\'annonce',
        description: 'Description',
        sellerInformation: 'Informations sur le vendeur',
        reportAd: 'Signaler cette annonce',
        noListingFound: 'Annonce non trouvée',
        noListingsInCategory: 'Aucune annonce trouvée pour cette catégorie et ces filtres.',
        noFavorites: "Vous n'avez pas encore ajouté d'annonces à vos favoris.",
        showPhoneNumber: 'Afficher le numéro',
        contactOnWhatsApp: 'Contacter sur WhatsApp',
        chatWithSeller: 'Discuter avec le vendeur',
        chatModalTitle: 'Discuter avec {sellerName}',
        typeYourMessage: 'Tapez votre message...',
        send: 'Envoyer',
        backToResults: 'Retour aux résultats',
        
        // Report Ad Modal
        reportAdTitle: "Signaler l'annonce",
        reportAdReason: 'Motif du signalement',
        reportReasonFraud: 'Fraude / Arnaque',
        reportReasonInappropriate: 'Contenu inapproprié / Illégal',
        reportReasonDuplicate: 'Annonce en double',
        reportReasonSold: 'Déjà vendu / Indisponible',
        reportReasonWrongCategory: 'Mauvaise catégorie',
        reportReasonOther: 'Autre (précisez)',
        reportDetails: 'Détails supplémentaires (optionnel)',
        reportDetailsPlaceholder: "Donnez-nous plus d'informations...",
        submitReport: 'Envoyer le signalement',
        reportSentSuccess: 'Signalement envoyé !',
        reportSentMessage: 'Merci de nous aider à maintenir la qualité de notre communauté.',


        // Price Types
        priceFixe: 'Prix fixe',
        priceNegociable: 'Négociable',
        priceOffre: 'Offre',
        
        // Page Titles & Content
        categoryPageTitle: 'Toutes les catégories',
        categoryPageDescription: 'Parcourez toutes les catégories d\'annonces disponibles sur sougnadz.com.',
        blogPageTitle: 'Blog',
        blogPageDescription: 'Lisez nos derniers articles et conseils.',
        helpPageTitle: 'Centre d\'aide',
        helpPageDescription: 'Trouvez des réponses à vos questions ici.',
        profilePageTitle: 'Mon Profil',
        profilePageDescription: 'Gérez les informations de votre profil ici.',
        myAdsPageTitle: 'Mes Annonces',
        myAdsPageDescription: 'Gérez toutes vos annonces publiées.',
        recentlyViewed: 'Vu récemment',

        // Search
        searchButton: 'Rechercher',
        searchResults: 'Résultats de recherche',
        noResultsFound: 'Aucun résultat trouvé',
        tryDifferentKeywords: 'Essayez des mots-clés différents ou élargissez votre recherche.',

        // Filters & Details
        filterResults: 'Filtrer les résultats',
        advancedFilters: 'Filtres avancés',
        applyFilters: 'Appliquer',
        resetFilters: 'Réinitialiser',
        filterCategory: 'Catégorie',
        filterWilaya: 'Wilaya',
        filterPrice: 'Prix',
        filterPriceMillions: 'Prix (millions DA)',
        filterExchange: 'Échange',
        filterYear: 'Année',
        filterBrand: 'Marque',
        filterModel: 'Modèle',
        filterFuel: 'Énergie',
        filterTransmission: 'Boite',
        filterKm: 'Kilométrage',
        filterPapers: 'Papiers',
        filterSellerType: 'Type de vendeur',
        filterMin: 'Min',
        filterMax: 'Max',
        sortBy: 'Trier par',
        sortRelevance: 'Pertinence',
        sortDate: 'Date d\'ajout',
        sortPriceAsc: 'Prix : Croissant',
        sortPriceDesc: 'Prix : Décroissant',
        engine: 'Moteur',
        trim: 'Finition',
        // -- Immobilier Filters
        filterTransactionType: 'Type de transaction',
        filterPropertyType: 'Type de bien',
        filterSurface: 'Surface (m²)',
        filterRooms: 'Nombre de pièces',
        filterFurnished: 'Meublé',
        transactionVente: 'Vente',
        transactionLocation: 'Location',
        transactionColocation: 'Colocation',
        transactionLocationVacances: 'Location vacances',
        propertyAppartement: 'Appartement',
        propertyMaison: 'Maison',
        propertyVilla: 'Villa',
        propertyTerrain: 'Terrain',
        propertyBureau: 'Bureau',
        propertyLocal: 'Local commercial',
        furnishedYes: 'Oui',
        furnishedNo: 'Non',
        surface: 'Surface',
        rooms: 'Pièces',
        furnishedLabel: 'Meublé',
        // -- General Filters
        filterState: 'État',
        stateNew: 'Neuf',
        stateUsed: 'Occasion',
        stateLikeNew: 'Comme neuf',

        // Car Sub-Categories
        carCatVoitures: 'Voitures',
        carCatUtilitaires: 'Utilitaires',
        carCatMotosScooters: 'Motos & Scooters',
        carCatQuads: 'Quads',
        carCatFourgon: 'Fourgon',
        carCatCamion: 'Camion',
        carCatBus: 'Bus',
        carCatEngin: 'Engin',
        carCatTracteurs: 'Tracteurs',
        carCatRemorques: 'Remorques',
        carCatBateauxBarques: 'Bateaux & Barques',

        // Exchange Options
        exchangeAccepts: "Accepte l'échange",
        exchangeOnly: 'Échange uniquement',
        exchangeNone: "Pas d'échanges",

        // Fuel Options
        fuelEssence: 'Essence',
        fuelDiesel: 'Diesel',
        fuelGpl: 'GPL',
        fuelHybrid: 'Hybride',
        fuelElectric: 'Électrique',
        fuelOther: 'Autre',

        // Gearbox Options
        gearboxManual: 'Manuelle',
        gearboxAutomatic: 'Automatique',
        gearboxSemiAutomatic: 'Semi automatique',

        // Papers Options
        papersCard: 'Carte grise / Safia',
        papersLicense: 'Licence / Délai',
        
        // Seller Type Options
        sellerParticulier: 'Particuliers',
        sellerStore: 'Stores',
        sellerAll: 'Tous',
        
        // Contact Modal
        contactModalTitle: 'Contacter le vendeur',
        yourName: 'Votre nom',
        yourEmail: 'Votre email',
        yourPhone: 'Votre téléphone (Optionnel)',
        message: 'Message',
        sendMessageButton: 'Envoyer le message',
        messageSentSuccess: 'Message envoyé avec succès !',

        // Donation Feature
        supportCause: 'Soutenir cette cause',
        donateWithBaridiMob: 'Faire un don avec BaridiMob',
        donationInfoTitle: 'Informations pour le don',
        scanQrCode: 'Scannez le code QR avec votre application',
        orUseCcp: 'Ou utilisez le compte CCP suivant',
        accountHolder: 'Titulaire du compte',
        accountNumber: 'Numéro de compte',
        close: 'Fermer',
        
        // Post Ad Flow
        postAdTitle: 'Que voulez-vous vendre sur',
        postAdSubtitle: 'Choisissez la catégorie appropriée pour votre annonce, puis nous vous guiderons vers le formulaire détaillé.',
        postAdGuidance: 'Vous pouvez toujours modifier la catégorie et les informations plus tard depuis votre page de gestion des annonces.',
        postAdFormTitle: 'Publier une annonce dans',
        formComingSoon: 'Le formulaire détaillé pour cette catégorie sera bientôt disponible.',
        backToCategories: 'Retour au choix des catégories',
        adTitle: 'Titre de l\'annonce',
        adTitlePlaceholder: 'Ex: Belle villa à vendre',
        adPrice: 'Prix',
        adPricePlaceholder: 'Ex: 12000000',
        adImages: 'Images',
        adImagesGuidance: 'Ajoutez jusqu\'à 5 images. La première sera la principale.',
        adUpload: 'Télécharger',
        adDescription: 'Description',
        adDescriptionPlaceholder: 'Décrivez votre bien en détail...',
        adLocation: 'Localisation',
        postYourAd: 'Publier votre annonce',
        adDetails: "Détails de l'annonce",
        generateWithAI: "Générer avec l'IA",
        generating: 'Génération...',
        aiDescriptionHelper: 'Cliquez pour générer une description attractive basée sur les détails que vous avez fournis.',
        suggestPrice: 'Suggérer un prix',
        suggesting: 'Suggestion...',
        suggestedPriceRange: 'Prix suggéré',
        aiPriceHelper: 'Obtenez une estimation de prix basée sur des annonces similaires.',
        from: 'De',
        to: 'À',

        // Post Ad Wizard
        step1: 'Informations',
        step2: 'Détails',
        step3: 'Médias',
        step4: 'Révision',
        nextStep: 'Suivant',
        prevStep: 'Précédent',
        adTitleRequired: 'Le titre de l\'annonce est obligatoire.',
        descriptionRequired: 'La description est obligatoire.',
        mediaPriceLocationRequired: 'Veuillez ajouter au moins une image et spécifier le prix et la localisation.',
        reviewDetails: 'Vérifiez les détails de votre annonce',


        // Footer
        createStore: 'Créez une boutique',
        advertise: 'Publicité sur sougnadz.com',
        howToPost: 'Comment annoncer ?',
        contactUs: 'Contactez-nous',
        privacyPolicy: 'Politique de confidentialité',
        terms: 'Conditions d\'utilisation',
        rightsReserved: 'Tous les droits sont réservés à sougnadz.com.'
    },
    ar: {
        // Header
        home: 'الرئيسية',
        categories: 'الفئات',
        blog: 'المدونة',
        help: 'مساعدة',
        publishAd: 'أضف إعلان',
        login: 'تسجيل الدخول',
        refreshPage: 'تحديث الصفحة',
        profile: 'ملفي الشخصي',
        myAds: 'إعلاناتي',
        logout: 'تسجيل الخروج',
        favorites: 'المفضلة',

        // Auth Modal
        continueWithGoogle: 'المتابعة باستخدام جوجل',
        continueWithFacebook: 'المتابعة باستخدام فيسبوك',
        
        // Hero
        heroTitle: 'اكتشف أفضل العروض في الجزائر',
        heroSubtitle: 'بيع و شري بسهولة في كل ولاية جزائرية',
        publishAdFree: 'أضف إعلانك مجاناً',
        searchPlaceholder: 'ابحث عن عرض...',
        smartSearchPlaceholder: 'ابحث بالذكاء الاصطناعي: "كليو 4 حالة جيدة في العاصمة"...',
        allWilayas: 'كل الولايات',
        selectCommune: 'اختر بلدية',

        // Sections
        latestCarDeals: 'أحدث عروض السيارات',
        seeAllOffers: 'عرض كل العروض',

        // Main Category Keys
        categoryBoutiques: 'محلات',
        categoryImmobilier: 'العقارات',
        categoryAutomobilesVehicules: 'سيارات و مركبات',
        categoryPiecesDetachees: 'قطع الغيار',
        categoryTelephonesAccessoires: 'الهواتف و الإكسسوارات',
        categoryInformatique: 'الإعلام الآلي',
        categoryElectromenagerElectronique: 'الكهرومنزلي و الإلكترونيك',
        categoryVetementsMode: 'الملابس و الموضة',
        categorySanteBeaute: 'الصحة و الجمال',
        categoryMeublesMaison: 'الأثاث و المنزل',
        categoryLoisirsDivertissements: 'الترفيه و الهوايات',
        categorySport: 'الرياضة',
        categoryEmploi: 'الوظائف',
        categoryMateriauxEquipement: 'مواد و معدات',
        categoryAlimentaires: 'مواد غذائية',
        categoryVoyages: 'السفر',
        categoryServices: 'الخدمات',
        demandesEmploi: 'طلبات عمل',
        actionsCaritatives: 'أعمال خيرية',
        
        // Sub-Category Keys
        categoryToutesLesCategories: 'كل الفئات',
        // -- Boutiques
        categoryBoutiquesInformatique: 'محلات إعلام آلي',
        categoryBoutiquesTelephonie: 'محلات هواتف',
        categoryBoutiquesElectromenager: 'محلات كهرومنزلي',
        categoryBoutiquesMeubles: 'محلات أثاث',
        categoryBoutiquesVetements: 'محلات ملابس',
        categoryBoutiquesCosmetiques: 'محلات مستحضرات تجميل',
        // -- Immobilier
        categoryImmobilierVente: 'بيع',
        categoryImmobilierLocation: 'كراء',
        categoryImmobilierColocation: 'مشاركة سكن',
        categoryImmobilierLocationVacances: 'كراء للعطل',
        categoryImmobilierBureauxCommerces: 'مكاتب و محلات',
        // -- Pièces détachées
        categoryPiecesPneusJantes: 'عجلات و إطارات',
        categoryPiecesMoteursBoites: 'محركات و علب سرعة',
        categoryPiecesCarrosserie: 'هيكل السيارة',
        categoryPiecesEclairage: 'إضاءة و بصريات',
        categoryPiecesInterieur: 'داخلي و صوت',
        // -- Téléphones
        categorySmartphones: 'هواتف ذكية',
        categoryTelephonesCellulaires: 'هواتف خلوية',
        categoryTablettes: 'أجهزة لوحية',
        categoryFixesFax: 'هواتف ثابتة وفاكس',
        categorySmartwatches: 'ساعات ذكية',
        categoryProtectionAntichoc: 'حماية وواقيات',
        categoryEcouteursSon: 'سماعات وصوتيات',
        categoryChargeursCables: 'شواحن وكابلات',
        categorySupportsStabilisateurs: 'حوامل ومثبتات',
        categoryManettes: 'أذرع تحكم',
        categoryVR: 'واقع افتراضي',
        // -- Informatique
        categoryInformatiqueLaptops: 'حواسيب محمولة',
        categoryInformatiqueDesktops: 'حواسيب مكتبية',
        categoryInformatiqueComposants: 'مكونات',
        categoryInformatiqueStockage: 'تخزين',
        categoryInformatiquePeripheriques: 'ملحقات',
        categoryInformatiqueReseaux: 'شبكات',
        // -- Électroménager & Électronique
        categoryElectroGros: 'أجهزة كهرومنزلية كبيرة',
        categoryElectroPetit: 'أجهزة كهرومنزلية صغيرة',
        categoryElectroTvSon: 'تلفزيون و صوت',
        categoryElectroPhotoVideo: 'تصوير و فيديو',
        categoryElectroChauffageClim: 'تدفئة و تكييف',
        // -- Vêtements & Mode
        categoryVetementsHomme: 'ملابس رجال',
        categoryVetementsFemme: 'ملابس نساء',
        categoryVetementsEnfant: 'ملابس أطفال',
        categoryChaussures: 'أحذية',
        categoryMontresBijoux: 'ساعات و مجوهرات',
        categorySacsAccessoires: 'حقائب و إكسسوارات',
        // -- Santé & Beauté
        categorySanteParfums: 'عطور',
        categorySanteMaquillage: 'مكياج',
        categorySanteSoins: 'عناية بالجسم والوجه',
        categorySanteMaterielMedical: 'معدات طبية',
        categorySanteComplements: 'مكملات غذائية',
        // -- Meubles & Maison
        categoryMeublesSalons: 'غرف جلوس و معيشة',
        categoryMeublesChambres: 'غرف نوم',
        categoryMeublesCuisines: 'مطابخ و حمامات',
        categoryMeublesDecoration: 'ديكور و إضاءة',
        categoryMeublesJardin: 'حديقة و مساحات خارجية',
        // -- Loisirs & Divertissements
        categoryLoisirsLivres: 'كتب و مجلات',
        categoryLoisirsMusique: 'موسيقى و آلات',
        categoryLoisirsFilms: 'أفلام و مسلسلات',
        categoryLoisirsJeux: 'ألعاب و دمى',
        categoryLoisirsCollections: 'مجموعات نادرة',
        categoryLoisirsArt: 'فن و تحف',
        // -- Sport
        categorySportVelos: 'دراجات هوائية',
        categorySportFitness: 'لياقة بدنية و كمال أجسام',
        categorySportCollectifs: 'رياضات جماعية',
        categorySportCombat: 'رياضات قتالية',
        categorySportNautiques: 'رياضات مائية',
        // -- Emploi
        categoryEmploiOffres: 'عروض عمل',
        categoryEmploiInformatique: 'إعلام آلي واتصالات',
        categoryEmploiCommercial: 'تجارة و مبيعات',
        categoryEmploiAdministratif: 'إدارة و سكرتارية',
        categoryEmploiSante: 'صحة',
        categoryEmploiIndustrie: 'صناعة و بناء',
        categoryEmploiHotellerie: 'فندقة و إطعام',
        // -- Matériaux & Équipement
        categoryMateriauxConstruction: 'مواد بناء',
        categoryMateriauxEquipementIndus: 'معدات صناعية',
        categoryMateriauxAgricole: 'عتاد فلاحي',
        categoryMateriauxBureau: 'تجهيزات مكتبية',
        // -- Alimentaires
        categoryAlimentairesFrais: 'منتجات طازجة',
        categoryAlimentairesEpicerie: 'مواد غذائية جافة',
        categoryAlimentairesBoissons: 'مشروبات',
        categoryAlimentairesTerroir: 'منتجات محلية',
        // -- Voyages
        categoryVoyagesBillets: 'تذاكر طيران',
        categoryVoyagesSejours: 'إقامات و فنادق',
        categoryVoyagesOrganises: 'رحلات منظمة',
        categoryVoyagesHajjOmra: 'حج و عمرة',
        // -- Services
        categoryServicesEntreprises: 'خدمات للشركات',
        categoryServicesCoursFormation: 'دروس و تكوين',
        categoryServicesReparation: 'تصليح و صيانة',
        categoryServicesEvenements: 'مناسبات',
        categoryServicesSanteBienEtre: 'صحة و رفاهية',
        categoryServicesTransport: 'نقل و ترحيل',
        categoryServicesDomicile: 'خدمات منزلية',

        // Listing Card
        sendMessage: 'إرسال رسالة',
        contactSeller: 'التواصل مع البائع',
        online: 'متصل الآن',
        offline: 'غير متصل',
        addToFavorites: 'إضافة إلى المفضلة',
        removeFromFavorites: 'إزالة من المفضلة',
        call: 'اتصل',
        comment: 'علّق',
        compare: 'قارن',
        report: 'إبلاغ',

        // Time Ago
        justNow: 'الآن',
        minutesAgo: 'منذ {count} د',
        hoursAgo: 'منذ {count} س',
        yesterday: 'أمس',
        daysAgo: 'منذ {count} أيام',
        
        // Page Titles & Content
        listingDetails: 'تفاصيل الإعلان',
        description: 'الوصف',
        sellerInformation: 'معلومات البائع',
        reportAd: 'الإبلاغ عن هذا الإعلان',
        noListingFound: 'الإعلان غير موجود',
        noListingsInCategory: 'لم يتم العثور على إعلانات لهذه الفئة والفلاتر.',
        noFavorites: 'لم تقم بإضافة أي إعلانات إلى المفضلة بعد.',
        showPhoneNumber: 'إظهار الرقم',
        contactOnWhatsApp: 'التواصل عبر واتساب',
        chatWithSeller: 'الدردشة مع البائع',
        chatModalTitle: 'الدردشة مع {sellerName}',
        typeYourMessage: 'اكتب رسالتك...',
        send: 'إرسال',
        backToResults: 'العودة إلى النتائج',

        // Report Ad Modal
        reportAdTitle: 'الإبلاغ عن الإعلان',
        reportAdReason: 'سبب الإبلاغ',
        reportReasonFraud: 'احتيال / نصب',
        reportReasonInappropriate: 'محتوى غير لائق / غير قانوني',
        reportReasonDuplicate: 'إعلان مكرر',
        reportReasonSold: 'تم بيعه / غير متوفر',
        reportReasonWrongCategory: 'فئة خاطئة',
        reportReasonOther: 'أخرى (حدد)',
        reportDetails: 'تفاصيل إضافية (اختياري)',
        reportDetailsPlaceholder: 'أعطنا المزيد من المعلومات...',
        submitReport: 'إرسال البلاغ',
        reportSentSuccess: 'تم إرسال البلاغ!',
        reportSentMessage: 'شكرًا لمساعدتنا في الحفاظ على جودة مجتمعنا.',

        // Price Types
        priceFixe: 'سعر ثابت',
        priceNegociable: 'قابل للتفاوض',
        priceOffre: 'سومة',
        
        // Page Titles & Content
        categoryPageTitle: 'جميع الفئات',
        categoryPageDescription: 'تصفح جميع فئات الإعلانات المتوفرة على sougnadz.com.',
        blogPageTitle: 'المدونة',
        blogPageDescription: 'اقرأ أحدث مقالاتنا ونصائحنا.',
        helpPageTitle: 'مركز المساعدة',
        helpPageDescription: 'ابحث عن إجابات لأسئلتك هنا.',
        profilePageTitle: 'ملفي الشخصي',
        profilePageDescription: 'إدارة معلومات ملفك الشخصي هنا.',
        myAdsPageTitle: 'إعلاناتي',
        myAdsPageDescription: 'إدارة جميع إعلاناتك المنشورة.',
        recentlyViewed: 'شوهدت مؤخراً',
        
        // Search
        searchButton: 'بحث',
        searchResults: 'نتائج البحث',
        noResultsFound: 'لم يتم العثور على نتائج',
        tryDifferentKeywords: 'جرّب كلمات مفتاحية مختلفة أو وسّع نطاق بحثك.',

        // Filters & Details
        filterResults: 'تصفية النتائج',
        advancedFilters: 'فلاتر متقدمة',
        applyFilters: 'تطبيق',
        resetFilters: 'إعادة تعيين',
        filterCategory: 'الفئة',
        filterWilaya: 'الولاية',
        filterPrice: 'السعر',
        filterPriceMillions: 'السعر (ملايين دج)',
        filterExchange: 'التبادل',
        filterYear: 'السنة',
        filterBrand: 'الماركة',
        filterModel: 'الموديل',
        filterFuel: 'الوقود',
        filterTransmission: 'علبة السرعات',
        filterKm: 'المسافة المقطوعة',
        filterPapers: 'الأوراق',
        filterSellerType: 'نوع البائع',
        filterMin: 'أدنى',
        filterMax: 'أقصى',
        sortBy: 'الترتيب حسب',
        sortRelevance: 'الصلة',
        sortDate: 'تاريخ الإضافة',
        sortPriceAsc: 'السعر: تصاعدي',
        sortPriceDesc: 'السعر: تنازلي',
        engine: 'المحرك',
        trim: 'التجهيزات',
        // -- Immobilier Filters
        filterTransactionType: 'نوع الصفقة',
        filterPropertyType: 'نوع العقار',
        filterSurface: 'المساحة (م²)',
        filterRooms: 'عدد الغرف',
        filterFurnished: 'مفروش',
        transactionVente: 'بيع',
        transactionLocation: 'كراء',
        transactionColocation: 'مشاركة سكن',
        transactionLocationVacances: 'كراء للعطل',
        propertyAppartement: 'شقة',
        propertyMaison: 'منزل',
        propertyVilla: 'فيلا',
        propertyTerrain: 'قطعة أرض',
        propertyBureau: 'مكتب',
        propertyLocal: 'محل تجاري',
        furnishedYes: 'نعم',
        furnishedNo: 'لا',
        surface: 'المساحة',
        rooms: 'الغرف',
        furnishedLabel: 'مفروش',
        // -- General Filters
        filterState: 'الحالة',
        stateNew: 'جديد',
        stateUsed: 'مستعمل',
        stateLikeNew: 'شبه جديد',


        // Car Sub-Categories
        carCatVoitures: 'سيارات',
        carCatUtilitaires: 'نفعية',
        carCatMotosScooters: 'دراجات نارية',
        carCatQuads: 'كواد',
        carCatFourgon: 'فورغون',
        carCatCamion: 'شاحنات',
        carCatBus: 'حافلات',
        carCatEngin: 'آليات',
        carCatTracteurs: 'جرارات',
        carCatRemorques: 'مقطورات',
        carCatBateauxBarques: 'قوارب',

        // Exchange Options
        exchangeAccepts: 'يقبل التبادل',
        exchangeOnly: 'تبادل فقط',
        exchangeNone: 'لا يقبل التبادل',

        // Fuel Options
        fuelEssence: 'بنزين',
        fuelDiesel: 'ديزل',
        fuelGpl: 'غاز',
        fuelHybrid: 'هجين',
        fuelElectric: 'كهربائي',
        fuelOther: 'آخر',

        // Gearbox Options
        gearboxManual: 'يدوي',
        gearboxAutomatic: 'أوتوماتيكي',
        gearboxSemiAutomatic: 'شبه أوتوماتيكي',

        // Papers Options
        papersCard: 'بطاقة رمادية / صافية',
        papersLicense: 'رخصة / مهلة',
        
        // Seller Type Options
        sellerParticulier: 'خواص',
        sellerStore: 'متاجر',
        sellerAll: 'الكل',
        
        // Contact Modal
        contactModalTitle: 'التواصل مع البائع',
        yourName: 'اسمك',
        yourEmail: 'بريدك الإلكتروني',
        yourPhone: 'هاتفك (اختياري)',
        message: 'الرسالة',
        sendMessageButton: 'إرسال الرسالة',
        messageSentSuccess: 'تم إرسال الرسالة بنجاح!',
        
        // Donation Feature
        supportCause: 'ادعم هذه القضية',
        donateWithBaridiMob: 'تبرع عبر بريدي موب',
        donationInfoTitle: 'معلومات التبرع',
        scanQrCode: 'امسح رمز الاستجابة السريعة بتطبيقك',
        orUseCcp: 'أو استخدم حساب CCP التالي',
        accountHolder: 'صاحب الحساب',
        accountNumber: 'رقم الحساب',
        close: 'إغلاق',

        // Post Ad Flow
        postAdTitle: 'ماذا تريد أن تبيع على',
        postAdSubtitle: 'اختر الفئة المناسبة لإعلانك، ثم سنأخذك إلى النموذج التفصيلي لإكمال المعلومات.',
        postAdGuidance: 'يمكنك دائمًا تعديل الفئة والمعلومات لاحقًا من صفحة إدارة الإعلانات.',
        postAdFormTitle: 'نشر إعلان في فئة',
        formComingSoon: 'النموذج التفصيلي لهذه الفئة سيكون متاحًا قريبًا.',
        backToCategories: 'العودة لاختيار الفئات',
        adTitle: 'عنوان الإعلان',
        adTitlePlaceholder: 'مثال: فيلا جميلة للبيع',
        adPrice: 'السعر',
        adPricePlaceholder: 'مثال: 12000000',
        adImages: 'الصور',
        adImagesGuidance: 'أضف حتى 5 صور. الصورة الأولى ستكون الرئيسية.',
        adUpload: 'تحميل',
        adDescription: 'الوصف',
        adDescriptionPlaceholder: 'صف عقارك بالتفصيل...',
        adLocation: 'الموقع',
        postYourAd: 'انشر إعلانك',
        adDetails: 'تفاصيل الإعلان',
        generateWithAI: 'إنشاء بالذكاء الاصطناعي',
        generating: 'جاري الإنشاء...',
        aiDescriptionHelper: 'انقر لإنشاء وصف جذاب بناءً على التفاصيل التي قدمتها.',
        suggestPrice: 'اقتراح سعر',
        suggesting: 'جاري الاقتراح...',
        suggestedPriceRange: 'السعر المقترح',
        aiPriceHelper: 'احصل على تقدير للسعر بناءً على الإعلانات المماثلة.',
        from: 'من',
        to: 'إلى',
        
        // Post Ad Wizard
        step1: 'المعلومات',
        step2: 'التفاصيل',
        step3: 'الوسائط',
        step4: 'مراجعة',
        nextStep: 'التالي',
        prevStep: 'السابق',
        adTitleRequired: 'عنوان الإعلان إلزامي.',
        descriptionRequired: 'الوصف إلزامي.',
        mediaPriceLocationRequired: 'الرجاء إضافة صورة واحدة على الأقل وتحديد السعر والموقع.',
        reviewDetails: 'راجع تفاصيل إعلانك',

        // Footer
        createStore: 'أنشئ متجرك',
        advertise: 'الإعلان على sougnadz.com',
        howToPost: 'كيفية إضافة إعلان؟',
        contactUs: 'اتصل بنا',
        privacyPolicy: 'سياسة الخصوصية',
        terms: 'شروط الاستخدام والبيع',
        rightsReserved: 'جميع الحقوق محفوظة لدى sougnadz.com.'
    }
};

export type TranslationKey = keyof typeof translations.fr;

interface LocalizationContextType {
    language: Language;
    direction: 'ltr';
    setLanguage: (lang: Language) => void;
    t: (key: TranslationKey, defaultVal?: string | { [key: string]: string | number }) => string;
}

const LocalizationContext = createContext<LocalizationContextType | undefined>(undefined);

export const LocalizationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [language, setLanguageState] = useState<Language>('fr');
    const direction = 'ltr' as const;

    const setLanguage = (lang: Language) => {
        setLanguageState(lang);
    };

    const t = useCallback((key: TranslationKey, replacements?: string | { [key: string]: string | number }): string => {
        let translation = translations[language][key] || (typeof replacements === 'string' ? replacements : key);
        if (typeof replacements === 'object' && replacements !== null) {
            Object.entries(replacements).forEach(([placeholder, value]) => {
                translation = translation.replace(`{${placeholder}}`, String(value));
            });
        }
        return translation;
    }, [language]);


    return (
        <LocalizationContext.Provider value={{ language, direction, setLanguage, t }}>
            {children}
        </LocalizationContext.Provider>
    );
};

export const useLocalization = (): LocalizationContextType => {
    const context = useContext(LocalizationContext);
    if (!context) {
        throw new Error('useLocalization must be used within a LocalizationProvider');
    }
    return context;
};
