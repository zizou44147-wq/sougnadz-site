import React, { createContext, useState, useContext, ReactNode, useCallback } from 'react';
import { Listing } from '../services/types';

interface ReportAdContextType {
    isReportModalOpen: boolean;
    listingToReport: Listing | null;
    openReportAdModal: (listing: Listing) => void;
    closeReportAdModal: () => void;
}

const ReportAdContext = createContext<ReportAdContextType | undefined>(undefined);

export const ReportAdProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [isReportModalOpen, setIsReportModalOpen] = useState(false);
    const [listingToReport, setListingToReport] = useState<Listing | null>(null);

    const openReportAdModal = useCallback((listing: Listing) => {
        setListingToReport(listing);
        setIsReportModalOpen(true);
    }, []);

    const closeReportAdModal = useCallback(() => {
        setIsReportModalOpen(false);
        setListingToReport(null);
    }, []);

    const value = {
        isReportModalOpen,
        listingToReport,
        openReportAdModal,
        closeReportAdModal
    };

    return (
        <ReportAdContext.Provider value={value}>
            {children}
        </ReportAdContext.Provider>
    );
};

export const useReportAd = (): ReportAdContextType => {
    const context = useContext(ReportAdContext);
    if (!context) {
        throw new Error('useReportAd must be used within a ReportAdProvider');
    }
    return context;
};
