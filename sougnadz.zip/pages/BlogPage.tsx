

import React from 'react';
import { useLocalization } from '../hooks/useLocalization';
import NavbarLogo from '../components/NavbarLogo';

const BlogPage: React.FC = () => {
    const { t } = useLocalization();
    return (
        <div className="container mx-auto px-4 py-16 text-center">
            <div className="mb-8">
                <NavbarLogo className="text-6xl" />
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-orange-500">
                {t('blogPageTitle')}
            </h1>
            <p className="mt-4 text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                {t('blogPageDescription')}
            </p>
        </div>
    );
};

export default BlogPage;