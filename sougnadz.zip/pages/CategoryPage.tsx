import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { fetchListings } from '../services/api';
import { Listing, ListingFilters } from '../services/types';
import ListingGrid from '../components/ListingGrid';
import { useParams, useSearchParams } from 'react-router-dom';
import { CATEGORIES } from '../constants/categories'; 
import SubCategoryCarousel from '../components/SubCategoryCarousel';
import ListingsPageLayout from '../components/ListingsPageLayout';
import FiltersSidebar from '../components/FiltersSidebar';

const CategoryPage: React.FC = () => {
    const { t } = useLocalization();
    const { categorySlug } = useParams<{ categorySlug: string }>();
    const [searchParams, setSearchParams] = useSearchParams();
    
    const [listings, setListings] = useState<Listing[]>([]);
    const [loading, setLoading] = useState(true);
    
    const category = useMemo(() => 
        (categorySlug && categorySlug !== 'all') ? CATEGORIES.find(c => c.slug === categorySlug) : undefined
    , [categorySlug]);

    const activeFilters = useMemo<ListingFilters>(() => {
        const filters: ListingFilters = {};
        for (const [key, value] of searchParams.entries()) {
            if (['energie', 'boite', 'papiers'].includes(key)) {
                filters[key] = value.split(',');
            } else {
                filters[key] = value;
            }
        }
        return filters;
    }, [searchParams]);

    const pageTitleKey = category ? category.labelKey : (categorySlug === 'all' ? 'searchResults' : 'categoryPageTitle');
    
    const handleFilterChange = useCallback((newFilters: ListingFilters) => {
        const currentParams = new URLSearchParams(searchParams);
        
        // Update or remove each key from newFilters
        Object.entries(newFilters).forEach(([key, value]) => {
            if (value === '' || value === null || (Array.isArray(value) && value.length === 0)) {
                currentParams.delete(key);
            } else if (Array.isArray(value)) {
                currentParams.set(key, value.join(','));
            } else {
                currentParams.set(key, String(value));
            }
        });
        
        setSearchParams(currentParams, { replace: true });

    }, [searchParams, setSearchParams]);
    
    const handleSubCategorySelect = (subCategorySlug: string | null) => {
        const newParams = new URLSearchParams(searchParams);
        if (subCategorySlug) {
            newParams.set('subCategory', subCategorySlug);
        } else {
            newParams.delete('subCategory');
        }
        setSearchParams(newParams, { replace: true });
    };

    useEffect(() => {
        const loadListings = async () => {
            setLoading(true);
            const finalFilters: ListingFilters = { 
                ...activeFilters, 
                category: category ? category.apiName : undefined 
            };
            if (!category) {
                 delete finalFilters.category;
            }
            const data = await fetchListings(finalFilters);
            setListings(data);
            setLoading(false);
        };
        loadListings();
    }, [activeFilters, category]);

    if (!categorySlug) {
        return (
             <div className="container mx-auto px-4 py-16 text-center">
                <h1 className="text-4xl sm:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-orange-500">
                    {t('categoryPageTitle')}
                </h1>
                <p className="mt-4 text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                    {t('categoryPageDescription')}
                </p>
            </div>
        )
    }
    
    const filtersSidebar = (
        <FiltersSidebar
            categorySlug={categorySlug}
            onApplyFilters={handleFilterChange}
            initialFilters={activeFilters}
        />
    );

    return (
        <ListingsPageLayout
            pageTitle={t(pageTitleKey as TranslationKey, category?.apiName || t('searchResults'))}
            sidebar={filtersSidebar}
            activeSort={activeFilters.sortBy || 'relevance'}
            onSortChange={(value) => handleFilterChange({ sortBy: value })}
        >
            {category && category.subCategories && (
                <div className="mb-8">
                    <SubCategoryCarousel 
                        subCategories={category.subCategories}
                        onSelect={handleSubCategorySelect}
                        selectedSlug={activeFilters.subCategory}
                    />
                </div>
            )}
            
            <ListingGrid 
                listings={listings} 
                loading={loading} 
                noResults={!loading && listings.length === 0}
                noResultsMessage={t('noListingsInCategory')}
            />
        </ListingsPageLayout>
    );
};

export default CategoryPage;
