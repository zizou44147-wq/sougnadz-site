import React, { useState, useEffect } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { fetchFavoriteListings } from '../services/api';
import { Listing } from '../services/types';
import ListingGrid from '../components/ListingGrid';

const FavoritesPage: React.FC = () => {
    const { t } = useLocalization();
    const [listings, setListings] = useState<Listing[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadFavorites = async () => {
            setLoading(true);
            const data = await fetchFavoriteListings();
            setListings(data);
            setLoading(false);
        };
        loadFavorites();
    }, []);

    return (
        <div className="container mx-auto px-4 py-8">
            <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-8">
                {t('favorites')}
            </h1>
            <ListingGrid
                listings={listings}
                loading={loading}
                noResults={!loading && listings.length === 0}
                noResultsMessage={t('noFavorites')}
            />
        </div>
    );
};

export default FavoritesPage;
