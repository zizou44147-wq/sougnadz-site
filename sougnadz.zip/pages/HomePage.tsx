import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import ListingCarousel from '../components/ListingCarousel';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { WILAYAS } from '../constants/geodata';
import { ListingFilters } from '../services/types';
import NavbarLogo from '../components/NavbarLogo';
import { CATEGORIES } from '../constants/categories';
import SmartSearchModal from '../components/SmartSearchModal';
import RecentlyViewedCarousel from '../components/RecentlyViewedCarousel';


interface HeroSectionProps {
    onSearch: (query: string) => void;
    onPublishClick: () => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onSearch, onPublishClick }) => {
    const { t } = useLocalization();
    const navigate = useNavigate();
    const [query, setQuery] = useState('');
    const [wilaya, setWilaya] = useState('');

    const homeCategories = useMemo(() => {
        const fullList = [
            ...CATEGORIES.map(c => ({ slug: c.slug, labelKey: c.labelKey as TranslationKey, queryParams: '' })),
            { slug: 'emploi', labelKey: 'demandesEmploi' as TranslationKey, queryParams: "?priceString=Demande d'emploi" },
            { slug: 'services', labelKey: 'actionsCaritatives' as TranslationKey, queryParams: "?priceString=Action caritative" },
        ];
        // Now return all categories for the button list
        return fullList;
    }, []);
    
    const handleCategoryClick = (slug: string, queryParams: string) => {
        navigate(`/category/${slug}${queryParams}`);
    };
    
    const handleSearchClick = () => {
        let finalQuery = query;
        if (wilaya) {
            finalQuery += ` à ${wilaya}`;
        }
        if(finalQuery.trim()){
            onSearch(finalQuery.trim());
        }
    };

    return (
        <div className="relative text-center py-16 sm:py-24 overflow-hidden bg-gradient-to-b from-gray-50 to-white dark:from-[#0a0f26] dark:to-[#070b18]">
            <div className="absolute inset-0 bg-grid-pattern opacity-10 dark:opacity-10"></div>
            <div className="container mx-auto px-4 relative z-10">
                <div className="max-w-4xl mx-auto">
                    <div className="mb-4">
                        <NavbarLogo className="text-6xl sm:text-7xl" />
                    </div>
                    <h1 className="text-4xl sm:text-5xl font-extrabold mt-2 animate-fade-in-down text-gray-900 dark:text-white">
                        {t('heroTitle')}
                    </h1>
                    <p className="mt-4 text-lg sm:text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto animate-fade-in-up">
                        {t('heroSubtitle')}
                    </p>
                    <button onClick={onPublishClick} className="mt-6 inline-block bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-8 rounded-full text-lg transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-orange-500/40 active:translate-y-0 active:scale-95">
                        {t('publishAdFree')}
                    </button>
                    <div className="mt-10 max-w-3xl mx-auto">
                        <div className="flex flex-col sm:flex-row items-center gap-0 bg-white dark:bg-gray-900/50 p-2 rounded-full backdrop-blur-sm border border-gray-200 dark:border-gray-700 shadow-lg">
                            <input
                                type="text"
                                placeholder={t('smartSearchPlaceholder')}
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                onKeyDown={(e) => e.key === 'Enter' && handleSearchClick()}
                                className="flex-grow bg-transparent text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 px-4 py-2 focus:outline-none"
                            />
                            <div className="h-6 w-px bg-gray-200 dark:bg-gray-700 mx-2 hidden sm:block"></div>
                            <select
                                onChange={(e) => setWilaya(e.target.value)}
                                value={wilaya}
                                className="bg-transparent text-gray-700 dark:text-gray-300 px-4 py-2 appearance-none focus:outline-none cursor-pointer"
                            >
                                <option className="bg-white dark:bg-gray-800 text-gray-900 dark:text-white" value="">{t('allWilayas')}</option>
                                {WILAYAS.map(w => <option className="bg-white dark:bg-gray-800 text-gray-900 dark:text-white" key={w.code} value={w.name}>{w.name}</option>)}
                            </select>
                            <button onClick={handleSearchClick} className="flex-shrink-0 bg-blue-600 hover:bg-blue-700 text-white font-bold p-3 rounded-full transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-blue-500/40 active:translate-y-0 active:scale-95 flex items-center justify-center w-12 h-12">
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                            </button>
                        </div>
                        <div className="mt-4 flex flex-wrap justify-center gap-2">
                            {homeCategories.map(cat => (
                                 <button
                                    key={cat.slug + cat.labelKey}
                                    onClick={() => handleCategoryClick(cat.slug, cat.queryParams)}
                                    className={'text-sm px-3 py-1 rounded-full transition-all duration-200 bg-gray-200 dark:bg-gray-700/50 hover:bg-gray-300 dark:hover:bg-gray-600/80 text-gray-700 dark:text-gray-300 transform hover:-translate-y-0.5 active:translate-y-0'}
                                >
                                    {t(cat.labelKey as any)}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            <style>{`
                .bg-grid-pattern {
                    background-image:
                        linear-gradient(rgba(100, 116, 139, 0.1) 1px, transparent 1px),
                        linear-gradient(90deg, rgba(100, 116, 139, 0.1) 1px, transparent 1px);
                }
                .dark .bg-grid-pattern {
                    background-image:
                        linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                        linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
                }
                .bg-grid-pattern {
                    background-size: 2rem 2rem;
                }
                @keyframes fade-in-down {
                    from { opacity: 0; transform: translateY(-20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in-down { animation: fade-in-down 0.8s ease-out forwards; }
                
                @keyframes fade-in-up {
                     from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in-up { animation: fade-in-up 0.8s 0.2s ease-out forwards; }
            `}</style>
        </div>
    );
};


const HomePage: React.FC = () => {
    const { t } = useLocalization();
    const navigate = useNavigate();
    const [isSmartSearchModalOpen, setIsSmartSearchModalOpen] = useState(false);
    const [searchQueryForModal, setSearchQueryForModal] = useState('');
    
    const handleSearch = (query: string) => {
        setSearchQueryForModal(query);
        setIsSmartSearchModalOpen(true);
    };
    
    const handleCarouselClick = (slug: string, queryParamsStr: string = '') => {
        navigate(`/category/${slug}${queryParamsStr}`);
    };

    const carousels = useMemo(() => {
        const strategicOrder: TranslationKey[] = [
            'categoryAutomobilesVehicules',
            'categoryPiecesDetachees',
            'categoryImmobilier',
            'categoryTelephonesAccessoires',
            'categoryInformatique',
            'categoryBoutiques',
            'categoryElectromenagerElectronique',
            'categoryVetementsMode',
            'categorySanteBeaute',
            'categoryMeublesMaison',
            'categoryLoisirsDivertissements',
            'categorySport',
            'categoryEmploi',
            'categoryMateriauxEquipement',
            'categoryAlimentaires',
            'categoryVoyages',
            'categoryServices',
            'demandesEmploi',
            'actionsCaritatives',
        ];
        
        const allCarousels = [
            ...CATEGORIES.map(cat => ({
                key: cat.labelKey as TranslationKey,
                filters: { category: cat.apiName },
                slug: cat.slug,
                queryParams: ''
            })),
            { key: 'demandesEmploi' as const, filters: { priceString: "Demande d'emploi" }, slug: 'emploi', queryParams: "?priceString=Demande d'emploi" },
            { key: 'actionsCaritatives' as const, filters: { priceString: "Action caritative" }, slug: 'services', queryParams: "?priceString=Action caritative" }
        ];

        return allCarousels.sort((a, b) => {
            const indexA = strategicOrder.indexOf(a.key);
            const indexB = strategicOrder.indexOf(b.key);
            if (indexA === -1) return 1; // if not in order list, push to end
            if (indexB === -1) return -1;
            return indexA - indexB;
        });
    }, []);

    return (
        <div>
            <HeroSection 
                onSearch={handleSearch}
                onPublishClick={() => navigate('/post-ad')}
            />
            
            <RecentlyViewedCarousel />

            {carousels.map(carousel => (
                 <ListingCarousel 
                    key={carousel.key} 
                    title={t(carousel.key)} 
                    filters={carousel.filters}
                    onViewAllClick={() => handleCarouselClick(carousel.slug, carousel.queryParams)}
                />
            ))}

            <SmartSearchModal
                isOpen={isSmartSearchModalOpen}
                onClose={() => setIsSmartSearchModalOpen(false)}
                query={searchQueryForModal}
            />
        </div>
    );
};

export default HomePage;