import React, { useEffect, useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchListingById } from '../services/api';
import { Listing } from '../services/types';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import DonationModal from '../components/DonationModal';
import Toast from '../components/Toast';
import PhoneIcon from '../components/icons/PhoneIcon';
import WhatsAppIcon from '../components/icons/WhatsAppIcon';
import ChatModal from '../components/ChatModal';
import ChatIcon from '../components/icons/ChatIcon';
import { useReportAd } from '../hooks/useReportAd';
import { CATEGORIES } from '../constants/categories';
import ArrowLeftIcon from '../components/icons/ArrowLeftIcon';

const UserStatus: React.FC<{ isOnline: boolean }> = ({ isOnline }) => {
    const { t } = useLocalization();
    const color = isOnline ? 'text-green-500 dark:text-green-400' : 'text-gray-500 dark:text-gray-400';
    const bgColor = isOnline ? 'bg-green-500 dark:bg-green-400' : 'bg-gray-500 dark:bg-gray-400';
    return (
        <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${bgColor}`}></span>
            <span className={`text-xs font-semibold ${color}`}>{isOnline ? t('online') : t('offline')}</span>
        </div>
    );
};

const ListingDetailsPage: React.FC = () => {
    const { t, language } = useLocalization();
    const { listingId: listingIdParam } = useParams<{ listingId: string }>();
    const { openReportAdModal } = useReportAd();
    const navigate = useNavigate();
    const [listing, setListing] = useState<Listing | null>(null);
    const [loading, setLoading] = useState(true);
    const [mainImage, setMainImage] = useState<string>('');
    const [isDonationModalOpen, setIsDonationModalOpen] = useState(false);
    const [showToast, setShowToast] = useState(false);
    const [isLightboxOpen, setIsLightboxOpen] = useState(false);
    const [currentLightboxIndex, setCurrentLightboxIndex] = useState(0);
    const [isChatModalOpen, setIsChatModalOpen] = useState(false);
    const [showPhoneNumber, setShowPhoneNumber] = useState(false);
    
    const listingId = useMemo(() => listingIdParam ? parseInt(listingIdParam, 10) : undefined, [listingIdParam]);

    const allImages = useMemo(() => {
        if (!listing) return [];
        return [listing.imageUrl, ...(listing.images || [])];
    }, [listing]);
    
    useEffect(() => {
        if (typeof listingId === 'number' && !isNaN(listingId)) {
            const viewed = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
            const updatedViewed = [listingId, ...viewed.filter((id: number) => id !== listingId)].slice(0, 10);
            localStorage.setItem('recentlyViewed', JSON.stringify(updatedViewed));
        }
    }, [listingId]);
    

    const openLightbox = (index: number) => {
        setCurrentLightboxIndex(index);
        setIsLightboxOpen(true);
    };

    const closeLightbox = () => {
        setIsLightboxOpen(false);
    };

    const nextImage = useMemo(() => () => {
        if (allImages.length === 0) return;
        setCurrentLightboxIndex((prevIndex) => (prevIndex + 1) % allImages.length);
    }, [allImages.length]);

    const prevImage = useMemo(() => () => {
         if (allImages.length === 0) return;
        setCurrentLightboxIndex((prevIndex) => (prevIndex - 1 + allImages.length) % allImages.length);
    }, [allImages.length]);
    
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (!isLightboxOpen) return;
            if (e.key === 'ArrowRight') nextImage();
            if (e.key === 'ArrowLeft') prevImage();
            if (e.key === 'Escape') closeLightbox();
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isLightboxOpen, nextImage, prevImage, language]);

    useEffect(() => {
        if (typeof listingId !== 'number' || isNaN(listingId)) {
            setLoading(false);
            setListing(null);
            return;
        }

        const loadListing = async () => {
            setLoading(true);
            const data = await fetchListingById(listingId);
            setListing(data || null);
            if (data) {
                setMainImage(data.imageUrl);
            }
            setLoading(false);
        };
        loadListing();
    }, [listingId]);
    
    const handleReportClick = () => {
        if (listing) {
            openReportAdModal(listing);
        }
    };
    
    const handleBackClick = () => {
        // -1 navigates back in the history stack.
        navigate(-1);
    };


    const renderDetails = () => {
        if (!listing) return null;

        const carDetailsConfig = [
            { metaKey: 'brand', labelKey: 'filterBrand' },
            { metaKey: 'model', labelKey: 'filterModel' },
            { metaKey: 'trim', labelKey: 'trim' },
            { metaKey: 'year', labelKey: 'filterYear' },
            { metaKey: 'km', labelKey: 'filterKm', format: (val: number) => `${val.toLocaleString(language === 'fr' ? 'fr-FR' : 'ar-DZ')} km` },
            { metaKey: 'engine', labelKey: 'engine' },
            { metaKey: 'fuel', labelKey: 'filterFuel', valueMapKey: 'fuel' },
            { metaKey: 'transmission', labelKey: 'filterTransmission', valueMapKey: 'transmission' },
            { metaKey: 'papers', labelKey: 'filterPapers', valueMapKey: 'papers' },
            { metaKey: 'exchange', labelKey: 'filterExchange', valueMapKey: 'exchange' },
        ];
        
        const immoDetailsConfig = [
             { metaKey: 'surface', labelKey: 'surface', format: (val: number) => `${val} m²` },
             { metaKey: 'rooms', labelKey: 'rooms' },
             { metaKey: 'furnished', labelKey: 'furnishedLabel' },
        ];

        const valueTranslationMap: { [key: string]: { [val: string]: TranslationKey } } = {
            fuel: { 'essence': 'fuelEssence', 'diesel': 'fuelDiesel', 'gpl': 'fuelGpl', 'hybride': 'fuelHybrid', 'electrique': 'fuelElectric', 'autre': 'fuelOther' },
            transmission: { 'manuelle': 'gearboxManual', 'automatique': 'gearboxAutomatic', 'semi_automatique': 'gearboxSemiAutomatic' },
            papers: { 'carte_grise_safia': 'papersCard', 'licence_delai': 'papersLicense' },
            exchange: { 'accepte': 'exchangeAccepts', 'uniquement': 'exchangeOnly', 'aucun': 'exchangeNone' }
        };

        let detailsToShow;
        if (listing.category === 'Automobiles & Véhicules') {
            detailsToShow = carDetailsConfig;
        } else if (listing.category === 'Immobilier') {
            detailsToShow = immoDetailsConfig;
        } else {
            detailsToShow = Object.keys(listing.meta).map(key => ({ metaKey: key, labelKey: key as TranslationKey }));
        }

        return (
            <div className="mt-8 p-6 bg-gray-100/50 dark:bg-[#10162b] rounded-lg">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">{t('listingDetails')}</h3>
                <dl className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-6">
                    {detailsToShow.map(detail => {
                        const value = listing.meta[detail.metaKey];
                        if (value === undefined || value === null || value === '') return null;

                        let displayValue;
                        if (detail.valueMapKey) {
                            const translationKey = valueTranslationMap[detail.valueMapKey]?.[String(value)];
                            displayValue = translationKey ? t(translationKey) : String(value);
                        } else if (detail.format) {
                            displayValue = detail.format(value as number);
                        } else {
                            const translatedLabel = t(detail.labelKey, detail.metaKey);
                             displayValue = String(value);
                             if (translatedLabel === detail.metaKey) {
                                 detail.labelKey = detail.metaKey.charAt(0).toUpperCase() + detail.metaKey.slice(1) as TranslationKey;
                             }
                        }

                        return (
                            <div key={detail.metaKey}>
                                <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">{t(detail.labelKey, detail.metaKey.charAt(0).toUpperCase() + detail.metaKey.slice(1))}</dt>
                                <dd className="mt-1 font-semibold text-gray-900 dark:text-white">{displayValue}</dd>
                            </div>
                        );
                    })}
                </dl>
            </div>
        );
    };
    
    const priceTypeTranslation: { [key: string]: TranslationKey } = {
        fixe: 'priceFixe',
        negociable: 'priceNegociable',
        offre: 'priceOffre',
    };

    if (loading) return <div className="text-center py-20 text-2xl">Loading...</div>;
    if (!listing) return <div className="text-center py-20 text-2xl text-red-500">{t('noListingFound')}</div>;

    return (
        <>
        <div className="container mx-auto px-4 py-8">
             <div className="mb-6">
                <button
                    onClick={handleBackClick}
                    className="inline-flex items-center gap-2 bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg hover:shadow-orange-500/40 active:translate-y-0 active:scale-95"
                >
                    <ArrowLeftIcon className="w-5 h-5" />
                    <span>{t('backToResults')}</span>
                </button>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column: Images & Details */}
                <div className="lg:col-span-2">
                    <div>
                         <button onClick={() => openLightbox(allImages.indexOf(mainImage))} className="w-full h-[300px] md:h-[450px] bg-gray-200 dark:bg-gray-800 rounded-lg mb-4 overflow-hidden group">
                            <img src={mainImage} alt={listing.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                        </button>
                        <div className="flex gap-2">
                            {allImages.map((img, index) => (
                                <button
                                    key={index}
                                    onClick={() => setMainImage(img)}
                                    className={`w-20 h-20 md:w-24 md:h-24 flex-shrink-0 bg-gray-200 dark:bg-gray-800 rounded-md cursor-pointer border-2 overflow-hidden transition-all ${mainImage === img ? 'border-blue-500 scale-105' : 'border-transparent hover:border-blue-400'}`}
                                >
                                    <img 
                                        src={img} 
                                        alt={`thumbnail ${index + 1}`} 
                                        className="w-full h-full object-cover"
                                    />
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="mt-8 text-start">
                        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white">{listing.title}</h1>
                        <div className="flex items-baseline gap-3 mt-2">
                            <p className="text-3xl font-bold text-orange-500 dark:text-orange-400">
                                {listing.price}
                            </p>
                            {listing.meta.priceType && (
                                <span className="text-sm font-semibold text-gray-600 dark:text-gray-300 bg-gray-200 dark:bg-gray-700 px-3 py-1 rounded-full">
                                    {t(priceTypeTranslation[listing.meta.priceType])}
                                </span>
                            )}
                        </div>
                        <p className="text-gray-500 dark:text-gray-400 mt-2">{listing.location}, {listing.commune}</p>
                    </div>

                    {renderDetails()}

                    <div className="mt-8 text-start">
                        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">{t('description')}</h3>
                        <p className="text-gray-700 dark:text-gray-300 whitespace-pre-line">{listing.description || 'Pas de description disponible.'}</p>
                    </div>
                </div>

                {/* Right Column: Seller Info & Actions */}
                <div className="lg:col-span-1">
                    <div className="bg-gray-50 dark:bg-[#10162b] p-6 rounded-lg shadow-md dark:shadow-black/25 sticky top-24">
                        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 text-start">{t('sellerInformation')}</h3>
                        <div className="flex items-center gap-4 mb-6">
                            <img src={listing.user.avatarUrl} alt={listing.user.name} className="w-16 h-16 rounded-full" />
                            <div>
                                <p className="text-lg font-bold text-gray-900 dark:text-white">{listing.user.name}</p>
                                <UserStatus isOnline={listing.user.isOnline} />
                            </div>
                        </div>

                        <div className="space-y-3">
                             <a 
                                href={showPhoneNumber ? `tel:${listing.contact.phone}` : '#'}
                                onClick={() => setShowPhoneNumber(true)}
                                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg text-lg transition-colors flex items-center justify-center gap-3"
                            >
                                <PhoneIcon />
                                <span>{showPhoneNumber ? listing.contact.phone : t('showPhoneNumber')}</span>
                            </a>
                             <a 
                                href={`https://wa.me/${listing.contact.phone.replace(/\s/g, '')}`}
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-lg text-lg transition-colors flex items-center justify-center gap-3"
                            >
                                <WhatsAppIcon />
                                <span>{t('contactOnWhatsApp')}</span>
                            </a>
                            <button 
                                onClick={() => setIsChatModalOpen(true)}
                                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold py-3 rounded-lg text-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-3 shadow-lg shadow-purple-500/30"
                            >
                                <ChatIcon />
                                {t('chatWithSeller')}
                            </button>

                             {listing.category === 'Services' && listing.subCategory === 'actions-caritatives' && listing.donationInfo && (
                                 <button onClick={() => setIsDonationModalOpen(true)} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-lg text-lg transition-colors flex items-center justify-center gap-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                                    </svg>
                                    {t('supportCause')}
                                </button>
                            )}
                        </div>

                        <button 
                            onClick={handleReportClick}
                            className="w-full bg-red-900/20 dark:bg-red-900/30 hover:bg-red-900/30 dark:hover:bg-red-900/50 text-red-700 dark:text-red-300 text-sm font-medium py-2 rounded-lg transition-colors mt-6"
                        >
                            {t('reportAd')}
                        </button>
                    </div>
                </div>
            </div>
        </div>

        {isLightboxOpen && (
            <div 
                className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center animate-fade-in"
                onClick={closeLightbox}
            >
                <button onClick={(e) => { e.stopPropagation(); closeLightbox(); }} className="absolute top-4 end-4 text-white text-4xl hover:text-gray-300 z-10">&times;</button>
                <button onClick={(e) => { e.stopPropagation(); prevImage(); }} className="absolute start-4 top-1/2 -translate-y-1/2 p-2 bg-white/20 rounded-full text-white hover:bg-white/40 z-10">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
                </button>
                <button onClick={(e) => { e.stopPropagation(); nextImage(); }} className="absolute end-4 top-1/2 -translate-y-1/2 p-2 bg-white/20 rounded-full text-white hover:bg-white/40 z-10">
                    <svg className="w-8 h-8 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
                </button>
                <img 
                    src={allImages[currentLightboxIndex]} 
                    alt="Lightbox view"
                    className="max-w-[90vw] max-h-[90vh] object-contain transition-transform duration-300 animate-zoom-in"
                    onClick={(e) => e.stopPropagation()}
                />
                <style>{`
                    @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
                    .animate-fade-in { animation: fade-in 0.3s ease-out; }
                    @keyframes zoom-in { from { transform: scale(0.9); } to { transform: scale(1); } }
                    .animate-zoom-in { animation: zoom-in 0.3s ease-out; }
                `}</style>
            </div>
        )}
        
        {listing && (
             <ChatModal
                isOpen={isChatModalOpen}
                onClose={() => setIsChatModalOpen(false)}
                seller={listing.user}
            />
        )}
        
        {listing?.donationInfo && (
            <DonationModal
                isOpen={isDonationModalOpen}
                onClose={() => setIsDonationModalOpen(false)}
                donationInfo={listing.donationInfo}
                listingTitle={listing.title}
            />
        )}
        <Toast 
            message={t('messageSentSuccess')}
            show={showToast}
            onClose={() => setShowToast(false)}
        />
        </>
    );
};

export default ListingDetailsPage;
