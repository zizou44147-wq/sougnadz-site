import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { CATEGORIES } from '../constants/categories';
import { WILAYAS } from '../constants/geodata';
import { MOCK_LISTINGS } from '../constants/mockData';
import { CAR_DATA } from '../constants/carData';
import { Commune, ListingFilters, FilterDefinition } from '../services/types';
import { GoogleGenAI, Type } from "@google/genai";
import { CATEGORY_FILTERS } from '../constants/filterConfig';
import CloseIcon from '../components/icons/CloseIcon';
import Stepper from '../components/Stepper';

const PostAdFormPage: React.FC = () => {
    const navigate = useNavigate();
    const { categorySlug } = useParams<{ categorySlug: string }>();
    const { t, language } = useLocalization();

    const [currentStep, setCurrentStep] = useState(0);
    const [formData, setFormData] = useState<ListingFilters>({});
    const [communes, setCommunes] = useState<Commune[]>([]);
    
    const [isGeneratingDescription, setIsGeneratingDescription] = useState(false);
    const [isSuggestingPrice, setIsSuggestingPrice] = useState(false);
    const [suggestedPrice, setSuggestedPrice] = useState<{ min: number; max: number } | null>(null);
    
    const [imageFiles, setImageFiles] = useState<File[]>([]);
    const [imagePreviews, setImagePreviews] = useState<string[]>([]);
    const MAX_IMAGES = 5;
    const [formError, setFormError] = useState<string | null>(null);

    const steps = useMemo(() => [t('step1'), t('step2'), t('step3'), t('step4')], [t]);

    const category = useMemo(() => 
        categorySlug ? CATEGORIES.find(c => c.slug === categorySlug) : undefined
    , [categorySlug]);
    
    const categoryFilterDefs = useMemo(() => {
        if (!categorySlug) return [];
        return CATEGORY_FILTERS[categorySlug]?.flatMap(group => group.subFilters || []) || [];
    }, [categorySlug]);
    
    const carBrands = useMemo(() => CAR_DATA.map(c => c.brand), []);
    const carModels = useMemo(() => {
        if (formData.marque) {
            return CAR_DATA.find(c => c.brand === formData.marque)?.models || [];
        }
        return [];
    }, [formData.marque]);

    useEffect(() => {
        if (formData.wilaya) {
            const wilayaData = WILAYAS.find(w => w.name === formData.wilaya);
            setCommunes(wilayaData ? wilayaData.communes : []);
            setFormData(prev => ({ ...prev, commune: '' }));
        } else {
            setCommunes([]);
        }
    }, [formData.wilaya]);

    useEffect(() => {
        return () => { imagePreviews.forEach(url => URL.revokeObjectURL(url)); };
    }, [imagePreviews]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleCheckboxChange = useCallback((key: string, value: string) => {
        setFormData(prev => {
            const currentValues = (prev[key] as string[] || []);
            const newValues = currentValues.includes(value)
                ? currentValues.filter(v => v !== value)
                : [...currentValues, value];
            return { ...prev, [key]: newValues };
        });
    }, []);

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const files = Array.from(e.target.files);
            if (imageFiles.length + files.length > MAX_IMAGES) {
                alert(`Vous ne pouvez télécharger qu'un maximum de ${MAX_IMAGES} images.`);
                return;
            }
            // FIX: Explicitly type `file` as `File` to resolve the "Property 'type' does not exist on type 'unknown'" error.
            const validFiles = files.filter((file: File) => file.type.startsWith('image/'));
            setImageFiles(prev => [...prev, ...validFiles]);
            const newPreviews = validFiles.map((file: File) => URL.createObjectURL(file));
            setImagePreviews(prev => [...prev, ...newPreviews]);
            e.target.value = '';
        }
    };

    const handleRemoveImage = (indexToRemove: number) => {
        URL.revokeObjectURL(imagePreviews[indexToRemove]);
        setImageFiles(prev => prev.filter((_, index) => index !== indexToRemove));
        setImagePreviews(prev => prev.filter((_, index) => index !== indexToRemove));
    };
    
    const handleGenerateDescription = async () => {
        if (!category) return;
        setIsGeneratingDescription(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const details = Object.entries(formData).filter(([key, value]) => value && !['title', 'description', 'price', 'wilaya', 'commune'].includes(key)).map(([key, value]) => `- ${key}: ${Array.isArray(value) ? value.join(', ') : value}`).join('\n');
            const promptLang = language === 'ar' ? 'اكتب وصف إعلان جذاب وودي ومفصل باللغة العربية لموقع الإعلانات الجزائري sougnadz.com. استخدم التفاصيل التالية. كن مبدعًا ولكن دقيقًا.' : 'Write a compelling, friendly, and detailed ad description in French for the Algerian classifieds site sougnadz.com. Use the following details. Be creative but accurate.';
            const prompt = `${promptLang}\n\n- Category: ${category.apiName}\n- Title: ${formData.title}\n${details}\n\nStart with a catchy phrase. Mention key features. Conclude with a call to action. Do not invent features not listed.`;
            const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
            setFormData(prev => ({...prev, description: response.text}));
        } catch (error) { console.error("Gemini description generation failed:", error); } finally { setIsGeneratingDescription(false); }
    };
    
    const handleSuggestPrice = async () => {
        if (!category) return;
        setIsSuggestingPrice(true); setSuggestedPrice(null);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const similarListings = MOCK_LISTINGS.filter(l => l.category === category.apiName && (formData.marque ? l.meta.brand === formData.marque : true)).slice(0, 3);
            if (similarListings.length === 0) { setIsSuggestingPrice(false); return; }
            const similarAdsText = similarListings.map((ad, i) => `Ad ${i + 1}: Title: ${ad.title}, Year: ${ad.meta.year || 'N/A'}, Mileage: ${ad.meta.km || 'N/A'} km, Price: ${ad.price}`).join('\n');
            const userItemText = `- Category: ${category.apiName}\n- Title: ${formData.title}\n- Brand: ${formData.marque || 'N/A'}\n- Model: ${formData.modele || 'N/A'}\n- Year: ${formData.year || 'N/A'}\n- Mileage: ${formData.km || 'N/A'} km`;
            const prompt = `You are a price analysis expert for the Algerian market. Based on the following similar ads, suggest a fair price range (min and max) in Algerian Dinars (DA) for the user's item. Respond ONLY with a JSON object containing "min" and "max" keys (numbers).\n\nSimilar Ads:\n${similarAdsText}\n\nUser's Item:\n${userItemText}`;
            const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { responseMimeType: 'application/json', responseSchema: { type: Type.OBJECT, properties: { min: { type: Type.NUMBER }, max: { type: Type.NUMBER } } } } });
            setSuggestedPrice(JSON.parse(response.text));
        } catch(error) { console.error("Gemini price suggestion failed:", error); } finally { setIsSuggestingPrice(false); }
    };

    const isStepComplete = (step: number): boolean => {
        switch(step) {
            case 0: if (!formData.title) { setFormError(t('adTitleRequired')); return false; } break;
            case 1: if (!formData.description) { setFormError(t('descriptionRequired')); return false; } break;
            case 2: if (imageFiles.length === 0 || !formData.price || !formData.wilaya || !formData.commune) { setFormError(t('mediaPriceLocationRequired')); return false; } break;
            default: break;
        }
        setFormError(null);
        return true;
    };

    const handleNext = () => { if (isStepComplete(currentStep)) setCurrentStep(prev => prev + 1); };
    const handlePrev = () => setCurrentStep(prev => prev - 1);
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        console.log('Form Submitted:', { category: category?.apiName, ...formData, images: imageFiles });
        alert('Annonce soumise (simulation) !');
        navigate('/');
    };
    
    const renderDynamicField = (def: FilterDefinition) => {
        const key = def.key; const label = t(def.labelKey as TranslationKey);
        const baseClasses = "block w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500";
        switch (def.type) {
            case 'radio-group': return (<fieldset key={key} className="col-span-1 md:col-span-2"><legend className="block text-sm font-medium text-gray-700 dark:text-gray-300">{label}</legend><div className="flex flex-wrap gap-x-6 gap-y-3 mt-2">{def.options?.map(opt => (<label key={opt.value} className="flex items-center gap-2 cursor-pointer text-gray-900 dark:text-gray-100"><input type="radio" name={key} value={opt.value} checked={formData[key] === opt.value} onChange={handleInputChange} className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-900" /><span>{t(opt.labelKey as TranslationKey)}</span></label>))}</div></fieldset>);
            case 'checkbox-group': return (<fieldset key={key} className="col-span-1 md:col-span-2"><legend className="block text-sm font-medium text-gray-700 dark:text-gray-300">{label}</legend><div className="flex flex-wrap gap-x-6 gap-y-3 mt-2">{def.options?.map(opt => (<label key={opt.value} className="flex items-center gap-2 cursor-pointer text-gray-900 dark:text-gray-100"><input type="checkbox" value={opt.value} checked={(formData[key] as string[] || []).includes(opt.value)} onChange={() => handleCheckboxChange(key, opt.value)} className="h-4 w-4 rounded text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-900" /><span>{t(opt.labelKey as TranslationKey)}</span></label>))}</div></fieldset>);
            case 'select': let options = (key === 'marque') ? carBrands.map(b => ({ label: b, value: b })) : (key === 'modele') ? carModels.map(m => ({ label: m, value: m })) : (def.options || []).map(o => ({ label: t(o.labelKey as TranslationKey), value: o.value})); return (<div key={key}><label htmlFor={key} className="block text-sm font-medium text-gray-700 dark:text-gray-300">{label}</label><select id={key} name={key} value={formData[key] || ''} onChange={handleInputChange} className={`mt-1 ${baseClasses}`} disabled={key === 'modele' && !formData.marque}><option value="">{t('sellerAll')}</option>{options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}</select></div>);
            case 'range-number': return (<div key={key}><label htmlFor={key} className="block text-sm font-medium text-gray-700 dark:text-gray-300">{label}</label><input type="number" name={key} id={key} value={formData[key] || ''} onChange={handleInputChange} className={`mt-1 ${baseClasses}`} placeholder={label} /></div>);
            default: return (<div key={key}><label htmlFor={key} className="block text-sm font-medium text-gray-700 dark:text-gray-300">{label}</label><input type="text" name={key} id={key} value={formData[key] || ''} onChange={handleInputChange} className={`mt-1 ${baseClasses}`} placeholder={label} /></div>);
        }
    };

    if (!category) return (<div className="min-h-screen bg-slate-950 text-slate-50 py-10 text-center"><p>Catégorie non valide.</p><button onClick={() => navigate('/post-ad')} className="mt-4 text-blue-400 hover:underline">{t('backToCategories')}</button></div>);

    const renderStepContent = () => {
        switch (currentStep) {
            case 0: return (<div className="space-y-8"><h2 className="text-2xl font-semibold">{steps[0]}: {t('adTitle')} & {t('adDetails')}</h2><div><label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('adTitle')}</label><input type="text" name="title" id="title" value={formData.title || ''} onChange={handleInputChange} placeholder={t('adTitlePlaceholder')} required className="mt-1 block w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500" /></div><div className="grid grid-cols-1 md:grid-cols-2 gap-6">{categoryFilterDefs.slice(0, 3).map(renderDynamicField)}</div></div>);
            case 1: return (<div className="space-y-8"><h2 className="text-2xl font-semibold">{steps[1]}: {t('adDetails')} & {t('adDescription')}</h2><div className="grid grid-cols-1 md:grid-cols-2 gap-6">{categoryFilterDefs.slice(3).map(renderDynamicField)}</div><div><label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('adDescription')}</label><div className="relative"><textarea name="description" id="description" value={formData.description || ''} onChange={handleInputChange} rows={8} placeholder={t('adDescriptionPlaceholder')} required className="mt-1 block w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500" /><button type="button" onClick={handleGenerateDescription} disabled={isGeneratingDescription} className="absolute bottom-3 end-3 bg-blue-600 text-white text-xs font-semibold py-1 px-3 rounded-md hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-wait flex items-center gap-1 transition-all transform hover:scale-105 active:scale-100">{isGeneratingDescription ? t('generating') : t('generateWithAI')}</button></div><p className="mt-2 text-xs text-gray-500 dark:text-gray-400">{t('aiDescriptionHelper')}</p></div></div>);
            case 2: return (<div className="space-y-8"><h2 className="text-2xl font-semibold">{steps[2]}: {t('adImages')}, {t('adPrice')} & {t('adLocation')}</h2><div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('adImages')}</label><div className="mt-1"><div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">{imagePreviews.map((preview, index) => (<div key={index} className="relative aspect-square rounded-md overflow-hidden border-2 border-gray-300 dark:border-slate-700 group"><img src={preview} alt={`Aperçu ${index + 1}`} className="w-full h-full object-cover" /><button type="button" onClick={() => handleRemoveImage(index)} className="absolute top-1 right-1 bg-red-600/80 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Remove image"><CloseIcon /></button>{index === 0 && <div className="absolute bottom-0 left-0 bg-black/60 text-white text-xs font-bold px-2 py-1 rounded-tr-md">Principale</div>}</div>))}{imagePreviews.length < MAX_IMAGES && (<label htmlFor="file-upload" className="relative cursor-pointer aspect-square flex flex-col justify-center items-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-slate-700 border-dashed rounded-md hover:border-blue-500 transition-colors"><div className="space-y-1 text-center"><svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true"><path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg><div className="flex text-sm text-gray-600 dark:text-slate-400"><span className="font-medium text-blue-600 dark:text-blue-400">{t('adUpload')}</span></div></div><input id="file-upload" name="file-upload" type="file" className="sr-only" multiple accept="image/*" onChange={handleImageChange} /></label>)}</div><p className="mt-2 text-xs text-gray-500 dark:text-slate-500">{t('adImagesGuidance')}</p></div></div><div><label htmlFor="price" className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('adPrice')}</label><div className="mt-1 flex flex-col sm:flex-row items-start gap-4"><input type="number" name="price" id="price" value={formData.price || ''} onChange={handleInputChange} placeholder={t('adPricePlaceholder')} required className="block w-full sm:flex-grow bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500" /><button type="button" onClick={handleSuggestPrice} disabled={isSuggestingPrice} className="w-full sm:w-auto flex-shrink-0 bg-emerald-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-emerald-700 disabled:bg-emerald-400 disabled:cursor-wait transition-all transform hover:scale-105 active:scale-100">{isSuggestingPrice ? t('suggesting') : t('suggestPrice')}</button></div>{suggestedPrice && (<div className="mt-2 text-sm bg-emerald-50 dark:bg-emerald-900/50 border border-emerald-200 dark:border-emerald-800 rounded-md p-3"><span className="font-semibold text-emerald-800 dark:text-emerald-200">{t('suggestedPriceRange')}: </span><span className="font-mono">{t('from')} {suggestedPrice.min.toLocaleString()} DA {t('to')} {suggestedPrice.max.toLocaleString()} DA</span></div>)}<p className="mt-2 text-xs text-gray-500 dark:text-gray-400">{t('aiPriceHelper')}</p></div><div><label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('adLocation')}</label><div className="mt-1 grid grid-cols-1 md:grid-cols-2 gap-4"><select name="wilaya" value={formData.wilaya || ''} onChange={handleInputChange} required className="block w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"><option value="">{t('allWilayas')}</option>{WILAYAS.map(w => <option key={w.code} value={w.name}>{`${w.code} - ${w.name}`}</option>)}</select><select name="commune" value={formData.commune || ''} onChange={handleInputChange} required disabled={!formData.wilaya} className="block w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50"><option value="">{t('selectCommune')}</option>{communes.map(c => <option key={c.code} value={c.name}>{`${c.code} - ${c.name}`}</option>)}</select></div></div></div>);
            case 3: return (<div><h2 className="text-2xl font-semibold mb-4">{steps[3]}: {t('reviewDetails')}</h2><div className="space-y-4 bg-gray-100 dark:bg-slate-800/50 p-6 rounded-lg"><div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">{Object.entries(formData).map(([key, value]) => value ? (<div key={key}><dt className="text-sm font-medium text-gray-500 dark:text-gray-400 capitalize">{t(key as TranslationKey, key)}</dt><dd className="mt-1 text-gray-900 dark:text-white font-semibold">{Array.isArray(value) ? value.join(', ') : String(value)}</dd></div>) : null)}</div>{imagePreviews.length > 0 && <div className="pt-4"><dt className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">{t('adImages')}</dt><div className="flex flex-wrap gap-2">{imagePreviews.map((preview, index) => <img key={index} src={preview} alt="preview" className="w-20 h-20 rounded-md object-cover border-2 border-gray-300 dark:border-slate-600" />)}</div></div>}</div></div>);
            default: return null;
        }
    };

    return (
        <div className="bg-white dark:bg-[#070b18] text-gray-900 dark:text-white py-10 min-h-screen">
            <div className="max-w-4xl mx-auto px-4">
                 <button onClick={() => navigate('/post-ad')} className="mb-6 flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:underline"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>{t('backToCategories')}</button>
                <div className="bg-gray-50 dark:bg-slate-900/50 border border-gray-200 dark:border-slate-700/60 rounded-2xl p-8">
                    <h1 className="text-3xl md:text-4xl font-extrabold text-center mb-2">{`${t('postAdFormTitle')} ${t(category.labelKey)}`}</h1>
                    <Stepper steps={steps} currentStep={currentStep} />
                    <form onSubmit={handleSubmit} className="space-y-8">
                        {renderStepContent()}
                        {formError && <p className="text-red-500 text-sm mt-2">{formError}</p>}
                        <div className="pt-8 flex justify-between items-center">
                            <button type="button" onClick={handlePrev} disabled={currentStep === 0} className="bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-white font-bold py-2 px-6 rounded-md transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed">{t('prevStep')}</button>
                            {currentStep === steps.length - 1 ? (
                                <button type="submit" className="flex justify-center py-3 px-8 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-orange-600 hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-orange-500/40 active:translate-y-0 active:scale-95">{t('postYourAd')}</button>
                            ) : (
                                <button type="button" onClick={handleNext} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-md transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-blue-500/40 active:translate-y-0 active:scale-95">{t('nextStep')}</button>
                            )}
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default PostAdFormPage;