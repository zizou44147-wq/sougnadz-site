import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { CATEGORIES } from '../constants/categories'; // Import the new centralized categories

const PostAdPage: React.FC = () => {
    const navigate = useNavigate();
    const { t } = useLocalization();

    const handleSelectCategory = (e: React.MouseEvent<HTMLAnchorElement>, slug: string) => {
        e.preventDefault();
        navigate(`/post-ad/${slug}`);
    };

    return (
        <div className="min-h-screen bg-slate-950 text-slate-50 py-10">
            <div className="max-w-5xl mx-auto px-4">
                <h1 className={`text-3xl md:text-4xl font-extrabold text-center mb-4 text-start`}>
                    {t('postAdTitle')}{' '}
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-orange-500">
                        sougnadz.com
                    </span>
                    ؟
                </h1>
                <p className={`text-center text-slate-300 mb-10 text-start`}>
                    {t('postAdSubtitle')}
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {CATEGORIES.map((cat) => (
                        <a
                            key={cat.slug}
                            href={`#/post-ad/${cat.slug}`}
                            onClick={(e) => handleSelectCategory(e, cat.slug)}
                            className="group block relative overflow-hidden rounded-2xl bg-slate-900 border border-slate-700/60 p-[1px] hover:border-sky-500/70 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-sky-500/20"
                        >
                            <div className={`rounded-2xl bg-gradient-to-br ${cat.color} opacity-80 group-hover:opacity-100 transition`}>
                                <div className="flex items-center justify-center px-4 py-6 bg-slate-950/70 rounded-2xl backdrop-blur-sm">
                                    <span className="text-lg font-semibold">{t(cat.labelKey)}</span>
                                </div>
                            </div>
                        </a>
                    ))}
                </div>
                <p className={`mt-8 text-center text-sm text-slate-400 text-start`}>
                    {t('postAdGuidance')}
                </p>
            </div>
        </div>
    );
};

export default PostAdPage;
