
import { Listing, CarFilters, ListingFilters } from './types';
import { MOCK_LISTINGS } from '../constants/mockData';

// This service is designed to be replaced with actual API calls.


/**
 * Fetches listings, optionally filtered by category and other criteria.
 */
export const fetchListings = async (filters: ListingFilters, limit?: number): Promise<Listing[]> => {
    console.log(`Fetching listings with filters:`, filters);
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay

    let results = MOCK_LISTINGS;

    if (filters) {
        results = MOCK_LISTINGS.filter(listing => {
            // Text query filter
            if (filters.query) {
                const query = filters.query.toLowerCase();
                if (!listing.title.toLowerCase().includes(query) &&
                    !listing.description?.toLowerCase().includes(query) &&
                    !listing.location.toLowerCase().includes(query)) {
                    return false;
                }
            }

            // Generic filters
            if (filters.category && listing.category !== filters.category) return false;
            if (filters.priceString && listing.price !== filters.priceString) return false;
            if (filters.wilaya && listing.location !== filters.wilaya) return false;
            if (filters.commune && listing.commune !== filters.commune) return false;

            // Advanced Car Filters
            if (listing.category === 'Automobiles & Véhicules') {
                if (filters.subCategory && listing.subCategory !== filters.subCategory) return false;
                if (filters.marque && listing.meta.brand !== filters.marque) return false;
                if (filters.modele && listing.meta.model !== filters.modele) return false;

                // Range filters
                if (filters.priceMinMillions && (listing.priceValue || 0) < filters.priceMinMillions) return false;
                if (filters.priceMaxMillions && (listing.priceValue || 0) > filters.priceMaxMillions) return false;
                if (filters.yearMin && (listing.meta.year || 0) < filters.yearMin) return false;
                if (filters.yearMax && (listing.meta.year || 0) > filters.yearMax) return false;
                if (filters.kmMin && (listing.meta.km || 0) < filters.kmMin) return false;
                if (filters.kmMax && (listing.meta.km || 0) > filters.kmMax) return false;
                
                // Checkbox/Radio filters
                if (filters.echange && listing.meta.exchange !== filters.echange) return false;
                if (filters.sellerType && listing.meta.sellerType !== filters.sellerType) return false;

                // Array filters (checkbox groups)
                if (filters.energie && filters.energie.length > 0 && !filters.energie.includes(listing.meta.fuel as any)) return false;
                if (filters.boite && filters.boite.length > 0 && !filters.boite.includes(listing.meta.transmission as any)) return false;
                if (filters.papiers && filters.papiers.length > 0 && !filters.papiers.includes(listing.meta.papers as any)) return false;
            }

            // Advanced Immobilier Filters
            if (listing.category === 'Immobilier') {
                if (filters.transactionType && listing.meta.transactionType !== filters.transactionType) return false;
                if (filters.propertyType && listing.meta.propertyType !== filters.propertyType) return false;
                if (filters.priceMin && (listing.priceValue || 0) < filters.priceMin) return false;
                if (filters.priceMax && (listing.priceValue || 0) > filters.priceMax) return false;
                if (filters.surfaceMin && (listing.meta.surface || 0) < filters.surfaceMin) return false;
                if (filters.surfaceMax && (listing.meta.surface || 0) > filters.surfaceMax) return false;
                if (filters.roomsMin && (listing.meta.rooms || 0) < filters.roomsMin) return false;
                if (filters.roomsMax && (listing.meta.rooms || 0) > filters.roomsMax) return false;
                if (filters.furnished && listing.meta.furnished?.toLowerCase() !== filters.furnished) return false;
            }
            
            return true;
        });
    }
    
    // Sorting logic
    const parsePrice = (price: string): number => {
        return parseInt(price.replace(/[^0-9]/g, ''), 10) || 0;
    };

    let sortedResults = [...results];

    if (filters.sortBy) {
        switch (filters.sortBy) {
            case 'date':
                sortedResults.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
                break;
            case 'price_asc':
                sortedResults.sort((a, b) => (a.priceValue || parsePrice(a.price)) - (b.priceValue || parsePrice(b.price)));
                break;
            case 'price_desc':
                sortedResults.sort((a, b) => (b.priceValue || parsePrice(b.price)) - (a.priceValue || parsePrice(a.price)));
                break;
            default:
                break;
        }
    }
    
    if (limit) {
        return sortedResults.slice(0, limit);
    }

    return sortedResults;
};

/**
 * Fetches a single listing by its ID.
 */
export const fetchListingById = async (id: number): Promise<Listing | undefined> => {
    console.log(`Fetching listing with ID: ${id}`);
    await new Promise(resolve => setTimeout(resolve, 200)); // Simulate network delay
    return MOCK_LISTINGS.find(listing => listing.id === id);
};


/**
 * Fetches blog posts.
 */
export const fetchBlogPosts = async () => {
    console.log("Fetching blog posts...");
    await new Promise(resolve => setTimeout(resolve, 200));
    return [
        { id: 1, title: "5 Tips for Safe Online Transactions", excerpt: "Learn how to protect yourself when buying or selling online." },
        { id: 2, title: "How to Take Great Photos for Your Ad", excerpt: "Good photos can significantly increase your ad's visibility." },
    ];
};

/**
 * Fetches listings marked as favorite.
 */
export const fetchFavoriteListings = async (): Promise<Listing[]> => {
    console.log(`Fetching favorite listings`);
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay
    return MOCK_LISTINGS.filter(listing => listing.isFavorite);
};
