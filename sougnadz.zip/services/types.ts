export type Language = 'fr' | 'ar';

export interface User {
    name: string;
    avatarUrl: string;
    isOnline: boolean;
}

export enum ListingBadge {
    New = 'Nouveau',
    Top = 'Top',
    Promo = 'Promo',
    Urgent = 'Urgent',
}

// General Types
export type SellerType = 'particulier' | 'store';
export type ExchangeType = 'accepte' | 'uniquement' | 'aucun';
export type ListingStateType = 'neuf' | 'occasion' | 'comme_neuf';


// Car specific types
export type CarSubCategory = 'voitures' | 'utilitaires' | 'motos_scooters' | 'quads' | 'fourgon' | 'camion' | 'bus' | 'engin' | 'tracteurs' | 'remorques' | 'bateaux_barques';
export type GearboxType = 'manuelle' | 'automatique' | 'semi_automatique';
export type FuelType = 'essence' | 'diesel' | 'gpl' | 'hybride' | 'electrique' | 'autre';
export type PapersType = 'carte_grise_safia' | 'licence_delai';

export interface CarFilters {
  subCategory?: CarSubCategory;
  priceMinMillions?: number;
  priceMaxMillions?: number;
  echange?: ExchangeType;
  yearMin?: number;
  yearMax?: number;
  marque?: string;
  modele?: string;
  energie?: FuelType[];
  boite?: GearboxType[];
  kmMin?: number;
  kmMax?: number;
  papiers?: PapersType[];
}

// Immobilier specific types
export type ImmobilierTransactionType = 'vente' | 'location' | 'colocation' | 'location_vacances';
export type ImmobilierPropertyType = 'appartement' | 'maison' | 'villa' | 'terrain' | 'bureau' | 'local';

export interface ImmobilierFilters {
    transactionType?: ImmobilierTransactionType;
    propertyType?: ImmobilierPropertyType;
    priceMin?: number;
    priceMax?: number;
    surfaceMin?: number;
    surfaceMax?: number;
    roomsMin?: number;
    roomsMax?: number;
    furnished?: 'oui' | 'non';
}

// FIX: Used Omit<CarFilters, 'subCategory'> to resolve the type conflict.
// The `subCategory` property in `ListingFilters` needs to be a generic `string`,
// which is wider than `CarSubCategory` in `CarFilters`, causing an error.
// Omitting it from the extended type and redefining it solves the issue.
export interface ListingFilters extends Omit<CarFilters, 'subCategory'>, ImmobilierFilters {
    query?: string;
    category?: string;
    subCategory?: string;
    wilaya?: string;
    commune?: string;
    sortBy?: string;
    etat?: ListingStateType;
    sellerType?: SellerType;
    priceString?: string;
    [key: string]: any; 
}


export interface Listing {
    id: number;
    title: string;
    category: string;
    subCategory?: string; 
    price: string;
    priceValue?: number;
    imageUrl: string;
    images?: string[];
    description?: string;
    location: string;
    commune?: string;
    badge?: ListingBadge;
    user: User;
    meta: { 
        [key: string]: string | number | boolean | undefined;
        // Car specific meta
        trim?: string;
        engine?: string;
        year?: number;
        km?: number;
        fuel?: FuelType;
        transmission?: GearboxType;
        papers?: PapersType;
        exchange?: ExchangeType;
        sellerType?: SellerType;
        // Immobilier specific meta
        transactionType?: ImmobilierTransactionType;
        propertyType?: ImmobilierPropertyType;
        surface?: number;
        rooms?: number;
        furnished?: 'Oui' | 'Non';
        // General meta
        state?: ListingStateType;
        priceType?: 'fixe' | 'negociable' | 'offre';
    };
    contact: {
        phone: string;
        email?: string;
    };
    createdAt: string;
    isFavorite?: boolean;
    unreadMessagesCount?: number;
    donationInfo?: {
        baridiMob: {
            ccp: string;
            name: string;
        };
    };
}


// Types for Geo Data
export interface Commune {
    code: string;
    name: string;
}

export interface Wilaya {
    code: string;
    name: string;
    communes: Commune[];
}

// Types for Dynamic Filters
export type FilterType = 'accordion-group' | 'select' | 'range-number' | 'checkbox-group' | 'radio-group' | 'dependent-select';

export interface FilterOption {
    labelKey: string;
    value: string;
}

export interface FilterDefinition {
    key: string;
    labelKey: string;
    type: FilterType;
    options?: FilterOption[]; 
    placeholder?: { min: string, max: string };
    subFilters?: FilterDefinition[];
    minKey?: string;
    maxKey?: string;
}

export interface CategoryFilterConfig {
    [categorySlug: string]: FilterDefinition[];
}