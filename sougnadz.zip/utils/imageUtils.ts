export const imageUrlToBase64 = async (url: string): Promise<{ base64: string; mimeType: string }> => {
    // The proxy was causing 403 Forbidden errors. Removing it for a direct fetch.
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Failed to fetch image: ${response.statusText}`);
    }
    const blob = await response.blob();
    const mimeType = blob.type;

    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            // result is the full data URI, e.g., "data:image/jpeg;base64,..."
            // We need to extract just the base64 part for the API
            const base64 = (reader.result as string).split(',')[1];
            if (base64) {
                 resolve({ base64, mimeType });
            } else {
                reject(new Error("Failed to read base64 from image."));
            }
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};