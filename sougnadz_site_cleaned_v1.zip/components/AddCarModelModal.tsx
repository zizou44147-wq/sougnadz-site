import React, { useState, useEffect } from 'react';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { validateCarBrand, validateCarModel, validateCarEngine } from '../services/aiValidation';

interface AddCarDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveSuccess: (type: 'BRAND_MODEL' | 'ENGINE', data: { brand: string, model: string } | { engine: string }) => void;
  mode: 'BRAND_MODEL' | 'ENGINE';
  initialBrand?: string;
}

const AddCarDetailModal: React.FC<AddCarDetailModalProps> = ({ isOpen, onClose, onSaveSuccess, mode, initialBrand }) => {
    const { t } = useLocalization();
    const [brand, setBrand] = useState('');
    const [model, setModel] = useState('');
    const [engine, setEngine] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (isOpen) {
            setBrand(initialBrand || '');
            setModel('');
            setEngine('');
            setError(null);
            setIsLoading(false);
        }
    }, [initialBrand, isOpen]);

    if (!isOpen) return null;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError(null);
        let isValid = false;

        try {
            if (mode === 'BRAND_MODEL') {
                const brandToSave = brand.trim();
                const modelToSave = model.trim();
                if (!brandToSave) return;

                isValid = await validateCarBrand(brandToSave);
                if (!isValid) {
                    setError(t('validationFailedBrand'));
                    return;
                }

                if (modelToSave) {
                    isValid = await validateCarModel(brandToSave, modelToSave);
                    if (!isValid) {
                        setError(t('validationFailedModel'));
                        return;
                    }
                }
                onSaveSuccess('BRAND_MODEL', { brand: brandToSave, model: modelToSave });
            } else { // ENGINE mode
                const engineToSave = engine.trim();
                if (!engineToSave) return;
                
                isValid = await validateCarEngine(engineToSave);
                if (!isValid) {
                    setError(t('validationFailedEngine'));
                    return;
                }
                onSaveSuccess('ENGINE', { engine: engineToSave });
            }
        } catch (e) {
            console.error(e);
            setError("An unexpected error occurred.");
        } finally {
            setIsLoading(false);
        }
    };

    const renderBrandModelForm = () => (
        <>
            <div>
                <label htmlFor="brand" className="block text-sm font-medium text-gray-300">{t('brandName')}</label>
                <input
                    type="text"
                    id="brand"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    placeholder={t('brandNamePlaceholder')}
                    required
                    className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
            </div>
             <div>
                <label htmlFor="model" className="block text-sm font-medium text-gray-300">{t('modelName')}</label>
                <input
                    type="text"
                    id="model"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    placeholder={t('modelNamePlaceholder')}
                    required
                    className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
            </div>
        </>
    );

    const renderEngineForm = () => (
        <div>
            <label htmlFor="engine" className="block text-sm font-medium text-gray-300">{t('engineName')}</label>
            <input
                type="text"
                id="engine"
                value={engine}
                onChange={(e) => setEngine(e.target.value)}
                placeholder={t('engineNamePlaceholder')}
                required
                className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
        </div>
    );
    
    const titleKey: TranslationKey = mode === 'BRAND_MODEL' ? 'addCarModelTitle' : 'addCarEngineTitle';

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity duration-300" onClick={onClose}>
            <form
                onSubmit={handleSubmit}
                className="bg-[#0f1429] rounded-lg shadow-xl p-8 w-full max-w-md m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex items-center gap-3 mb-6">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 3a1 1 0 011 1v1.586l1.707-1.707a1 1 0 011.414 1.414L12.414 7H14a1 1 0 011 1v2a1 1 0 01-1 1h-1.586l1.707 1.707a1 1 0 01-1.414 1.414L11 12.414V14a1 1 0 01-2 0v-1.586l-1.707 1.707a1 1 0 01-1.414-1.414L7.586 11H6a1 1 0 01-1-1V8a1 1 0 011-1h1.586L5.879 5.293a1 1 0 011.414-1.414L9 5.586V4a1 1 0 011-1z" />
                    </svg>
                    <h2 className="text-2xl font-bold text-white">{t(titleKey)}</h2>
                </div>
                
                <div className="space-y-4">
                    {mode === 'BRAND_MODEL' ? renderBrandModelForm() : renderEngineForm()}
                </div>

                {error && <p className="text-red-400 text-sm mt-4 bg-red-900/40 p-3 rounded-md">{error}</p>}

                <div className="mt-8 flex justify-end gap-3 items-center">
                    {isLoading && <span className="text-sm text-gray-400 italic">{t('validatingWithAI')}</span>}
                    <button
                        type="button"
                        onClick={onClose}
                        disabled={isLoading}
                        className="px-4 py-2 bg-gray-700 text-gray-200 rounded-md hover:bg-gray-600 font-semibold transition-colors disabled:opacity-50"
                    >
                        {t('cancel')}
                    </button>
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-semibold transition-colors disabled:bg-blue-400 disabled:cursor-wait"
                    >
                        {t('add')}
                    </button>
                </div>

                <style>{`
                    @keyframes modal-pop {
                        from { transform: scale(0.9); opacity: 0; }
                        to { transform: scale(1); opacity: 1; }
                    }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </form>
        </div>
    );
};

export default AddCarDetailModal;