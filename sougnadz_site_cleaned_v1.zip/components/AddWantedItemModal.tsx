import React, { useState } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { CATEGORIES } from '../constants/categories';
import { WILAYAS } from '../constants/geodata';
import { useWantedItems } from '../hooks/useWantedItems';

interface AddWantedItemModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
}

const AddWantedItemModal: React.FC<AddWantedItemModalProps> = ({ isOpen, onClose, onSuccess }) => {
    const { t } = useLocalization();
    const { addWantedItem } = useWantedItems();
    const [title, setTitle] = useState('');
    const [category, setCategory] = useState('');
    const [description, setDescription] = useState('');
    const [budget, setBudget] = useState('');
    const [deliveryWilaya, setDeliveryWilaya] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title || !category || !description || !deliveryWilaya) {
            // Basic validation
            return;
        }

        addWantedItem({
            title,
            category,
            description,
            budget,
            deliveryWilaya,
        });
        
        onSuccess();
        onClose();
        // Reset form
        setTitle('');
        setCategory('');
        setDescription('');
        setBudget('');
        setDeliveryWilaya('');
    };
    
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity duration-300" onClick={onClose}>
            <form
                onSubmit={handleSubmit}
                className="bg-[#0f1429] rounded-lg shadow-xl p-8 w-full max-w-2xl m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="text-center mb-6">
                    <h2 className="text-2xl font-bold text-white">{t('addWantedItemTitle')}</h2>
                    <p className="text-gray-400">{t('addWantedItemSubtitle')}</p>
                </div>
                
                <div className="space-y-4">
                     <div>
                        <label htmlFor="wanted-title" className="block text-sm font-medium text-gray-300">{t('wantedItemTitle')}</label>
                        <input type="text" id="wanted-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t('wantedItemTitlePlaceholder')} required className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
                    </div>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="wanted-category" className="block text-sm font-medium text-gray-300">{t('wantedItemCategory')}</label>
                            <select id="wanted-category" value={category} onChange={(e) => setCategory(e.target.value)} required className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                                <option value="">{t('filterCategory')}</option>
                                {CATEGORIES.map(cat => <option key={cat.slug} value={cat.apiName}>{t(cat.labelKey)}</option>)}
                            </select>
                        </div>
                        <div>
                             <label htmlFor="wanted-budget" className="block text-sm font-medium text-gray-300">{t('wantedItemBudget')}</label>
                            <input type="text" id="wanted-budget" value={budget} onChange={(e) => setBudget(e.target.value)} placeholder={t('wantedItemBudgetPlaceholder')} className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                     </div>
                     <div>
                        <label htmlFor="wanted-delivery" className="block text-sm font-medium text-gray-300">{t('wantedItemDelivery')}</label>
                        <select id="wanted-delivery" value={deliveryWilaya} onChange={(e) => setDeliveryWilaya(e.target.value)} required className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <option value="">{t('filterWilaya')}</option>
                            {WILAYAS.map(w => <option key={w.code} value={w.name}>{w.name}</option>)}
                        </select>
                        <p className="mt-1 text-xs text-gray-400">{t('wantedItemDeliveryHelper')}</p>
                    </div>
                     <div>
                        <label htmlFor="wanted-description" className="block text-sm font-medium text-gray-300">{t('wantedItemDescription')}</label>
                        <textarea id="wanted-description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder={t('wantedItemDescriptionPlaceholder')} required rows={4} className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500"></textarea>
                    </div>
                </div>

                <div className="mt-8 flex justify-end gap-3">
                    <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-700 text-gray-200 rounded-md hover:bg-gray-600 font-semibold transition-colors">
                        {t('cancel')}
                    </button>
                    <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-semibold transition-colors">
                        {t('submitRequest')}
                    </button>
                </div>

                <style>{`
                    @keyframes modal-pop {
                        from { transform: scale(0.9); opacity: 0; }
                        to { transform: scale(1); opacity: 1; }
                    }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </form>
        </div>
    );
};

export default AddWantedItemModal;