import React, { useState, useRef, useEffect, memo, useMemo } from 'react';
import { Listing, ListingBadge } from '../services/types';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { useNavigate } from 'react-router-dom';
import { toggleFavoriteStatus } from '../services/api';
import MoreIcon from './icons/MoreIcon';
import FlagIcon from './icons/FlagIcon';
import { useReportAd } from '../hooks/useReportAd';
import CalendarIcon from './icons/CalendarIcon';
import SpeedometerIcon from './icons/SpeedometerIcon';
import FuelIcon from './icons/FuelIcon';
import StarIcon from './icons/StarIcon';
import VerifiedIcon from './icons/VerifiedIcon';
import LightningBoltIcon from './icons/LightningBoltIcon';
import { formatTimeAgo } from '../utils/time';
import ShareIcon from './icons/ShareIcon';
import FacebookIcon from './icons/FacebookIcon';
import TwitterIcon from './icons/TwitterIcon';
import TelegramIcon from './icons/TelegramIcon';
import LinkIcon from './icons/LinkIcon';
import CheckIcon from './icons/CheckIcon';
import WhatsAppIcon from './icons/WhatsAppIcon';
import { useWatermarkedImage } from '../hooks/useWatermarkedImage';
import ShippingIcon from './icons/ShippingIcon';

// --- HELPER COMPONENTS ---

const Badge: React.FC<{ badge: ListingBadge }> = ({ badge }) => {
    const badgeMap = {
        [ListingBadge.New]: { color: 'bg-blue-600', text: 'Nouveau' },
        [ListingBadge.Top]: { color: 'bg-yellow-400 text-black', text: 'Top' },
        [ListingBadge.Promo]: { color: 'bg-green-500', text: 'Promo' },
        [ListingBadge.Urgent]: { color: 'bg-red-500', text: 'Urgent' },
        [ListingBadge.Featured]: { color: 'bg-purple-600', text: 'En vedette' },
    };
    const currentBadge = badgeMap[badge];

    return (
        <span className={`absolute top-3 left-3 text-xs font-bold text-white px-2.5 py-1 rounded-full z-10 ${currentBadge.color}`}>
            {currentBadge.text}
        </span>
    );
};

const UserStatus: React.FC<{ isOnline: boolean }> = ({ isOnline }) => {
    const { t } = useLocalization();
    if (isOnline) {
        return (
            <div className="flex items-center gap-1.5 text-xs font-medium text-green-600">
                <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                <span>{t('online')}</span>
            </div>
        );
    }
    return (
         <div className="flex items-center gap-1.5 text-xs font-medium text-gray-500">
            <span className="relative flex h-2 w-2">
                <span className="relative inline-flex rounded-full h-2 w-2 bg-gray-400"></span>
            </span>
            <span>{t('offline')}</span>
        </div>
    );
};


// --- MAIN COMPONENT ---

const AutomobileListingCard: React.FC<{ listing: Listing }> = ({ listing }) => {
    const { t, language } = useLocalization();
    const navigate = useNavigate();
    const { openReportAdModal } = useReportAd();
    const [isFavorited, setIsFavorited] = useState(listing.isFavorite || false);
    const [isAnimating, setIsAnimating] = useState(false);
    const [isOptionsOpen, setIsOptionsOpen] = useState(false);
    const optionsMenuRef = useRef<HTMLDivElement>(null);
    const [isShareMenuOpen, setIsShareMenuOpen] = useState(false);
    const [linkCopied, setLinkCopied] = useState(false);
    const shareMenuRef = useRef<HTMLDivElement>(null);
    const { watermarkedUrl, isLoading } = useWatermarkedImage(listing.imageUrl);
    
    const carTitle = useMemo(() => {
        if (listing.meta.brand && listing.meta.model) {
            const mainTitle = `${listing.meta.brand} ${listing.meta.model}`;
            const subTitle = listing.title.replace(mainTitle, '').trim();
            return { main: mainTitle, sub: subTitle };
        }
        return { main: listing.title, sub: null };
    }, [listing]);


    useEffect(() => {
        setIsFavorited(listing.isFavorite || false);
    }, [listing.isFavorite]);


    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (optionsMenuRef.current && !optionsMenuRef.current.contains(event.target as Node)) {
                setIsOptionsOpen(false);
                setIsShareMenuOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleCardClick = () => {
        navigate(`/listing/${listing.id}`);
    };
    
    const toggleFavorite = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();

        const newFavoriteStatus = toggleFavoriteStatus(listing.id);

        if (newFavoriteStatus) {
            setIsAnimating(true);
        }
        setIsFavorited(newFavoriteStatus);
    };

    const handleOptionsClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsOptionsOpen(prev => !prev);
        setIsShareMenuOpen(false); // Close share when toggling main menu
    };

    const handleReportClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        openReportAdModal(listing);
        setIsOptionsOpen(false);
    }
    
    const handleShareClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsShareMenuOpen(prev => !prev);
    };

    const listingUrl = `${window.location.origin}${window.location.pathname.replace(/index.html$/, '')}#/listing/${listing.id}`;
    const encodedTitle = encodeURIComponent(listing.title);

    const shareOptions = [
        { name: 'Facebook', icon: <FacebookIcon className="w-5 h-5" />, url: `https://www.facebook.com/sharer/sharer.php?u=${listingUrl}` },
        { name: 'Twitter', icon: <TwitterIcon className="w-5 h-5" />, url: `https://twitter.com/intent/tweet?url=${listingUrl}&text=${encodedTitle}` },
        { name: 'WhatsApp', icon: <WhatsAppIcon className="w-5 h-5" />, url: `https://api.whatsapp.com/send?text=${encodedTitle}%20${listingUrl}` },
        { name: 'Telegram', icon: <TelegramIcon className="w-5 h-5" />, url: `https://t.me/share/url?url=${listingUrl}&text=${encodedTitle}` }
    ];

    const handleCopyLink = (e: React.MouseEvent) => {
        e.stopPropagation();
        navigator.clipboard.writeText(listingUrl).then(() => {
            setLinkCopied(true);
            setTimeout(() => {
                setLinkCopied(false);
                setIsShareMenuOpen(false);
                setIsOptionsOpen(false);
            }, 1500);
        });
    };

    const priceTypeTranslation: { [key: string]: TranslationKey } = {
        fixe: 'priceFixe',
        negociable: 'priceNegociable',
        offre: 'priceOffre',
    };

    const fuelKey = useMemo(() => {
        const valueTranslationMap: { [key: string]: TranslationKey } = {
            'essence': 'fuelEssence', 'diesel': 'fuelDiesel', 'gpl': 'fuelGpl', 'hybride': 'fuelHybrid', 'electrique': 'fuelElectric', 'autre': 'fuelOther'
        };
        return listing.meta.fuel ? valueTranslationMap[listing.meta.fuel] : undefined;
    }, [listing.meta.fuel]);

    return (
        <div 
            onClick={handleCardClick}
            className="group relative flex h-full cursor-pointer flex-col rounded-xl border border-slate-700 bg-slate-800 shadow-sm transition-all duration-300 hover:border-blue-500/80 hover:shadow-lg"
        >
            <div className="relative">
                <div className="h-56 w-full overflow-hidden rounded-t-xl bg-slate-700">
                    {isLoading ? (
                        <div className="h-full w-full animate-pulse" />
                    ) : (
                        <img
                            src={watermarkedUrl || listing.imageUrl}
                            alt={listing.title}
                            loading="lazy"
                            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                        />
                    )}
                </div>
                {listing.badge && <Badge badge={listing.badge} />}
                
                 <div className="absolute top-2.5 right-2.5 z-20" ref={optionsMenuRef}>
                    <button
                        onClick={handleOptionsClick}
                        aria-label="More options"
                        className="p-2 bg-gray-900/50 rounded-full text-white hover:bg-black/60 transition-colors"
                    >
                        <MoreIcon className="w-5 h-5" />
                    </button>
                    <div className={`absolute mt-2 w-40 bg-slate-900 border border-slate-700 rounded-md shadow-lg py-1 end-0 transition-all duration-300 ease-out origin-top-right ${isOptionsOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
                        <button onClick={handleReportClick} className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-slate-800 text-start">
                            <FlagIcon className="w-4 h-4" />
                            <span>{t('report')}</span>
                        </button>
                         <div className="border-t border-slate-700 my-1"></div>
                        <div className="relative">
                            <button onClick={handleShareClick} className="w-full flex items-center justify-between gap-2 px-4 py-2 text-sm text-gray-200 hover:bg-slate-800 text-start">
                                <div className="flex items-center gap-2">
                                    <ShareIcon className="w-4 h-4" />
                                    <span>{t('share')}</span>
                                </div>
                                <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" /></svg>
                            </button>
                            <div ref={shareMenuRef} className={`absolute bottom-0 right-full mr-2 w-48 bg-slate-900 border border-slate-700 rounded-md shadow-lg p-2 flex items-center justify-around transition-all duration-300 ease-out origin-right ${isShareMenuOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
                                {shareOptions.map(option => (
                                    <a key={option.name} href={option.url} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()} className="p-2 rounded-full text-gray-300 hover:bg-slate-800" aria-label={`Share on ${option.name}`}>
                                        {option.icon}
                                    </a>
                                ))}
                                <button onClick={handleCopyLink} className="p-2 rounded-full text-gray-300 hover:bg-slate-800" aria-label="Copy link">
                                    {linkCopied ? <CheckIcon className="w-5 h-5 text-green-500" /> : <LinkIcon className="w-5 h-5" />}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <button
                    onClick={toggleFavorite}
                    onAnimationEnd={() => setIsAnimating(false)}
                    aria-label={t(isFavorited ? 'removeFromFavorites' : 'addToFavorites')}
                    className="absolute bottom-2.5 right-2.5 z-10 p-2 bg-gray-900/50 rounded-full text-white hover:bg-black/60 transition-colors"
                >
                    <svg className={`w-5 h-5 ${isAnimating ? 'heart-popping' : ''}`} fill={isFavorited ? '#ef4444' : 'none'} stroke={isFavorited ? 'none' : 'currentColor'} strokeWidth={2} viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 016.364 0L12 7.636l1.318-1.318a4.5 4.5 0 016.364 6.364L12 20.364l-7.682-7.682a4.5 4.5 0 010-6.364z" />
                    </svg>
                </button>
            </div>

            <div className="flex flex-grow flex-col p-4">
                <h3 className="font-bold text-lg text-white line-clamp-1">{carTitle.main}</h3>
                {carTitle.sub && <p className="text-sm text-gray-400 line-clamp-1">{carTitle.sub}</p>}
                
                <div className="my-3 grid grid-cols-3 gap-2 border-y border-slate-700/60 py-3 text-xs text-gray-300">
                    {listing.meta.year && <div className="flex items-center gap-1.5"><CalendarIcon className="h-4 w-4 text-gray-400" /><span>{listing.meta.year}</span></div>}
                    {listing.meta.km !== undefined && <div className="flex items-center gap-1.5"><SpeedometerIcon className="h-4 w-4 text-gray-400" /><span>{listing.meta.km.toLocaleString(language === 'fr' ? 'fr-FR' : 'ar-DZ')} km</span></div>}
                    {fuelKey && <div className="flex items-center gap-1.5"><FuelIcon className="h-4 w-4 text-gray-400" /><span>{t(fuelKey)}</span></div>}
                </div>
                
                <div>
                    <div className="flex items-center gap-3">
                        <img src={listing.user.avatarUrl} alt={listing.user.name} className="w-10 h-10 rounded-full flex-shrink-0" />
                        <div>
                            <p className="font-bold text-gray-200 line-clamp-1">{listing.user.name}</p>
                            <UserStatus isOnline={listing.user.isOnline} />
                        </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-2">
                        {listing.user.rating && (
                            <div className="flex items-center gap-1 text-xs font-medium text-gray-300">
                               <StarIcon className="h-4 w-4 text-amber-500" />
                                <span className="font-bold">{listing.user.rating.toFixed(1)}</span>
                            </div>
                        )}
                         {listing.user.quickReply && (
                            <div className="flex items-center gap-1 rounded-full bg-cyan-900/50 px-2 py-0.5 text-xs font-semibold text-cyan-200">
                                <LightningBoltIcon className="h-3.5 w-3.5" />
                                <span>{t('quickReply')}</span>
                            </div>
                        )}
                        {listing.meta.sellerType === 'store' && (
                            <div className="flex items-center gap-1 rounded-full bg-blue-900/50 px-2 py-0.5 text-xs font-semibold text-blue-200">
                                <VerifiedIcon className="h-3.5 w-3.5" />
                                <span>{t('professionalSeller')}</span>
                            </div>
                        )}
                        {listing.market === 'europe' && listing.meta.shipsToAlgeria && (
                            <div className="flex items-center gap-1 rounded-full bg-orange-900/50 px-2 py-0.5 text-xs font-semibold text-orange-200">
                                <ShippingIcon className="h-3.5 w-3.5" />
                                <span>{t('shippingToAlgeriaAvailable')}</span>
                            </div>
                        )}
                    </div>
                </div>

                <div className="mt-auto pt-4 space-y-2">
                     <p className="text-xs text-gray-400">
                        {listing.location}{listing.commune ? `, ${listing.commune}` : ''} &middot; {formatTimeAgo(listing.createdAt, t, language)}
                    </p>
                    <div className="flex items-end justify-between">
                        <p className="text-2xl font-extrabold text-orange-600">
                            {listing.price}
                        </p>
                        {listing.meta.priceType && (
                            <div className="rounded-md border border-slate-600 bg-slate-700 px-3 py-1.5 text-xs font-bold text-gray-200 shadow-sm">
                                {t(priceTypeTranslation[listing.meta.priceType])}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default memo(AutomobileListingCard);