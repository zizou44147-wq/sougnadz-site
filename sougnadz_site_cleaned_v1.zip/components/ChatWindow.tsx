/*
  This file appears to be part of an unintegrated AI chat feature.
  The content has been commented out as it's not currently used in the application.
  The application uses a different 'ChatModal.tsx' for seller communication.
*/

/*
import React, { useRef, useEffect } from 'react';
import type { Message } from '../types';
import MessageBubble from './MessageBubble';

interface ChatWindowProps {
    messages: Message[];
    isLoading: boolean;
}

const TypingIndicator: React.FC = () => (
    <div className="flex items-start justify-start">
         <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center mr-3 flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-blue-400">
            <path fillRule="evenodd" d="M4.5 3.75a3 3 0 0 0-3 3v10.5a3 3 0 0 0 3 3h15a3 3 0 0 0 3-3V6.75a3 3 0 0 0-3-3h-15Zm4.125 3a.75.75 0 0 0 0 1.5h6.75a.75.75 0 0 0 0-1.5h-6.75Zm-.75 3.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Zm-2.25 3.375a.75.75 0 0 0 0 1.5h.75a.75.75 0 0 0 0-1.5h-.75Z" clipRule="evenodd" />
            <path d="M11.25 3.75a.75.75 0 0 0-1.5 0v.75h1.5v-.75Z" />
            <path d="M12.75 3.75a.75.75 0 0 1 1.5 0v.75h-1.5v-.75Z" />
            </svg>
        </div>
        <div className="p-3 bg-slate-700 rounded-2xl rounded-bl-sm">
            <div className="flex items-center justify-center space-x-1">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
            </div>
        </div>
    </div>
);

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading }) => {
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages, isLoading]);

    return (
        <div ref={scrollRef} className="flex-1 space-y-4 p-4 overflow-y-auto custom-scrollbar">
            {messages.map((msg) => (
                <MessageBubble key={msg.id} message={msg} />
            ))}
            {isLoading && <TypingIndicator />}
        </div>
    );
};

export default ChatWindow;
*/
