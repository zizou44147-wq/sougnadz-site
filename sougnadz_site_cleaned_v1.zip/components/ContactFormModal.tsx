import React, { useState } from 'react';
import { useLocalization } from '../hooks/useLocalization';

interface ContactFormModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const ContactFormModal: React.FC<ContactFormModalProps> = ({ isOpen, onClose }) => {
    const { t } = useLocalization();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsSubmitting(true);
        setError(null);

        const formData = new FormData(e.currentTarget);
        const email = formData.get('email') as string;

        if (!email || !email.toLowerCase().endsWith('@gmail.com')) {
            setError(t('gmailOnlyError'));
            setIsSubmitting(false);
            return;
        }

        try {
            const response = await fetch("https://formspree.io/f/xyzlzavj", {
                method: 'POST',
                body: formData,
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (response.ok) {
                setIsSubmitting(false);
                setIsSuccess(true);
                setTimeout(() => {
                    handleClose();
                }, 3000);
            } else {
                throw new Error("Failed to send message.");
            }
        } catch (err) {
            setIsSubmitting(false);
            setError("Sorry, there was an error sending your message. Please try again later.");
            console.error(err);
        }
    };
    
    const handleClose = () => {
        setIsSuccess(false);
        setIsSubmitting(false);
        setError(null);
        onClose();
    }

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-[100]" onClick={handleClose}>
            <div
                className="bg-white dark:bg-[#0f1429] rounded-lg shadow-xl p-8 w-full max-w-lg m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative"
                onClick={(e) => e.stopPropagation()}
            >
                <button onClick={handleClose} className="absolute top-4 end-4 text-gray-400 dark:text-gray-500 hover:text-gray-800 dark:hover:text-white">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>

                {isSuccess ? (
                    <div className="text-center py-10">
                        <div className="w-16 h-16 bg-green-100 dark:bg-green-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
                             <svg className="w-10 h-10 text-green-600 dark:text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                        </div>
                        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{t('contactFormSuccessTitle')}</h2>
                        <p className="mt-2 text-gray-600 dark:text-gray-400">{t('contactFormSuccessBody')}</p>
                    </div>
                ) : (
                    <>
                        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">{t('contactUs')}</h2>
                        {error && <p className="text-red-500 text-sm mb-4 bg-red-100 dark:bg-red-900/40 p-3 rounded-md">{error}</p>}
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('yourName')}</label>
                                    <input type="text" id="name" name="name" required className="mt-1 block w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
                                </div>
                                <div>
                                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('yourEmail')}</label>
                                    <input type="email" id="email" name="email" required className="mt-1 block w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
                                </div>
                            </div>
                            <div>
                                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('contactFormSubject')}</label>
                                <input type="text" id="subject" name="subject" required className="mt-1 block w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                            <div>
                                <label htmlFor="contact-message" className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('contactFormMessage')}</label>
                                <textarea id="contact-message" name="message" rows={5} required className="mt-1 block w-full bg-gray-100 dark:bg-slate-800 border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"></textarea>
                            </div>
                            <button
                                type="submit"
                                disabled={isSubmitting}
                                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md transition-colors disabled:bg-blue-400/50 disabled:cursor-wait"
                            >
                                {isSubmitting ? t('contactFormSending') : t('contactFormSendMessage')}
                            </button>
                        </form>
                    </>
                )}
                <style>{`
                    @keyframes modal-pop {
                        from { transform: scale(0.9); opacity: 0; }
                        to { transform: scale(1); opacity: 1; }
                    }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </div>
        </div>
    );
};

export default ContactFormModal;