

import React, { useState } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { User } from '../services/types';

interface ContactModalProps {
    isOpen: boolean;
    onClose: () => void;
    seller: User;
    contactInfo: { phone: string; email?: string };
    onMessageSent: () => void;
}

const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose, seller, contactInfo, onMessageSent }) => {
    const { t } = useLocalization();
    const [messageSent, setMessageSent] = useState(false);

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Mock sending message
        console.log("Sending message...");
        setMessageSent(true);
        onMessageSent();
        setTimeout(() => {
            onClose();
            setMessageSent(false); // Reset for next time
        }, 1000); // Close modal quicker
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity duration-300" onClick={onClose}>
            <div
                className="bg-[#0f1429] rounded-lg shadow-xl p-8 w-full max-w-lg m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold text-white">{t('contactModalTitle')}</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-white absolute top-8 end-8">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>

                {messageSent ? (
                    <div className="text-center py-10">
                        <p className="text-2xl text-green-400 font-semibold">{t('messageSentSuccess')}</p>
                    </div>
                ) : (
                    <>
                        <div className="bg-gray-800/50 p-4 rounded-lg mb-6">
                            <h3 className="text-lg font-semibold text-white mb-2">{t('sellerInformation')}</h3>
                            <div className="flex items-center gap-4">
                                <img src={seller.avatarUrl} alt={seller.name} className="w-16 h-16 rounded-full" />
                                <div>
                                    <p className="text-xl font-bold text-white">{seller.name}</p>
                                    <p className="text-blue-400">{contactInfo.phone}</p>
                                    {contactInfo.email && <p className="text-gray-400">{contactInfo.email}</p>}
                                </div>
                            </div>
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-gray-300">{t('yourName')}</label>
                                <input type="text" id="name" required className="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-gray-300">{t('yourEmail')}</label>
                                <input type="email" id="email" required className="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                             <div>
                                <label htmlFor="message" className="block text-sm font-medium text-gray-300">{t('message')}</label>
                                <textarea id="message" rows={4} required className="mt-1 block w-full bg-gray-800 border-gray-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500"></textarea>
                            </div>
                            <button type="submit" className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-4 rounded-md transition-colors">
                                {t('sendMessageButton')}
                            </button>
                        </form>
                    </>
                )}
                
                {/* Fix: Replaced <style jsx> with <style> to fix TypeScript error regarding invalid 'jsx' prop. */}
                <style>{`
                    @keyframes modal-pop {
                        from { transform: scale(0.9); opacity: 0; }
                        to { transform: scale(1); opacity: 1; }
                    }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </div>
        </div>
    );
};

export default ContactModal;