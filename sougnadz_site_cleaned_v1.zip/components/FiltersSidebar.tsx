import React, { useState, useEffect, useCallback, useMemo, ReactNode } from 'react';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { CATEGORY_FILTERS } from '../constants/filterConfig';
import { CAR_DATA } from '../constants/carData';
import { CAR_ENGINES } from '../constants/carEngines';
import { FilterDefinition, ListingFilters, Commune } from '../services/types';
import { useUserData } from '../hooks/useUserData';
import AddCarDetailModal from './AddCarDetailModal';
import Toast from './Toast';
import { WILAYAS } from '../constants/geodata';

interface AccordionProps {
    title: string;
    children: ReactNode;
    defaultOpen?: boolean;
}

const Accordion: React.FC<AccordionProps> = ({ title, children, defaultOpen = false }) => {
    const [isOpen, setIsOpen] = useState(defaultOpen);
    return (
        <div className="border-b border-gray-200">
            <button onClick={() => setIsOpen(!isOpen)} className="w-full flex justify-between items-center py-4 text-start">
                <span className="font-semibold text-gray-800">{title}</span>
                <svg className={`w-5 h-5 text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
            </button>
            <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-[1000px] pb-4' : 'max-h-0'}`}>
                {children}
            </div>
        </div>
    );
};


interface FiltersSidebarProps {
    categorySlug: string;
    onApplyFilters: (filters: ListingFilters) => void;
    initialFilters?: ListingFilters;
    // FIX: Made isOpen and onClose optional as they are injected by the parent layout.
    isOpen?: boolean;
    onClose?: () => void;
    isMobile?: boolean;
}

const FiltersSidebar: React.FC<FiltersSidebarProps> = ({ categorySlug, onApplyFilters, initialFilters, isOpen, onClose = () => {}, isMobile = false }) => {
    const { t } = useLocalization();
    const [filters, setFilters] = useState<ListingFilters>(initialFilters || {});
    const { userCarData, addCarModel, userEngines, addEngine } = useUserData();
    const [isAddDetailModalOpen, setIsAddDetailModalOpen] = useState(false);
    const [addDetailMode, setAddDetailMode] = useState<'BRAND_MODEL' | 'ENGINE'>('BRAND_MODEL');
    const [showToast, setShowToast] = useState(false);
    const [communes, setCommunes] = useState<Commune[]>([]);

    useEffect(() => {
        setFilters(initialFilters || {});
    }, [initialFilters]);

    useEffect(() => {
        if (filters.wilaya) {
            const selectedWilaya = WILAYAS.find(w => w.name === filters.wilaya);
            setCommunes(selectedWilaya ? selectedWilaya.communes : []);
        } else {
            setCommunes([]);
        }
    }, [filters.wilaya]);

    const categoryFilterDefs = useMemo(() => CATEGORY_FILTERS[categorySlug] || [], [categorySlug]);
    
    const combinedCarData = useMemo(() => {
        const allData = JSON.parse(JSON.stringify(CAR_DATA)); // Deep copy to avoid mutation
        userCarData.forEach(userCar => {
            const existingBrandIndex = allData.findIndex((b: { brand: string }) => b.brand.toLowerCase() === userCar.brand.toLowerCase());
            if (existingBrandIndex > -1) {
                const existingModels = new Set(allData[existingBrandIndex].models.map((m: string) => m.toLowerCase()));
                const newModels = userCar.models.filter(m => !existingModels.has(m.toLowerCase()));
                allData[existingBrandIndex].models.push(...newModels);
                allData[existingBrandIndex].models.sort();
            } else {
                allData.push(userCar);
            }
        });
        return allData.sort((a: { brand: string }, b: { brand: string }) => a.brand.localeCompare(b.brand));
    }, [userCarData]);

    const carBrands = useMemo(() => combinedCarData.map((c: { brand: string }) => c.brand), [combinedCarData]);
    const carModels = useMemo(() => {
        if (filters.marque) {
            return combinedCarData.find((c: { brand: string }) => c.brand === filters.marque)?.models || [];
        }
        return [];
    }, [filters.marque, combinedCarData]);
    
    const combinedEngines = useMemo(() => {
        const engineSet = new Set([...CAR_ENGINES, ...userEngines]);
        return Array.from(engineSet).sort();
    }, [userEngines]);


    const handleFilterChange = useCallback((key: string, value: any) => {
        setFilters(prev => {
            const newFilters = { ...prev };
            if (Array.isArray(prev[key])) { // Checkbox logic
                const currentValues = prev[key] as string[];
                const newValues = currentValues.includes(value) ? currentValues.filter(v => v !== value) : [...currentValues, value];
                newFilters[key] = newValues;
            } else { // Radio or other input logic
                 newFilters[key] = value;
            }
            if (key === 'marque') delete newFilters.modele;
            if (key === 'wilaya') delete newFilters.commune;
            if (key === 'dateRange' && value !== 'custom') {
                delete newFilters.dateFrom;
                delete newFilters.dateTo;
            }
            return newFilters;
        });
    }, []);

    const handleApply = () => {
        onApplyFilters(filters);
        onClose();
    };

    const handleReset = () => {
        setFilters({});
        onApplyFilters({});
        onClose();
    };
    
    const handleAddNew = (mode: 'BRAND_MODEL' | 'ENGINE') => {
        setAddDetailMode(mode);
        setIsAddDetailModalOpen(true);
    };
    
    const handleSaveNewDetail = (type: 'BRAND_MODEL' | 'ENGINE', data: any) => {
        if (type === 'BRAND_MODEL') {
            addCarModel(data.brand, data.model);
            setFilters(prev => ({ ...prev, marque: data.brand, modele: data.model }));
        } else if (type === 'ENGINE') {
            addEngine(data.engine);
            setFilters(prev => ({ ...prev, engine: data.engine }));
        }
        setIsAddDetailModalOpen(false);
        setShowToast(true);
    };

    const renderFilterControl = (def: FilterDefinition) => {
        const key = def.key;
        const baseClasses = "block w-full bg-gray-100 border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500";
        switch(def.type) {
            case 'radio-group':
            case 'checkbox-group':
                const type = def.type === 'radio-group' ? 'radio' : 'checkbox';
                return (
                    <div className="space-y-3">
                        {def.options?.map(opt => (
                            <label key={opt.value} className="flex items-center gap-2 cursor-pointer text-gray-700">
                                <input type={type} name={key} value={opt.value} 
                                    checked={type === 'radio' ? filters[key] === opt.value : (filters[key] as string[] || []).includes(opt.value)}
                                    onChange={() => handleFilterChange(key, opt.value)}
                                    className={`h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 bg-gray-100 ${type === 'checkbox' ? 'rounded' : ''}`} 
                                />
                                <span>{t(opt.labelKey as TranslationKey)}</span>
                            </label>
                        ))}
                    </div>
                );
            case 'select':
                let options: { label: string, value: string }[] = [];
                let placeholder = t('sellerAll');

                if (def.key === 'marque') {
                    options = carBrands.map(b => ({ label: b, value: b }));
                    placeholder = t('filterBrand');
                } else if (def.key === 'modele') {
                    options = carModels.map(m => ({ label: m, value: m }));
                    placeholder = t('filterModel');
                } else if (def.key === 'engine') {
                    options = combinedEngines.map(e => ({ label: e, value: e }));
                    placeholder = t('engine');
                } else if (def.key === 'wilaya') {
                    options = WILAYAS.map(w => ({ label: `${w.code} - ${w.name}`, value: w.name }));
                    placeholder = t('allWilayas');
                } else if (def.key === 'commune') {
                    options = communes.map(c => ({ label: `${c.code} - ${c.name}`, value: c.name }));
                    placeholder = t('selectCommune');
                } else {
                    options = (def.options || []).map(o => ({ label: t(o.labelKey as TranslationKey), value: o.value}));
                }

                const promptKey: TranslationKey | null = 
                    def.key === 'modele' ? 'modelNotFoundPrompt' :
                    def.key === 'engine' ? 'engineNotFoundPrompt' : null;

                const addMode = def.key === 'engine' ? 'ENGINE' : 'BRAND_MODEL';
                
                return (
                    <div>
                        <select 
                            id={key} 
                            name={key} 
                            value={filters[key] || ''} 
                            onChange={(e) => handleFilterChange(key, e.target.value)} 
                            className={baseClasses} 
                            disabled={(def.key === 'modele' && !filters.marque) || (def.key === 'commune' && !filters.wilaya)}
                        >
                            <option value="">{placeholder}</option>
                            {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                        </select>
                         {promptKey && (
                            <button type="button" onClick={() => handleAddNew(addMode)} className="text-xs text-blue-500 hover:underline mt-2">
                                {t(promptKey)}
                            </button>
                        )}
                    </div>
                );
            case 'range-number':
                const minKey = def.minKey || `${def.key}Min`;
                const maxKey = def.maxKey || `${def.key}Max`;
                return (
                    <div className="flex gap-2">
                        <input type="number" min="0" placeholder={t('filterMin')} value={filters[minKey] || ''} onChange={e => handleFilterChange(minKey, e.target.value)} className={baseClasses} />
                        <input type="number" min="0" placeholder={t('filterMax')} value={filters[maxKey] || ''} onChange={e => handleFilterChange(maxKey, e.target.value)} className={baseClasses} />
                    </div>
                );
            case 'date-range':
                if (filters.dateRange !== 'custom') return null;
                const minDateKey = def.minKey!;
                const maxDateKey = def.maxKey!;
                return (
                    <div className="space-y-2">
                        <div>
                            <label htmlFor={minDateKey} className="text-xs text-gray-500">{t('from')}</label>
                            <input id={minDateKey} type="date" value={filters[minDateKey] || ''} onChange={e => handleFilterChange(minDateKey, e.target.value)} className={baseClasses} />
                        </div>
                        <div>
                            <label htmlFor={maxDateKey} className="text-xs text-gray-500">{t('to')}</label>
                            <input id={maxDateKey} type="date" value={filters[maxDateKey] || ''} onChange={e => handleFilterChange(maxDateKey, e.target.value)} className={baseClasses} />
                        </div>
                    </div>
                );
            default: return null;
        }
    };

    const content = (
        <>
            <div className={`bg-white text-gray-900 flex flex-col ${isMobile ? 'h-full w-full' : 'rounded-lg border border-gray-200'}`}>
                <div className="flex-shrink-0 flex items-center justify-between p-4 border-b border-gray-200">
                    <h3 className="text-xl font-bold">{t('filterResults')}</h3>
                    {isMobile && (
                        <button onClick={onClose} className="p-2">
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                        </button>
                    )}
                </div>

                <div className="flex-grow overflow-y-auto px-4">
                    {categoryFilterDefs.map(group => (
                        <Accordion key={group.key} title={t(group.labelKey as TranslationKey)} defaultOpen={true}>
                            <div className="space-y-4">
                                {group.subFilters?.map(def => (
                                    <div key={def.key}>
                                        <label className="block text-sm font-medium text-gray-700 mb-2">{t(def.labelKey as TranslationKey)}</label>
                                        {renderFilterControl(def)}
                                    </div>
                                ))}
                            </div>
                        </Accordion>
                    ))}
                </div>

                <div className="flex-shrink-0 p-4 border-t border-gray-200 space-y-3">
                    <button onClick={handleApply} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-md transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-blue-500/40 active:translate-y-0 active:scale-95">{t('applyFilters')}</button>
                    <button onClick={handleReset} className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-6 rounded-md transition-all duration-200 active:scale-95">{t('resetFilters')}</button>
                </div>
            </div>
            <AddCarDetailModal
                isOpen={isAddDetailModalOpen}
                onClose={() => setIsAddDetailModalOpen(false)}
                onSaveSuccess={handleSaveNewDetail}
                mode={addDetailMode}
                initialBrand={filters.marque}
            />
            <Toast 
                message={t('validationSuccess')}
                show={showToast}
                onClose={() => setShowToast(false)}
            />
        </>
    );
    
    return isMobile ? content : <div className="sticky top-24">{content}</div>;
};

export default FiltersSidebar;