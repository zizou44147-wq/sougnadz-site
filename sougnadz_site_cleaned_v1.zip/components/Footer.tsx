import React from 'react';
import NavbarLogo from './NavbarLogo';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
    const { t } = useLocalization();
    
    const links: {
        store: { key: TranslationKey; to: string }[];
        about: { key: TranslationKey; to: string }[];
    } = {
        store: [
            { key: 'createStore', to: '/help' }, 
            { key: 'advertise', to: '/help' },
            { key: 'howToPost', to: '/help' },
        ],
        about: [
            { key: 'footerAbout', to: '/about' },
            { key: 'contactUs', to: '/help' },
            { key: 'privacyPolicy', to: '/privacy' },
            { key: 'terms', to: '/terms' },
        ]
    };

    return (
        <footer className="bg-gray-50 border-t border-gray-200 text-gray-600">
            <div className="container mx-auto px-4 py-12">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                    {/* Column 1: Logo & About */}
                    <div className="md:col-span-2">
                        <NavbarLogo className="text-3xl" />
                        <p className={`mt-4 max-w-md text-start`}>
                            sougnadz.com est votre plateforme de confiance pour acheter et vendre des produits et services partout en Algérie.
                        </p>
                    </div>
                    
                    {/* Column 2: Store Links */}
                    <div>
                        <h3 className={`font-bold text-gray-900 text-lg mb-4 text-start`}>{t('createStore')}</h3>
                        <ul className={`space-y-2 text-start`}>
                             {links.store.map(link => (
                                <li key={link.key}>
                                    <Link to={link.to} className="hover:text-gray-900 transition-colors">
                                        {t(link.key)}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* Column 3: About Links */}
                    <div>
                        <h3 className={`font-bold text-gray-900 text-lg mb-4 text-start`}>{t('footerAbout')}</h3>
                         <ul className={`space-y-2 text-start`}>
                            {links.about.map(link => (
                                <li key={link.key}>
                                     <Link to={link.to} className="hover:text-gray-900 transition-colors">
                                        {t(link.key)}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>

                <div className="mt-12 border-t border-gray-200 pt-8 flex flex-col sm:flex-row justify-between items-center">
                    <p className="text-sm">© {new Date().getFullYear()} sougnadz.com. {t('rightsReserved')}</p>
                    <div className="flex gap-4 mt-4 sm:mt-0">
                       {/* Social Icons would go here */}
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;