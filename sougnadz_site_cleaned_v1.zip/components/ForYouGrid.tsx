import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Listing } from '../services/types';
import { MOCK_LISTINGS } from '../constants/mockData';
import { useLocalization } from '../hooks/useLocalization';
import ListingGrid from './ListingGrid';

interface ForYouGridProps {
    market: 'dz' | 'europe';
}

const ForYouGrid: React.FC<ForYouGridProps> = ({ market }) => {
    const { t } = useLocalization();
    const [recommendedListings, setRecommendedListings] = useState<Listing[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const generateRecommendations = async () => {
            setLoading(true);
            try {
                // Filter all listings by the specified market
                const marketListings = MOCK_LISTINGS.filter(l => (l.market || 'dz') === market);

                const viewedIds: number[] = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
                const favoriteIds: number[] = JSON.parse(localStorage.getItem('favoriteListings') || '[]');
                
                const userActivityIds = [...new Set([...viewedIds, ...favoriteIds])];

                // Filter user activity to only include items from the current market
                const userActivityListings = userActivityIds
                    .map(id => marketListings.find(l => l.id === id))
                    .filter((l): l is Listing => Boolean(l))
                    .map(l => ({ id: l.id, title: l.title, category: l.category, price: l.price }));

                if (userActivityListings.length === 0) {
                    // Fallback: show 8 most recent listings from the current market
                    const recentListings = [...marketListings]
                        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                        .slice(0, 8);
                    setRecommendedListings(recentListings);
                    return;
                }

                const availableListings = marketListings
                    .filter(l => !userActivityIds.includes(l.id))
                    .map(l => ({ id: l.id, title: l.title, category: l.category, price: l.price, description: l.description?.substring(0, 100) }));

                if (!process.env.API_KEY) {
                    throw new Error("API key not found.");
                }

                const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

                const prompt = `You are a recommendation engine for sougnadz.com. Based on the user's activity (recently viewed and favorited items), select 8 listings from the 'Available Listings' that would be most relevant to the user for the '${market}' market.

                User Activity:
                ${JSON.stringify(userActivityListings)}

                Available Listings (sample from ${market} market):
                ${JSON.stringify(availableListings.slice(0, 50))}

                Your response MUST be ONLY a JSON array of the recommended listing IDs. Example: [200, 316, 202, 203].`;
                
                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: prompt,
                });

                const cleanedText = response.text.replace(/```json|```/g, '').trim();
                const recommendedIds: number[] = JSON.parse(cleanedText);

                if (!Array.isArray(recommendedIds)) {
                     throw new Error("AI did not return a valid array of IDs.");
                }

                const listingMap = new Map(MOCK_LISTINGS.map(l => [l.id, l]));
                const finalRecs = recommendedIds
                    .map(id => listingMap.get(id))
                    .filter((l): l is Listing => Boolean(l));
                
                if (finalRecs.length < 8) {
                    const recentListings = [...marketListings]
                        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
                    const finalRecsIds = new Set(finalRecs.map(l => l.id));
                    const padding = recentListings.filter(l => !finalRecsIds.has(l.id)).slice(0, 8 - finalRecs.length);
                    finalRecs.push(...padding);
                }

                setRecommendedListings(finalRecs.slice(0, 8));

            } catch (error) {
                console.error("Failed to generate recommendations, using fallback:", error);
                 const recentListings = [...MOCK_LISTINGS.filter(l => (l.market || 'dz') === market)]
                    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                    .slice(0, 8);
                setRecommendedListings(recentListings);
            } finally {
                setLoading(false);
            }
        };

        generateRecommendations();
    }, [market]);
    
    if (!loading && recommendedListings.length === 0) {
        return null;
    }

    return (
        <section className="py-12 bg-transparent">
            <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-white mb-6">{t('forYou')}</h2>
                <ListingGrid 
                    listings={recommendedListings} 
                    loading={loading} 
                    noResults={false}
                />
            </div>
        </section>
    );
};

export default ForYouGrid;
