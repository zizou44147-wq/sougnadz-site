import React, { useState, useRef, useEffect } from 'react';
import { useGuestbook, GuestbookMessage } from '../hooks/useGuestbook';
import { useLocalization } from '../hooks/useLocalization';
import { useAuth } from '../hooks/useAuth';
import { useLocation } from 'react-router-dom';
import { formatTimeAgo } from '../utils/time';
import SendIcon from './icons/SendIcon';
import MoreIcon from './icons/MoreIcon';
import PinIcon from './icons/PinIcon';
import PencilIcon from './icons/PencilIcon';
import TrashIcon from './icons/TrashIcon';

// This is the hardcoded ID for the site owner.
// To test as the owner, uncomment the corresponding line in `hooks/useAuth.tsx`.
const SITE_OWNER_ID = 'site-owner-admin-123';

const Guestbook: React.FC = () => {
    const { messages, addMessage, deleteMessage, editMessage, togglePinMessage, guestMessageIds } = useGuestbook();
    const { t, language } = useLocalization();
    const { currentUser } = useAuth();
    
    const [newMessage, setNewMessage] = useState('');
    const [editingMessage, setEditingMessage] = useState<{ id: number; text: string } | null>(null);
    const [activeMenu, setActiveMenu] = useState<number | null>(null);
    const [isVisible, setIsVisible] = useState(true);
    
    const listRef = useRef<HTMLUListElement>(null);
    const menuRefs = useRef<{ [key: number]: HTMLDivElement }>({});
    const inputRef = useRef<HTMLInputElement>(null);
    const wasLoggedIn = useRef(!!currentUser);
    const lastScrollY = useRef(0);
    const location = useLocation();
    const isHomePage = location.pathname === '/';

    // --- Intelligent Visibility ("Phantom Panel") ---
    useEffect(() => {
        if (!isHomePage) {
            setIsVisible(false); // Hide on all pages except home
            return;
        }

        const handleScroll = () => {
            const currentScrollY = window.scrollY;
            if (currentScrollY > lastScrollY.current && currentScrollY > 100) {
                setIsVisible(false); // Scrolling down
            } else if (currentScrollY < lastScrollY.current) {
                setIsVisible(true); // Scrolling up
            }
            lastScrollY.current = currentScrollY <= 0 ? 0 : currentScrollY;
        };

        window.addEventListener('scroll', handleScroll, { passive: true });
        return () => window.removeEventListener('scroll', handleScroll);
    }, [isHomePage]);


    // Auto-focus logic after login
    useEffect(() => {
        if (currentUser && !wasLoggedIn.current) {
            setTimeout(() => inputRef.current?.focus(), 100);
        }
        wasLoggedIn.current = !!currentUser;
    }, [currentUser]);

    // Animate new messages
    useEffect(() => {
        if (listRef.current) {
            const firstChild = listRef.current.firstChild as HTMLLIElement;
            if(firstChild && !firstChild.classList.contains('animate-new-message')) {
                const isPinned = firstChild.getAttribute('data-pinned') === 'true';
                if (!isPinned) { // Only animate non-pinned new messages
                    firstChild.classList.add('animate-new-message');
                    setTimeout(() => firstChild.classList.remove('animate-new-message'), 700);
                }
            }
        }
    }, [messages]);
    
    // Close menu on outside click
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (activeMenu !== null && menuRefs.current[activeMenu] && !menuRefs.current[activeMenu].contains(event.target as Node)) {
                setActiveMenu(null);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [activeMenu]);


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const guestId = `guest${Date.now()}`;
        const author = currentUser || {
            id: guestId,
            name: language === 'ar' ? 'زائر' : 'Visiteur',
            avatar: `https://i.pravatar.cc/150?u=${guestId}`
        };
        addMessage(newMessage, author);
        setNewMessage('');
    };
    
    const handleEditSave = () => {
        if (editingMessage) {
            editMessage(editingMessage.id, editingMessage.text);
            setEditingMessage(null);
        }
    };
    
    const handleDelete = (id: number) => {
        if (window.confirm("Are you sure you want to delete this message?")) {
            deleteMessage(id);
        }
        setActiveMenu(null);
    };

    const pinnedMessages = messages.filter(m => m.isPinned);
    const regularMessages = messages.filter(m => !m.isPinned);

    const renderMessage = (msg: GuestbookMessage) => {
        const isEditing = editingMessage?.id === msg.id;
        const isOwner = currentUser?.id === SITE_OWNER_ID;
        const isAuthor = currentUser?.id === msg.author.id;
        const isGuestAuthorOfThisMessage = !currentUser && guestMessageIds.includes(msg.id);

        const canEditOrDelete = isOwner || isAuthor || isGuestAuthorOfThisMessage;
        const canPin = isOwner;
        
        return (
            <li 
                key={msg.id}
                data-pinned={msg.isPinned} 
                className={`p-3 rounded-lg border relative group ${msg.isPinned ? 'bg-amber-900/20 border-amber-500/50' : 'bg-slate-800/70 border-slate-700/50'}`}
            >
                {isEditing ? (
                    <div className="space-y-2">
                        <textarea
                            value={editingMessage.text}
                            onChange={(e) => setEditingMessage({ ...editingMessage, text: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-600 rounded-md p-2 text-sm text-slate-200"
                        />
                        <div className="flex justify-end gap-2">
                            <button onClick={() => setEditingMessage(null)} className="text-xs px-2 py-1 rounded bg-slate-600 hover:bg-slate-500">{t('cancel')}</button>
                            <button onClick={handleEditSave} className="text-xs px-2 py-1 rounded bg-blue-600 hover:bg-blue-500">{t('save')}</button>
                        </div>
                    </div>
                ) : (
                    <>
                        <div className="flex items-start gap-2">
                            <img src={msg.author.avatar} alt={msg.author.name} className="w-6 h-6 rounded-full mt-1"/>
                            <div className="flex-1">
                                <p className="text-xs font-bold text-slate-300">{msg.author.name}</p>
                                <p className="text-sm text-slate-200 break-words pr-6">
                                    {msg.text}
                                </p>
                            </div>
                        </div>
                        <p className="text-xs text-slate-500 text-right mt-1">{formatTimeAgo(msg.createdAt, t, language)}</p>
                    </>
                )}
                
                {(canEditOrDelete || canPin) && !isEditing && (
                    <div className="absolute top-1 right-1" ref={(el) => { if (el) menuRefs.current[msg.id] = el; }}>
                        <button onClick={() => setActiveMenu(activeMenu === msg.id ? null : msg.id)} className="p-1 rounded-full opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity">
                            <MoreIcon className="w-4 h-4 text-slate-400" />
                        </button>
                        {activeMenu === msg.id && (
                            <div className="absolute right-0 mt-2 w-40 bg-slate-900 border border-slate-700 rounded-md shadow-lg z-10 py-1">
                                {canPin && (
                                    <button onClick={() => { togglePinMessage(msg.id); setActiveMenu(null); }} className="w-full text-left flex items-center gap-2 px-3 py-1.5 text-sm text-slate-200 hover:bg-slate-800">
                                        <PinIcon className={`w-4 h-4 ${msg.isPinned ? 'text-amber-400' : ''}`} />{t(msg.isPinned ? 'unpinMessage' : 'pinMessage')}
                                    </button>
                                )}
                                {canEditOrDelete && (
                                    <>
                                        <button onClick={() => { setEditingMessage({id: msg.id, text: msg.text}); setActiveMenu(null); }} className="w-full text-left flex items-center gap-2 px-3 py-1.5 text-sm text-slate-200 hover:bg-slate-800">
                                            <PencilIcon className="w-4 h-4" />{t('editMessage')}
                                        </button>
                                        <button onClick={() => handleDelete(msg.id)} className="w-full text-left flex items-center gap-2 px-3 py-1.5 text-sm text-red-500 hover:bg-slate-800">
                                            <TrashIcon className="w-4 h-4" />{t('deleteMessage')}
                                        </button>
                                    </>
                                )}
                            </div>
                        )}
                    </div>
                )}
            </li>
        );
    };

    return (
        <>
            <div 
                className={`hidden lg:block fixed top-28 right-0 bottom-8 w-80 z-[60] mr-4 transition-transform duration-700`}
                style={{ 
                    transform: isVisible ? 'translateX(0)' : 'translateX(calc(100% + 2rem))',
                    transitionTimingFunction: 'cubic-bezier(0.68, -0.55, 0.27, 1.55)'
                }}
            >
                <div className="h-full bg-slate-900/80 backdrop-blur-md border border-slate-700 rounded-2xl shadow-lg flex flex-col">
                    <div className="p-4 border-b border-slate-700 flex-shrink-0">
                        <h3 className="font-bold text-lg text-white text-center">{t('guestbookTitle')}</h3>
                        <p className="text-center text-sm font-bold text-orange-500 mt-1">{t('guestbookCount', { count: messages.length })}</p>
                    </div>
                    
                    <ul ref={listRef} className="flex-grow p-3 space-y-3 overflow-y-auto">
                        {pinnedMessages.length > 0 && (
                            <>
                                <h4 className="text-xs font-bold uppercase text-amber-500 px-1">{t('pinnedMessagesTitle')}</h4>
                                {pinnedMessages.map(renderMessage)}
                                {regularMessages.length > 0 && <hr className="border-amber-500/20 my-2" />}
                            </>
                        )}
                        {regularMessages.map(renderMessage)}
                    </ul>

                    <div className="p-4 border-t border-slate-700 flex-shrink-0">
                        <form onSubmit={handleSubmit}>
                            <div className="flex items-center gap-2">
                                <input
                                    ref={inputRef}
                                    type="text"
                                    value={newMessage}
                                    onChange={(e) => setNewMessage(e.target.value)}
                                    placeholder={t('guestbookPlaceholder')}
                                    className="flex-grow bg-slate-800 border border-slate-600 rounded-full py-2 px-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                                <button type="submit" disabled={!newMessage.trim()} className="bg-blue-600 text-white p-2.5 rounded-full hover:bg-blue-700 disabled:bg-slate-600 transition-colors">
                                    <SendIcon className="w-5 h-5"/>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <style>{`
                @keyframes new-message-anim {
                    from { opacity: 0; transform: translateY(-20px) scale(0.95); }
                    to { opacity: 1; transform: translateY(0) scale(1); }
                }
                .animate-new-message { animation: new-message-anim 0.5s ease-out forwards; }
            `}</style>
        </>
    );
};

export default Guestbook;