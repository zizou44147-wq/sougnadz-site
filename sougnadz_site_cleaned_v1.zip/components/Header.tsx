import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import NavbarLogo from './NavbarLogo';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import AlgeriaFlagIcon from './icons/AlgeriaFlagIcon';
import UKFlagIcon from './icons/UKFlagIcon';
import RefreshIcon from './icons/RefreshIcon';
import { Language } from '../services/types';
import { CATEGORIES } from '../constants/categories';
import MenuIcon from './icons/MenuIcon';
import CloseIcon from './icons/CloseIcon';
import CalendarHistoryIcon from './icons/CalendarHistoryIcon';
import { useAuth } from '../hooks/useAuth';

const Header: React.FC = () => {
    const { language, setLanguage, t } = useLocalization();
    const navigate = useNavigate();
    const { isLoggedIn, logout, openAuthModal } = useAuth();
    
    const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
    const [isCategoryMenuOpen, setIsCategoryMenuOpen] = useState(false);
    const [isSalesMenuOpen, setIsSalesMenuOpen] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
    const [selectedDate, setSelectedDate] = useState('');
    const [isMobileSalesOpen, setIsMobileSalesOpen] = useState(false);
    
    const userMenuRef = useRef<HTMLDivElement>(null);
    const categoryMenuRef = useRef<HTMLDivElement>(null);
    const salesMenuRef = useRef<HTMLDivElement>(null);
    const langMenuRef = useRef<HTMLDivElement>(null);

    const handleLogout = () => {
        logout();
        setIsUserMenuOpen(false);
        setIsMobileMenuOpen(false);
        navigate('/');
    };
    
    const handlePublishClick = () => {
        if (isLoggedIn) {
            navigate('/post-ad');
        } else {
            openAuthModal();
        }
        setIsMobileMenuOpen(false);
    };

    const toggleLanguage = (lang: Language) => {
        setLanguage(lang);
        setIsLangMenuOpen(false);
    };

    const handleDateFilterClick = (filter: 'today' | 'yesterday' | string) => {
        const getISODateString = (date: Date) => date.toISOString().split('T')[0];

        let dateFrom = '';
        let dateTo = '';

        if (filter === 'today') {
            dateFrom = dateTo = getISODateString(new Date());
        } else if (filter === 'yesterday') {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            dateFrom = dateTo = getISODateString(yesterday);
        } else if (filter) { // A specific date string
            dateFrom = dateTo = filter;
        }

        if (dateFrom) {
            const params = new URLSearchParams();
            params.set('dateRange', 'custom');
            params.set('dateFrom', dateFrom);
            params.set('dateTo', dateTo);
            navigate(`/category/all?${params.toString()}`);
        }

        setIsSalesMenuOpen(false);
        setIsMobileMenuOpen(false); // for mobile
    };

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) setIsUserMenuOpen(false);
            if (categoryMenuRef.current && !categoryMenuRef.current.contains(event.target as Node)) setIsCategoryMenuOpen(false);
            if (salesMenuRef.current && !salesMenuRef.current.contains(event.target as Node)) setIsSalesMenuOpen(false);
            if (langMenuRef.current && !langMenuRef.current.contains(event.target as Node)) setIsLangMenuOpen(false);
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const navLinks: { key: TranslationKey, path: string }[] = [
        { key: 'home', path: '/' },
        { key: 'help', path: '/help' },
    ];
    
    const MobileNavLink: React.FC<{path: string, children: React.ReactNode}> = ({ path, children }) => (
        <Link to={path} onClick={() => setIsMobileMenuOpen(false)} className="block px-4 py-3 text-lg text-gray-700 hover:bg-gray-100">
            {children}
        </Link>
    );

    const LanguageIcon = () => {
        const iconClass = "w-6 h-auto rounded-sm";
        switch (language) {
            case 'ar':
                return <AlgeriaFlagIcon className={iconClass} />;
            case 'en':
                return <UKFlagIcon className={iconClass} />;
            case 'fr':
            default:
                return (
                    <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center">
                        <span className="font-bold text-xs text-white">Fr</span>
                    </div>
                );
        }
    };

    return (
        <>
            <header className="bg-white/80 backdrop-blur-sm sticky top-0 z-40 border-b border-gray-200">
                <div className="container mx-auto px-4">
                    <div className="flex items-center justify-between h-16">
                        {/* Left Side: Logo & Desktop Nav */}
                        <div className="flex items-center gap-8">
                            <NavbarLogo className="text-3xl" />
                            <nav className="hidden md:flex items-center gap-6">
                                {navLinks.map(link => (
                                    <Link key={link.key} to={link.path} className="text-gray-600 hover:text-gray-900 transition-colors duration-300">
                                        {t(link.key)}
                                    </Link>
                                ))}
                                <div className="relative" ref={salesMenuRef}>
                                    <button onClick={() => setIsSalesMenuOpen(!isSalesMenuOpen)} className="text-gray-600 hover:text-gray-900 transition-colors duration-300 flex items-center gap-1">
                                        {t('salesHistory')}
                                        <svg className={`w-4 h-4 transition-transform ${isSalesMenuOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                                    </button>
                                    <div className={`absolute mt-2 w-60 bg-white border border-gray-200 rounded-md shadow-lg py-1 start-0 transition-all duration-300 ease-out origin-top-left ${isSalesMenuOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
                                        <button onClick={() => handleDateFilterClick('today')} className={`w-full flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 text-start`}>
                                            <CalendarHistoryIcon className="w-4 h-4" /> {t('salesToday')}
                                        </button>
                                        <button onClick={() => handleDateFilterClick('yesterday')} className={`w-full flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 text-start`}>
                                            <CalendarHistoryIcon className="w-4 h-4" /> {t('salesYesterday')}
                                        </button>
                                        <div className="border-t border-gray-100 my-1"></div>
                                        <div className="p-2">
                                            <label className="text-xs text-gray-500 px-2">{t('salesByDate')}</label>
                                            <div className="flex items-center gap-2 mt-1">
                                                <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="w-full border-gray-300 bg-white text-gray-900 rounded-md shadow-sm text-sm focus:ring-blue-500 focus:border-blue-500" />
                                                <button onClick={() => handleDateFilterClick(selectedDate)} disabled={!selectedDate} className="px-3 py-1 bg-blue-600 text-white text-sm font-semibold rounded-md hover:bg-blue-700 disabled:bg-blue-300">
                                                    {t('go')}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="relative" ref={categoryMenuRef}>
                                    <button onClick={() => setIsCategoryMenuOpen(!isCategoryMenuOpen)} className="text-gray-600 hover:text-gray-900 transition-colors duration-300 flex items-center gap-1">
                                        {t('categories')}
                                        <svg className={`w-4 h-4 transition-transform ${isCategoryMenuOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                                    </button>
                                    <div className={`absolute mt-2 w-56 bg-white border border-gray-200 rounded-md shadow-lg py-1 start-0 transition-all duration-300 ease-out origin-top-left ${isCategoryMenuOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
                                        {CATEGORIES.map(cat => (
                                            <Link key={cat.slug} to={`/category/${cat.slug}`} onClick={() => setIsCategoryMenuOpen(false)} className={`w-full block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 text-start`}>
                                                {t(cat.labelKey)}
                                            </Link>
                                        ))}
                                    </div>
                                </div>
                            </nav>
                        </div>

                        {/* Right Side: Actions */}
                        <div className="flex items-center gap-4">
                            {/* Language & Theme controls - always visible */}
                            <div className="relative" ref={langMenuRef}>
                                <button onClick={() => setIsLangMenuOpen(!isLangMenuOpen)} className="p-2 h-10 w-10 flex items-center justify-center rounded-full text-gray-600 hover:bg-gray-100 transition-colors" aria-label="Change language">
                                    <LanguageIcon />
                                </button>
                                <div className={`absolute mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg py-1 end-0 transition-all duration-300 ease-out origin-top-right ${isLangMenuOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
                                    <button onClick={() => toggleLanguage('fr')} className={`w-full flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-start ${language === 'fr' ? 'text-blue-500 font-bold' : 'text-gray-700'}`}>
                                        <div className="w-5 h-5 bg-orange-600 rounded-full flex items-center justify-center">
                                            <span className="font-bold text-[10px] text-white">Fr</span>
                                        </div>
                                        <span>French</span>
                                    </button>
                                    <button onClick={() => toggleLanguage('ar')} className={`w-full flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-start ${language === 'ar' ? 'text-blue-500 font-bold' : 'text-gray-700'}`}>
                                        <AlgeriaFlagIcon className="w-5 h-auto rounded-sm" /> <span>العربية</span>
                                    </button>
                                    <button onClick={() => toggleLanguage('en')} className={`w-full flex items-center gap-2 px-4 py-2 text-sm hover:bg-gray-100 text-start ${language === 'en' ? 'text-blue-500 font-bold' : 'text-gray-700'}`}>
                                        <UKFlagIcon className="w-5 h-auto rounded-sm" /> <span>{t('english')}</span>
                                    </button>
                                </div>
                            </div>

                            {/* Desktop-only Auth/User controls */}
                            <div className="hidden md:flex items-center gap-4 ml-2">
                                <button onClick={handlePublishClick} className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded-full transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg active:scale-95">
                                    {t('publishAd')}
                                </button>
                                {isLoggedIn ? (
                                    <div className="relative" ref={userMenuRef}>
                                        <button onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}>
                                            <img src="https://i.pravatar.cc/150?u=mockuser" alt="User Avatar" className="w-9 h-9 rounded-full border-2 border-blue-500" />
                                        </button>
                                        <div className={`absolute mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg py-1 end-0 transition-all duration-300 ease-out origin-top-right ${isUserMenuOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
                                            <Link to="/profile" onClick={() => setIsUserMenuOpen(false)} className={`w-full block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 text-start`}>{t('profile')}</Link>
                                            <Link to="/myAds" onClick={() => setIsUserMenuOpen(false)} className={`w-full block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 text-start`}>{t('myAds')}</Link>
                                            <Link to="/favorites" onClick={() => setIsUserMenuOpen(false)} className={`w-full block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 text-start`}>{t('favorites')}</Link>
                                            <Link to="/saved-searches" onClick={() => setIsUserMenuOpen(false)} className={`w-full block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 text-start`}>{t('savedSearches')}</Link>
                                            <div className="border-t border-gray-200 my-1"></div>
                                            <button onClick={handleLogout} className={`w-full block px-4 py-2 text-sm text-red-500 hover:bg-gray-100 text-start`}>{t('logout')}</button>
                                        </div>
                                    </div>
                                ) : (
                                    <button onClick={openAuthModal} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg active:scale-95">
                                        {t('login')}
                                    </button>
                                )}
                            </div>

                            {/* Mobile Hamburger Menu Button */}
                            <button onClick={() => setIsMobileMenuOpen(true)} className="p-2 rounded-full text-gray-600 hover:bg-gray-100 md:hidden" aria-label="Open menu">
                                <MenuIcon className="w-6 h-6" />
                            </button>
                        </div>
                    </div>
                </div>
            </header>

            {/* Mobile Menu Panel */}
            <div className={`fixed inset-0 z-50 transition-opacity duration-300 md:hidden ${isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
                {/* Backdrop */}
                <div className="absolute inset-0 bg-black/40" onClick={() => setIsMobileMenuOpen(false)}></div>
                {/* Panel */}
                <div className={`relative ml-auto h-full w-full max-w-xs bg-white shadow-xl transition-transform duration-300 ease-in-out ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
                    <div className="flex items-center justify-between p-4 border-b border-gray-200">
                        <NavbarLogo className="text-2xl" />
                        <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 -mr-2 rounded-full text-gray-500 hover:bg-gray-100" aria-label="Close menu">
                            <CloseIcon className="w-5 h-5" />
                        </button>
                    </div>
                    <nav className="py-4">
                        {isLoggedIn ? (
                            <div className="px-4 py-3 border-b border-gray-200">
                                <div className="flex items-center gap-3">
                                    <img src="https://i.pravatar.cc/150?u=mockuser" alt="User Avatar" className="w-10 h-10 rounded-full border-2 border-blue-500" />
                                    <div>
                                        <p className="font-bold text-gray-800">Mock User</p>
                                        <Link to="/profile" onClick={() => setIsMobileMenuOpen(false)} className="text-sm text-blue-500 hover:underline">{t('profile')}</Link>
                                    </div>
                                </div>
                                <div className="mt-4 space-y-2">
                                     <MobileNavLink path="/myAds">{t('myAds')}</MobileNavLink>
                                     <MobileNavLink path="/favorites">{t('favorites')}</MobileNavLink>
                                     <MobileNavLink path="/saved-searches">{t('savedSearches')}</MobileNavLink>
                                </div>
                            </div>
                        ) : (
                            <div className="px-4 py-4 border-b border-gray-200">
                                <button onClick={() => { openAuthModal(); setIsMobileMenuOpen(false); }} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-4 rounded-lg transition-colors">
                                    {t('login')}
                                </button>
                            </div>
                        )}
                        <div className="py-2 border-b border-gray-200">
                            <MobileNavLink path="/">{t('home')}</MobileNavLink>
                             <div>
                                <button onClick={() => setIsMobileSalesOpen(!isMobileSalesOpen)} className="w-full flex justify-between items-center px-4 py-3 text-lg text-gray-700 hover:bg-gray-100">
                                    <span>{t('salesHistory')}</span>
                                    <svg className={`w-5 h-5 text-gray-500 transition-transform ${isMobileSalesOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                                </button>
                                {isMobileSalesOpen && (
                                    <div className="pl-8 pb-2 bg-gray-50">
                                        <button onClick={() => handleDateFilterClick('today')} className="block w-full text-left py-2 text-gray-600 hover:text-black">{t('salesToday')}</button>
                                        <button onClick={() => handleDateFilterClick('yesterday')} className="block w-full text-left py-2 text-gray-600 hover:text-black">{t('salesYesterday')}</button>
                                        <div className="pt-2 pr-4">
                                            <label className="text-sm text-gray-500">{t('salesByDate')}</label>
                                            <input type="date" onChange={(e) => { if(e.target.value) handleDateFilterClick(e.target.value) }} className="w-full mt-1 p-2 border rounded-md text-sm bg-white border-gray-300" />
                                        </div>
                                    </div>
                                )}
                            </div>
                             <MobileNavLink path="/category/all">{t('categories')}</MobileNavLink>
                             <MobileNavLink path="/help">{t('help')}</MobileNavLink>
                        </div>
                         <div className="p-4">
                            <button onClick={handlePublishClick} className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-2.5 px-4 rounded-lg transition-colors">
                                {t('publishAd')}
                            </button>
                        </div>
                        {isLoggedIn && (
                             <div className="px-4 py-4 border-t border-gray-200">
                                <button onClick={handleLogout} className="w-full text-start px-4 py-3 text-lg text-red-500 hover:bg-gray-100 rounded-md">{t('logout')}</button>
                            </div>
                        )}
                    </nav>
                </div>
            </div>
        </>
    );
};

export default Header;