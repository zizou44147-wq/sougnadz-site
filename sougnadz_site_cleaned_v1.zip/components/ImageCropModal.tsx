import React, { useRef, useEffect, useState } from 'react';

interface ImageCropModalProps {
    src: string;
    onClose: () => void;
    onCropComplete: (dataUrl: string) => void;
}

const ImageCropModal: React.FC<ImageCropModalProps> = ({ src, onClose, onCropComplete }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const cropOverlayRef = useRef<HTMLDivElement>(null);
    const imageRef = useRef<HTMLImageElement>(new Image());

    const [crop, setCrop] = useState({ x: 10, y: 10, width: 100, height: 100 });
    const [isDragging, setIsDragging] = useState(false);
    const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

    const draw = () => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        const img = imageRef.current;
        if (!canvas || !ctx) return;

        // Scale image to fit canvas
        const hRatio = canvas.width / img.width;
        const vRatio = canvas.height / img.height;
        const ratio = Math.min(hRatio, vRatio);
        const centerShift_x = (canvas.width - img.width * ratio) / 2;
        const centerShift_y = (canvas.height - img.height * ratio) / 2;

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, img.width, img.height, centerShift_x, centerShift_y, img.width * ratio, img.height * ratio);
    };

    useEffect(() => {
        const img = imageRef.current;
        img.src = src;
        img.onload = () => {
            const canvas = canvasRef.current;
            if (!canvas) return;
            // Set initial crop to be a square in the center
            const size = Math.min(canvas.width, canvas.height) * 0.8;
            setCrop({
                x: (canvas.width - size) / 2,
                y: (canvas.height - size) / 2,
                width: size,
                height: size,
            });
            draw();
        };
    }, [src]);

    useEffect(() => {
        const overlay = cropOverlayRef.current;
        if (overlay) {
            overlay.style.left = `${crop.x}px`;
            overlay.style.top = `${crop.y}px`;
            overlay.style.width = `${crop.width}px`;
            overlay.style.height = `${crop.height}px`;
        }
    }, [crop]);

    const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
        setIsDragging(true);
        setDragStart({ x: e.clientX, y: e.clientY });
    };

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!isDragging) return;
        const dx = e.clientX - dragStart.x;
        const dy = e.clientY - dragStart.y;
        setCrop(c => ({ ...c, x: c.x + dx, y: c.y + dy }));
        setDragStart({ x: e.clientX, y: e.clientY });
    };

    const handleMouseUp = () => {
        setIsDragging(false);
    };

    const handleCrop = () => {
        const canvas = canvasRef.current;
        const img = imageRef.current;
        if (!canvas) return;

        const hRatio = canvas.width / img.width;
        const vRatio = canvas.height / img.height;
        const ratio = Math.min(hRatio, vRatio);
        const centerShift_x = (canvas.width - img.width * ratio) / 2;
        const centerShift_y = (canvas.height - img.height * ratio) / 2;
        
        const sourceX = (crop.x - centerShift_x) / ratio;
        const sourceY = (crop.y - centerShift_y) / ratio;
        const sourceWidth = crop.width / ratio;
        const sourceHeight = crop.height / ratio;

        const cropCanvas = document.createElement('canvas');
        cropCanvas.width = sourceWidth;
        cropCanvas.height = sourceHeight;
        const cropCtx = cropCanvas.getContext('2d');
        if (!cropCtx) return;

        cropCtx.drawImage(
            img,
            sourceX,
            sourceY,
            sourceWidth,
            sourceHeight,
            0,
            0,
            sourceWidth,
            sourceHeight
        );

        onCropComplete(cropCanvas.toDataURL('image/jpeg', 0.9));
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-[60]" onMouseUp={handleMouseUp}>
            <div className="bg-white p-4 rounded-lg shadow-xl" onClick={e => e.stopPropagation()}>
                <h3 className="font-bold text-lg mb-4">Recadrer l'image</h3>
                <div 
                    className="relative cursor-move select-none"
                    style={{ width: '500px', height: '400px' }}
                    onMouseMove={handleMouseMove}
                >
                    <canvas ref={canvasRef} width="500" height="400" />
                    <div 
                        ref={cropOverlayRef}
                        className="absolute border-2 border-dashed border-white"
                        onMouseDown={handleMouseDown}
                    >
                         <div className="absolute -top-1 -left-1 w-2 h-2 bg-white rounded-full"></div>
                         <div className="absolute -top-1 -right-1 w-2 h-2 bg-white rounded-full"></div>
                         <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-white rounded-full"></div>
                         <div className="absolute -bottom-1 -right-1 w-2 h-2 bg-white rounded-full"></div>
                    </div>
                </div>
                 <div className="mt-4 flex justify-end gap-3">
                    <button onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 font-semibold">
                        Annuler
                    </button>
                    <button onClick={handleCrop} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-semibold">
                        Recadrer et Confirmer
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ImageCropModal;
