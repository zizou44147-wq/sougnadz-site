import React, { useEffect, useState, useRef, useCallback, memo } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchListings } from '../services/api';
import { Listing, ListingFilters } from '../services/types';
import ListingCard from './ListingCard';
import { useLocalization } from '../hooks/useLocalization';
import AutomobileListingCard from './AutomobileListingCard';

// A simple chevron icon for the navigation buttons
const ChevronIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
  </svg>
);

// A skeleton loader to show while listings are being fetched
const CarouselSkeleton: React.FC = () => (
    <div className="flex gap-6">
        {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="w-[300px] sm:w-[320px] md:w-[350px] flex-shrink-0">
                <div className="bg-gray-100 dark:bg-slate-800 rounded-xl h-[420px] animate-pulse overflow-hidden border border-gray-200 dark:border-slate-700">
                    <div className="w-full h-56 bg-gray-200 dark:bg-slate-700"></div>
                     <div className="p-4 space-y-3">
                        <div className="h-5 bg-gray-200 dark:bg-slate-700 rounded w-full"></div>
                        <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded w-3/4"></div>
                        <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded w-full mt-4"></div>
                        <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded w-2/3"></div>
                         <div className="pt-4 flex justify-between items-center">
                            <div className="h-8 bg-gray-200 dark:bg-slate-700 rounded w-1/3"></div>
                            <div className="h-6 bg-gray-200 dark:bg-slate-700 rounded-full w-1/4"></div>
                        </div>
                    </div>
                </div>
            </div>
        ))}
    </div>
);

interface ListingCarouselProps {
    title: string;
    filters: ListingFilters;
    onViewAllClick: () => void;
    excludeId?: number;
}

const ListingCarousel: React.FC<ListingCarouselProps> = ({ title, filters, onViewAllClick, excludeId }) => {
    const [listings, setListings] = useState<Listing[]>([]);
    const [loading, setLoading] = useState(true);
    const scrollerRef = useRef<HTMLDivElement>(null);
    const [canScrollLeft, setCanScrollLeft] = useState(false);
    const [canScrollRight, setCanScrollRight] = useState(false);
    const { t } = useLocalization();
    const navigate = useNavigate();

    useEffect(() => {
        const getListings = async () => {
            setLoading(true);
            try {
                const data = await fetchListings(filters, 10, excludeId);
                setListings(data);
            } catch (error) {
                console.error(`Failed to fetch listings for ${title}:`, error);
                setListings([]);
            } finally {
                setLoading(false);
            }
        };
        getListings();
    }, [filters, title, excludeId]);
    
    const checkScrollability = useCallback(() => {
        const el = scrollerRef.current;
        if (el) {
            const tolerance = 2;
            const hasHorizontalScroll = el.scrollWidth > el.clientWidth;

            if (!hasHorizontalScroll) {
                setCanScrollLeft(false);
                setCanScrollRight(false);
                return;
            }

            const atStart = Math.abs(el.scrollLeft) <= tolerance;
            const atEnd = Math.abs(el.scrollLeft) >= el.scrollWidth - el.clientWidth - tolerance;

            setCanScrollLeft(!atStart);
            setCanScrollRight(!atEnd);
        }
    }, []);

    useEffect(() => {
        const el = scrollerRef.current;
        if (!loading && el && listings.length > 0) {
            checkScrollability();
            const resizeObserver = new ResizeObserver(checkScrollability);
            resizeObserver.observe(el);
            el.addEventListener('scroll', checkScrollability, { passive: true });

            return () => {
                resizeObserver.unobserve(el);
                el.removeEventListener('scroll', checkScrollability);
            };
        }
    }, [loading, listings, checkScrollability]);

    const handleNav = (scrollDirection: 'prev' | 'next') => {
        const el = scrollerRef.current;
        if (el) {
            const scrollAmount = el.clientWidth * 0.8;
            const finalAmount = scrollDirection === 'prev' ? -scrollAmount : scrollAmount;
            el.scrollBy({ left: finalAmount, behavior: 'smooth' });
        }
    };

    if (loading) {
        return (
            <section className="py-12">
                <div className="container mx-auto px-4">
                    <h2 className="text-3xl font-bold text-white mb-6">{title}</h2>
                    <CarouselSkeleton />
                </div>
            </section>
        );
    }
    
    if (listings.length === 0) {
        return null;
    }

    return (
        <section className="py-12">
            <div className="container mx-auto px-4">
                <div className="flex justify-between items-center mb-6">
                    <h2
                        className="text-3xl font-bold text-white cursor-pointer hover:text-orange-500 transition-colors"
                        onClick={onViewAllClick}
                    >
                        {title}
                    </h2>
                    <button 
                        onClick={onViewAllClick}
                        className="text-sm font-semibold text-blue-600 hover:underline"
                    >
                        {t('seeAllOffers')}
                    </button>
                </div>
                <div className="relative">
                    {/* Previous Button - hidden on mobile */}
                    <button
                        onClick={() => handleNav('prev')}
                        aria-label="Previous items"
                        className={`hidden md:block absolute top-28 -translate-y-1/2 z-20 p-2 bg-orange-600 rounded-full text-white shadow-md hover:bg-orange-700 transition-opacity duration-300 start-4 ${!canScrollLeft ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
                    >
                        <ChevronIcon className={`w-6 h-6 rotate-180`} />
                    </button>
                    {/* Next Button - hidden on mobile */}
                    <button
                        onClick={() => handleNav('next')}
                        aria-label="Next items"
                        className={`hidden md:block absolute top-28 -translate-y-1/2 z-20 p-2 bg-orange-600 rounded-full text-white shadow-md hover:bg-orange-700 transition-opacity duration-300 end-4 ${!canScrollRight ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
                    >
                        <ChevronIcon className={`w-6 h-6`} />
                    </button>
                    
                    <div
                        ref={scrollerRef}
                        className="flex items-start gap-6 overflow-x-auto snap-x snap-mandatory scroll-smooth hide-scrollbar -mx-4 px-4 isolate"
                    >
                        {listings.map((listing) => (
                            <div key={listing.id} className="w-[300px] sm:w-[320px] md:w-[350px] flex-shrink-0 snap-start">
                                {listing.category === 'Automobiles & Véhicules'
                                    ? <AutomobileListingCard listing={listing} />
                                    : <ListingCard listing={listing} />}
                            </div>
                        ))}
                    </div>
                </div>
                 {/* Fix: Replaced <style jsx> with <style> to fix TypeScript error regarding invalid 'jsx' prop. */}
                 <style>{`
                    .hide-scrollbar {
                        -ms-overflow-style: none; /* IE and Edge */
                        scrollbar-width: none; /* Firefox */
                    }
                    .hide-scrollbar::-webkit-scrollbar {
                        display: none; /* Chrome, Safari and Opera */
                    }
                 `}</style>
            </div>
        </section>
    );
};

export default memo(ListingCarousel);