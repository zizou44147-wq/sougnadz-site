import React, { useState } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import SaveSearchIcon from './icons/SaveSearchIcon';

interface ListingsPageLayoutProps {
    pageTitle: string;
    // FIX: Changed sidebar prop from React.ReactNode to React.ReactElement for better type safety with React.cloneElement.
    sidebar: React.ReactElement;
    children: React.ReactNode;
    activeSort: string;
    onSortChange: (value: string) => void;
    showSaveSearchButton?: boolean;
    onSaveSearchClick?: () => void;
}

const ListingsPageLayout: React.FC<ListingsPageLayoutProps> = ({ pageTitle, sidebar, children, activeSort, onSortChange, showSaveSearchButton, onSaveSearchClick }) => {
    const { t } = useLocalization();
    const [isFiltersOpen, setIsFiltersOpen] = useState(false);

    return (
        <div className="container mx-auto px-4 py-8">
            <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 text-center sm:text-start flex-grow">
                    {pageTitle}
                </h1>
                <div className="flex items-center gap-4 self-center sm:self-auto flex-shrink-0">
                    {showSaveSearchButton && (
                         <button
                            onClick={onSaveSearchClick}
                            className="hidden sm:flex items-center gap-2 bg-gray-100 border border-gray-300 text-gray-900 rounded-md py-2 px-4 text-sm font-semibold hover:bg-gray-200 transition-colors"
                            title={t('saveSearch')}
                         >
                            <SaveSearchIcon className="w-5 h-5" />
                            <span className="hidden md:inline">{t('saveSearch')}</span>
                        </button>
                    )}
                    <button
                        onClick={() => setIsFiltersOpen(true)}
                        className="lg:hidden flex items-center gap-2 bg-gray-100 border border-gray-300 text-gray-900 rounded-md py-2 px-4 text-sm font-semibold"
                    >
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 4h18M7 12h10M10 20h4" /></svg>
                        {t('filterResults')}
                    </button>

                    <div className="flex items-center gap-2">
                        <label htmlFor="sort-by" className="text-gray-600 text-sm whitespace-nowrap">{t('sortBy')}:</label>
                        <div className="relative">
                            <select 
                                id="sort-by"
                                value={activeSort}
                                onChange={(e) => onSortChange(e.target.value)}
                                className="appearance-none bg-gray-100 border border-gray-300 text-gray-900 rounded-md py-2 pl-3 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                                <option value="relevance">{t('sortRelevance')}</option>
                                <option value="date">{t('sortDate')}</option>
                                <option value="price_asc">{t('sortPriceAsc')}</option>
                                <option value="price_desc">{t('sortPriceDesc')}</option>
                            </select>
                            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                               <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="lg:grid lg:grid-cols-4 lg:gap-8">
                <aside className="hidden lg:block lg:col-span-1">
                    {/* FIX: Added a type assertion to inform TypeScript of the props being injected into the cloned element. This resolves the overload error caused by excess property checking on a generically typed React.ReactElement. */}
                    {React.cloneElement(sidebar as React.ReactElement<{ isOpen?: boolean; onClose?: () => void; }>, { isOpen: true, onClose: () => {} })}
                </aside>

                <main className="lg:col-span-3">
                    {children}
                </main>
            </div>

            {/* Mobile Filter Modal */}
            <div className={`fixed inset-0 z-[100] transition-transform duration-300 ease-in-out ${isFiltersOpen ? 'translate-x-0' : 'translate-x-full'}`}>
                 {/* FIX: Added a type assertion to inform TypeScript of the props being injected into the cloned element. This resolves the overload error caused by excess property checking on a generically typed React.ReactElement. */}
                 {React.cloneElement(sidebar as React.ReactElement<{ isOpen?: boolean; onClose?: () => void; isMobile?: boolean; }>, { isOpen: isFiltersOpen, onClose: () => setIsFiltersOpen(false), isMobile: true })}
            </div>

        </div>
    );
};

export default ListingsPageLayout;