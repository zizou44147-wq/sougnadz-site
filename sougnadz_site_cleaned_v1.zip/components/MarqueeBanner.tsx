import React, { useState, useEffect, useRef } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { useLocation } from 'react-router-dom';
import NavbarLogo from './NavbarLogo';

const MarqueeBanner: React.FC = () => {
  const { t } = useLocalization();
  const [isVisible, setIsVisible] = useState(true);
  const lastScrollY = useRef(0);
  const location = useLocation();
  const isHomePage = location.pathname === '/';
  
  const [animationPhase, setAnimationPhase] = useState<'ar' | 'en-fr'>('ar');

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimationPhase(prev => (prev === 'ar' ? 'en-fr' : 'ar'));
    }, 30000); // Switch every 30 seconds

    return () => clearTimeout(timer);
  }, [animationPhase]);

  const handleScroll = () => {
    const currentScrollY = window.scrollY;
    if (currentScrollY > lastScrollY.current && currentScrollY > 100) {
      setIsVisible(false);
    } else if (currentScrollY < lastScrollY.current) {
      setIsVisible(true);
    }
    lastScrollY.current = currentScrollY <= 0 ? 0 : currentScrollY;
  };

  useEffect(() => {
    if (isHomePage) {
      setIsVisible(true);
      return; // Do not attach scroll listener on homepage
    }

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isHomePage]);
  
  const marqueeTextAr = t('marqueeMessageAr');
  const marqueeTextEn = t('marqueeMessageEn');
  const marqueeTextFr = t('marqueeMessageFr');

  const contentAr = (
    <div 
        className="flex" 
        style={{ animation: 'marquee-rtl 30s linear infinite' }}
    >
        <span className="mx-8 font-cairo" dir="rtl">{marqueeTextAr}</span>
        <span className="mx-8 font-cairo" dir="rtl">{marqueeTextAr}</span>
    </div>
  );

  const contentEnFr = (
     <div 
        className="flex items-center" 
        style={{ animation: 'marquee-ltr 30s linear infinite' }}
     >
        <span className="mx-8 font-nunito flex items-center gap-4">{marqueeTextEn} <NavbarLogo className="text-2xl" /> {marqueeTextFr}</span>
        <span className="mx-8 font-nunito flex items-center gap-4">{marqueeTextEn} <NavbarLogo className="text-2xl" /> {marqueeTextFr}</span>
    </div>
  );
  
  return (
    <div 
        className={`fixed top-16 left-0 right-0 z-30 transition-transform duration-700`}
        style={{ 
            transform: isVisible ? 'translateY(0)' : 'translateY(-100%)',
            transitionTimingFunction: 'cubic-bezier(0.68, -0.55, 0.27, 1.55)'
        }}
    >
      <div className="bg-gradient-to-r from-orange-500 via-red-500 to-yellow-500 text-white text-sm font-bold p-2.5 overflow-hidden whitespace-nowrap shadow-lg">
        {animationPhase === 'ar' ? contentAr : contentEnFr}
      </div>
    </div>
  );
};

export default MarqueeBanner;