/*
  This file appears to be part of an unintegrated AI chat feature.
  The content has been commented out as it's not currently used in the application.
*/

/*
import React from 'react';
import { Message, Sender } from '../types';

interface MessageBubbleProps {
    message: Message;
}

const BotIcon: React.FC = () => (
    <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center mr-3 flex-shrink-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-blue-400">
          <path fillRule="evenodd" d="M4.5 3.75a3 3 0 0 0-3 3v10.5a3 3 0 0 0 3 3h15a3 3 0 0 0 3-3V6.75a3 3 0 0 0-3-3h-15Zm4.125 3a.75.75 0 0 0 0 1.5h6.75a.75.75 0 0 0 0-1.5h-6.75Zm-.75 3.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Zm-2.25 3.375a.75.75 0 0 0 0 1.5h.75a.75.75 0 0 0 0-1.5h-.75Z" clipRule="evenodd" />
          <path d="M11.25 3.75a.75.75 0 0 0-1.5 0v.75h1.5v-.75Z" />
          <path d="M12.75 3.75a.75.75 0 0 1 1.5 0v.75h-1.5v-.75Z" />
        </svg>
    </div>
);

const UserIcon: React.FC = () => (
     <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center ml-3 flex-shrink-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-white">
          <path fillRule="evenodd" d="M7.5 6a4.5 4.5 0 1 1 9 0 4.5 4.5 0 0 1-9 0ZM3.751 20.105a8.25 8.25 0 0 1 16.498 0 .75.75 0 0 1-.437.695A18.683 18.683 0 0 1 12 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 0 1-.437-.695Z" clipRule="evenodd" />
        </svg>
    </div>
);

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
    const isUser = message.sender === Sender.USER;

    if (isUser) {
        return (
            <div className="flex items-start justify-end">
                <div className="max-w-md lg:max-w-lg xl:max-w-2xl px-4 py-3 bg-blue-600 rounded-2xl rounded-br-sm">
                    <p className="text-white whitespace-pre-wrap break-words">{message.text}</p>
                </div>
                <UserIcon />
            </div>
        );
    }

    return (
        <div className="flex items-start justify-start">
            <BotIcon />
            <div className="max-w-md lg:max-w-lg xl:max-w-2xl px-4 py-3 bg-slate-700 rounded-2xl rounded-bl-sm">
                <p className="text-slate-200 whitespace-pre-wrap break-words">{message.text}</p>
            </div>
        </div>
    );
};

export default MessageBubble;
*/
