import React, { FC, memo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocalization } from '../hooks/useLocalization';

interface NavbarLogoProps {
  className?: string;
}

const NavbarLogo: FC<NavbarLogoProps> = ({ className }) => {
  const navigate = useNavigate();
  const { language } = useLocalization();

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    navigate('/');
  };

  const finalClassName = className || 'text-3xl';

  const textShadow3d = (color: string, highlight: string, depth = 4) => {
    let shadow = [];
    for (let i = 1; i <= depth; i++) {
      shadow.push(`${i * 0.02}em ${i * 0.03}em 0 ${color}`);
    }
     shadow.push(`0.01em -0.01em 0 ${highlight}`); // Top highlight
     shadow.push(`0.12em 0.15em 0.1em rgba(0,0,0,0.3)`); // Drop shadow
    return shadow.join(', ');
  };

  // Define outline values
  const orangeOutlineValue = '0.025em';
  const blackOutlineValue = '0.028em'; // Kept original size for contrast
  const whiteOutlineValue = '0.028em';

  const thinOrangeOutline = `
    -${orangeOutlineValue} -${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8),  
     ${orangeOutlineValue} -${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8),
    -${orangeOutlineValue}  ${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8),
     ${orangeOutlineValue}  ${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8)
  `;
  
  const thinBlackOutline = `
    -${blackOutlineValue} -${blackOutlineValue} 0 rgba(0,0,0,0.7),  
     ${blackOutlineValue} -${blackOutlineValue} 0 rgba(0,0,0,0.7),
    -${blackOutlineValue}  ${blackOutlineValue} 0 rgba(0,0,0,0.7),
     ${blackOutlineValue}  ${blackOutlineValue} 0 rgba(0,0,0,0.7)
  `;

  const thinWhiteOutline = `
    -${whiteOutlineValue} -${whiteOutlineValue} 0 rgba(255,255,255,0.8),  
     ${whiteOutlineValue} -${whiteOutlineValue} 0 rgba(255,255,255,0.8),
    -${whiteOutlineValue}  ${whiteOutlineValue} 0 rgba(255,255,255,0.8),
     ${whiteOutlineValue}  ${whiteOutlineValue} 0 rgba(255,255,255,0.8)
  `;

  if (language === 'ar') {
    const arabicStyles = {
      sougna: {
        color: '#0d244f',
        textShadow: `${thinOrangeOutline}, ${textShadow3d('#081630', '#3b61aa', 5)}`,
      },
      dz: {
        color: '#f97316',
        textShadow: `${thinWhiteOutline}, ${textShadow3d('#c25a12', '#fdba74', 5)}`,
      },
    };

    return (
      <>
        <div
          onClick={handleClick}
          className={`inline-block cursor-pointer group ${finalClassName}`}
          aria-label="اذهب إلى الصفحة الرئيسية لموقع sougnadz.com"
          dir="rtl"
        >
          <div
            className="relative transition-transform duration-300 ease-in-out group-hover:scale-105"
            style={{ fontFamily: "'Cairo', sans-serif", fontWeight: 900, letterSpacing: 'normal' }}
          >
            <div 
                className="absolute -bottom-[0.2em] right-[-0.05em] w-[4em] h-[0.8em] z-0"
            >
                <svg viewBox="0 0 100 20" preserveAspectRatio="none" className="w-full h-full">
                    <defs>
                        <linearGradient id="swoosh3D" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stopColor="#fb923c" />
                            <stop offset="50%" stopColor="#f97316" />
                            <stop offset="100%" stopColor="#ea580c" />
                        </linearGradient>
                    </defs>
                    <path 
                        d="M 100,15 C 95,20 85,22 70,18 S 30,2 10,5 L 0,0 L 5,8 C 20,15 40,18 60,15 S 90,8 95,12 Z" 
                        fill="url(#swoosh3D)"
                    />
                </svg>
            </div>

            <div className="relative z-10 text-[1em]">
              <span style={{ ...arabicStyles.sougna, letterSpacing: '-0.05em' }}>ســوڤــنــا</span>
              <span style={{ ...arabicStyles.dz, marginRight: '0.15em' }}>ديزاد</span>
            </div>
          </div>
        </div>
      </>
    );
  }


  const styles = {
    sougna: {
      color: '#0d244f',
      textShadow: `${thinOrangeOutline}, ${textShadow3d('#081630', '#3b61aa', 5)}`,
    },
    dz: {
      color: '#f97316',
      textShadow: `${thinWhiteOutline}, ${textShadow3d('#c25a12', '#fdba74', 5)}`,
    },
    com: {
      color: '#e5e7eb',
      textShadow: `${thinBlackOutline}, ${textShadow3d('#9ca3af', '#ffffff', 4)}`,
    },
  };

  return (
    <>
      <div
        onClick={handleClick}
        className={`inline-block cursor-pointer group ${finalClassName}`}
        aria-label="Go to sougnadz.com homepage"
      >
        <div
          className="relative transition-transform duration-300 ease-in-out group-hover:scale-105"
          style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 900, letterSpacing: '-0.02em' }}
        >
          <div 
              className="absolute -bottom-[0.1em] left-[-0.15em] w-[4.8em] h-[0.8em] z-0"
          >
              <svg viewBox="0 0 100 20" preserveAspectRatio="none" className="w-full h-full">
                  <defs>
                      <linearGradient id="swoosh3D" x1="0%" y1="0%" x2="0%" y2="100%">
                          <stop offset="0%" stopColor="#fb923c" />
                          <stop offset="50%" stopColor="#f97316" />
                          <stop offset="100%" stopColor="#ea580c" />
                      </linearGradient>
                  </defs>
                  <path 
                      d="M 0,15 C 5,20 15,22 30,18 S 70,2 90,5 L 100,0 L 95,8 C 80,15 60,18 40,15 S 10,8 5,12 Z" 
                      fill="url(#swoosh3D)"
                  />
              </svg>
          </div>

          <div className="relative z-10 text-[1em]">
            <span style={{...styles.sougna, fontSize: '1.3em', position: 'relative', top: '0.06em'}}>s</span>
            <span style={{...styles.sougna, marginLeft: '0.04em'}}>ou</span>
            <span style={{...styles.sougna, fontSize: '1.3em', position: 'relative', top: '0.06em', marginLeft: '0.02em'}}>g</span>
            <span style={{...styles.sougna, marginLeft: '0.04em'}}>na</span>
            <span style={styles.dz}>dz</span>
            <span className="relative" style={{ top: '0.05em' }}>
              <span style={{...styles.dz, fontSize: '1.2em'}}>.</span>
              <span style={styles.com}>com</span>
            </span>
          </div>
        </div>
      </div>
    </>
  );
};

export default memo(NavbarLogo);