import React, { useState } from 'react';
import { useLocalization } from '../hooks/useLocalization';

interface SaveSearchModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (name: string) => void;
}

const SaveSearchModal: React.FC<SaveSearchModalProps> = ({ isOpen, onClose, onSave }) => {
    const { t } = useLocalization();
    const [name, setName] = useState('');

    if (!isOpen) return null;

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        if (name.trim()) {
            onSave(name.trim());
            setName('');
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity duration-300" onClick={onClose}>
            <form
                onSubmit={handleSave}
                className="bg-[#0f1429] rounded-lg shadow-xl p-8 w-full max-w-md m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative"
                onClick={(e) => e.stopPropagation()}
            >
                <h2 className="text-xl font-bold text-white mb-4">{t('nameYourSearch')}</h2>
                <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={t('searchNamePlaceholder')}
                    className="w-full bg-slate-800 border-slate-700 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    required
                    autoFocus
                />
                <div className="mt-6 flex justify-end gap-3">
                    <button
                        type="button"
                        onClick={onClose}
                        className="px-4 py-2 bg-gray-700 text-gray-200 rounded-md hover:bg-gray-600 font-semibold"
                    >
                        {t('close')}
                    </button>
                    <button
                        type="submit"
                        className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-semibold"
                    >
                        {t('save')}
                    </button>
                </div>
                 <style>{`
                    @keyframes modal-pop {
                        from { transform: scale(0.9); opacity: 0; }
                        to { transform: scale(1); opacity: 1; }
                    }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </form>
        </div>
    );
};

export default SaveSearchModal;