import React, { useState, useEffect } from 'react';
import ArrowUpIcon from './icons/ArrowUpIcon';
import ArrowDownIcon from './icons/ArrowDownIcon';

const ScrollToTopButton: React.FC = () => {
    const [showButtons, setShowButtons] = useState(false);
    const [isAtBottom, setIsAtBottom] = useState(false);
    const [isAtTop, setIsAtTop] = useState(true);

    const handleScroll = () => {
        const scrollPosition = window.scrollY;
        const windowHeight = window.innerHeight;
        const bodyHeight = document.body.offsetHeight;

        // Show buttons after scrolling down a bit
        setShowButtons(scrollPosition > 400);

        // Check if user is at the very top (with a small tolerance)
        setIsAtTop(scrollPosition < 5);

        // Check if user is at the bottom of the page (with a 5px tolerance)
        setIsAtBottom(windowHeight + scrollPosition >= bodyHeight - 5);
    };

    const scrollUp = () => {
        window.scrollBy({
            top: -window.innerHeight * 0.85, // Scroll up by 85% of the viewport height for a comfortable overlap
            behavior: 'smooth'
        });
    };

    const scrollDown = () => {
        window.scrollBy({
            top: window.innerHeight * 0.85, // Scroll down by 85% of the viewport height
            behavior: 'smooth'
        });
    };

    useEffect(() => {
        window.addEventListener('scroll', handleScroll, { passive: true });
        // Initial check in case the page loads scrolled down
        handleScroll();
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    const baseButtonClasses = "p-3 bg-orange-600 text-white rounded-full shadow-lg hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 transition-all duration-300 transform hover:-translate-y-1 active:scale-95";

    return (
        <div className="fixed bottom-6 end-6 z-50 flex items-center gap-3">
            <button
                onClick={scrollDown}
                className={`${baseButtonClasses} ${
                    showButtons && !isAtBottom ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
                }`}
                aria-label="Scroll down"
            >
                <ArrowDownIcon className="w-6 h-6" />
            </button>

            <button
                onClick={scrollUp}
                className={`${baseButtonClasses} ${
                    showButtons && !isAtTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
                }`}
                aria-label="Scroll up"
            >
                <ArrowUpIcon className="w-6 h-6" />
            </button>
        </div>
    );
};

export default ScrollToTopButton;