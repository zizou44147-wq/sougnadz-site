import React, { useState, useEffect } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { GoogleGenAI, Type } from "@google/genai";
import { MOCK_LISTINGS } from '../constants/mockData';
import { Listing } from '../services/types';
import { useNavigate } from 'react-router-dom';

interface SmartSearchModalProps {
    isOpen: boolean;
    onClose: () => void;
    query: string;
}

interface AiRecommendation {
    listingId: number;
    reason: string;
}

interface AiResponse {
    analysis: string;
    recommendations: AiRecommendation[];
}

interface RecommendedListing extends Listing {
    reason: string;
}

const RecommendationCard: React.FC<{ listing: RecommendedListing, onSelect: () => void }> = ({ listing, onSelect }) => {
    return (
        <div onClick={onSelect} className="bg-white dark:bg-slate-800/50 rounded-lg shadow-md overflow-hidden cursor-pointer hover:shadow-lg hover:border-blue-500 border border-transparent transition-all duration-300 transform hover:-translate-y-1">
            <img src={listing.imageUrl} alt={listing.title} className="w-full h-40 object-cover" />
            <div className="p-4">
                <h4 className="font-bold text-lg text-gray-900 dark:text-white">{listing.title}</h4>
                <p className="text-orange-500 font-semibold mb-2">{listing.price}</p>
                <p className="text-sm text-gray-600 dark:text-gray-300 border-l-4 border-blue-500 pl-3 italic">
                    {listing.reason}
                </p>
            </div>
        </div>
    );
};

const LoadingSkeleton = () => (
    <div className="space-y-4 animate-pulse">
        <div className="h-8 bg-gray-200 dark:bg-slate-700 rounded w-3/4"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Array.from({length: 2}).map((_, i) => (
                 <div key={i} className="bg-gray-200 dark:bg-slate-700 rounded-lg h-64"></div>
            ))}
        </div>
    </div>
)


const SmartSearchModal: React.FC<SmartSearchModalProps> = ({ isOpen, onClose, query }) => {
    const { t, language } = useLocalization();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [analysis, setAnalysis] = useState('');
    const [recommendations, setRecommendations] = useState<RecommendedListing[]>([]);

    const handleSelectListing = (id: number) => {
        navigate(`/listing/${id}`);
        onClose();
    };

    useEffect(() => {
        if (!isOpen) return;

        const fetchRecommendations = async () => {
            setLoading(true);
            setError(null);
            
            try {
                const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

                const availableCars = MOCK_LISTINGS.filter(l => l.category === 'Automobiles & Véhicules').map(car => ({
                    id: car.id,
                    title: car.title,
                    price: car.price,
                    year: car.meta.year,
                    km: car.meta.km,
                    fuel: car.meta.fuel,
                    transmission: car.meta.transmission
                }));

                const responseSchema = {
                    type: Type.OBJECT,
                    properties: {
                        analysis: { type: Type.STRING, description: `A brief, friendly summary in ${language === 'ar' ? 'Arabic' : 'French'} of what the user is looking for.` },
                        recommendations: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    listingId: { type: Type.NUMBER, description: "The ID of the recommended car from the provided list." },
                                    reason: { type: Type.STRING, description: `A short, compelling reason in ${language === 'ar' ? 'Arabic' : 'French'} why this specific car is a great match for the user's query.` }
                                },
                                required: ['listingId', 'reason'],
                            }
                        }
                    },
                    required: ['analysis', 'recommendations'],
                };

                const systemInstruction = `You are an expert car sales assistant for sougnadz.com, an Algerian classifieds website. Your goal is to help users find the perfect car based on their natural language query (which can be in French, Arabic, or Algerian Darja). Analyze the user's request and the provided JSON list of available cars. Your response MUST be a JSON object matching the specified schema. Pick the top 2-4 best matches and provide a clear, concise reason for each recommendation based on the user's needs.`;

                const prompt = `User Query: "${query}"\n\nAvailable Cars (JSON):\n${JSON.stringify(availableCars)}`;

                const response = await ai.models.generateContent({
                    model: 'gemini-2.5-flash',
                    contents: prompt,
                    config: {
                        responseMimeType: "application/json",
                        responseSchema: responseSchema,
                        systemInstruction: systemInstruction,
                    },
                });

                const result: AiResponse = JSON.parse(response.text);
                setAnalysis(result.analysis);

                const recommendedListings = result.recommendations.map(rec => {
                    const listing = MOCK_LISTINGS.find(l => l.id === rec.listingId);
                    return { ...listing, reason: rec.reason } as RecommendedListing;
                }).filter(Boolean);

                setRecommendations(recommendedListings);
                
            } catch (err) {
                console.error("Smart Search AI call failed:", err);
                setError("Désolé, une erreur s'est produite lors de l'analyse de votre recherche. Veuillez réessayer avec des mots-clés plus simples.");
            } finally {
                setLoading(false);
            }
        };

        fetchRecommendations();

    }, [isOpen, query, language]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity duration-300" onClick={onClose}>
            <div
                className="bg-gray-100 dark:bg-[#0f1429] rounded-lg shadow-xl p-6 sm:p-8 w-full max-w-3xl m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative max-h-[90vh] flex flex-col"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex-shrink-0">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-500" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" /></svg>
                            Assistant de Recherche Intelligent
                        </h2>
                        <button onClick={onClose} className="text-gray-400 dark:text-gray-500 hover:text-gray-800 dark:hover:text-white">
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                        </button>
                    </div>
                     <p className="text-sm text-gray-600 dark:text-gray-400 mb-6 border-b border-gray-200 dark:border-gray-700 pb-4">
                        Vous avez recherché : <span className="font-semibold italic">"{query}"</span>
                     </p>
                </div>
                
                <div className="overflow-y-auto flex-grow pr-2">
                    {loading && <LoadingSkeleton />}
                    
                    {error && (
                        <div className="text-center text-red-500 bg-red-100 dark:bg-red-900/50 p-4 rounded-lg">
                            <h3 className="font-bold">Erreur</h3>
                            <p>{error}</p>
                        </div>
                    )}

                    {!loading && !error && (
                        <div>
                             <div className="bg-blue-50 dark:bg-blue-900/40 border-l-4 border-blue-500 p-4 rounded-r-lg mb-6">
                                <p className="text-blue-800 dark:text-blue-200">{analysis}</p>
                            </div>
                             <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-gray-200">Nos meilleures recommandations pour vous :</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {recommendations.map(rec => (
                                    <RecommendationCard key={rec.id} listing={rec} onSelect={() => handleSelectListing(rec.id)} />
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                <style>{`
                    @keyframes modal-pop {
                        from { transform: scale(0.9); opacity: 0; }
                        to { transform: scale(1); opacity: 1; }
                    }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </div>
        </div>
    );
};

export default SmartSearchModal;
