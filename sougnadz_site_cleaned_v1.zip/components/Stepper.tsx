/*
  This component is no longer used.
  The multi-step ad posting wizard has been replaced by a single-page, AI-driven experience.
*/
import React from 'react';

const Stepper: React.FC = () => {
  return null;
};

export default Stepper;
