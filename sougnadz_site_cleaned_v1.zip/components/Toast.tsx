
import React from 'react';

interface ToastProps {
    message: string;
    show: boolean;
    onClose: () => void;
    type?: 'success' | 'error';
}

const icons = {
    success: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-100" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
    ),
    error: (
         <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-100" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
    )
};

const bgColors = {
    success: 'bg-green-600',
    error: 'bg-red-600'
};


const Toast: React.FC<ToastProps> = ({ message, show, onClose, type = 'success' }) => {
    return (
        <div
            className={`fixed bottom-0 inset-x-0 sm:bottom-5 sm:right-5 sm:left-auto sm:inset-x-auto sm:max-w-sm z-50 transition-all duration-300 ease-in-out
                ${show ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5 pointer-events-none'}`}
        >
            <div className={`flex items-center justify-between gap-3 ${bgColors[type]} text-white font-semibold py-3 px-4 shadow-lg sm:rounded-lg`}>
                <div className="flex items-center gap-3">
                    {icons[type]}
                    <span>{message}</span>
                </div>
                <button onClick={onClose} className="p-1 rounded-full hover:bg-black/20 flex-shrink-0">
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    );
};

export default Toast;