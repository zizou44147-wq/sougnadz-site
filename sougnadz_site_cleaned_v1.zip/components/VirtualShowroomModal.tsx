
export async function startMicrophone() {
  if (typeof navigator !== 'undefined' && navigator.mediaDevices?.getUserMedia) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      return stream;
    } catch (err) {
      console.error("Microphone permission denied or error:", err);
      throw err;
    }
  } else {
    throw new Error("getUserMedia not supported in this environment.");
  }
}

import React, { useState, useRef, useCallback } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { GoogleGenAI } from "@google/genai";
import { imageUrlToBase64, fileToBase64 } from '../utils/imageUtils';
import SparklesIcon from './icons/SparklesIcon';
import CameraIcon from './icons/CameraIcon';
import UploadIcon from './icons/UploadIcon';

interface VirtualShowroomModalProps {
    isOpen: boolean;
    onClose: () => void;
    productImageUrl: string;
    productTitle: string;
}

const VirtualShowroomModal: React.FC<VirtualShowroomModalProps> = ({ isOpen, onClose, productImageUrl, productTitle }) => {
    const { t, language } = useLocalization();
    const [userRoomImage, setUserRoomImage] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [aiTip, setAiTip] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const resetState = () => {
        setUserRoomImage(null);
        setGeneratedImage(null);
        setAiTip(null);
        setIsLoading(false);
        setError(null);
    };

    const handleClose = () => {
        resetState();
        onClose();
    };

    const handleGenerate = async (roomFile: File) => {
        // 1. Rate limiting check (1 use per minute per user)
        const lastUsed = localStorage.getItem('vs_last_used');
        if (lastUsed && Date.now() - parseInt(lastUsed) < 60000) {
            setError(t('rateLimitError'));
            return;
        }

        setIsLoading(true);
        setError(null);
        setGeneratedImage(null);
        setAiTip(null);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

            // 2. Convert images to base64
            const [productImageParts, roomImageBase64] = await Promise.all([
                imageUrlToBase64(productImageUrl),
                fileToBase64(roomFile)
            ]);

            const productPart = {
                inlineData: {
                    mimeType: productImageParts.mimeType,
                    data: productImageParts.base64,
                },
            };

            const roomPart = {
                inlineData: {
                    mimeType: roomFile.type,
                    data: roomImageBase64,
                },
            };
            
            const langInstruction = language === 'ar' ? 'باللغة العربية' : 'en français';
            const prompt = `En tant qu'expert en design d'intérieur, placez le produit de la première image de manière réaliste dans la pièce de la deuxième image. Faites correspondre la perspective, l'éclairage et l'échelle. Supprimez l'arrière-plan original du produit. Fournissez également une courte astuce de design (une phrase, ${langInstruction}) sur la façon dont le produit s'intègre dans la pièce.`;
            
            // 3. Call Gemini
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: [
                    {
                        parts: [
                            { text: prompt },
                            productPart,
                            roomPart,
                            { text: `\nAstuce de design (${langInstruction}):` }
                        ]
                    }
                ]
            });

            // 4. Process response
            let foundImage = false;
            for (const part of response.candidates[0].content.parts) {
                if (part.inlineData) {
                    const base64Data = part.inlineData.data;
                    const mimeType = part.inlineData.mimeType;
                    setGeneratedImage(`data:${mimeType};base64,${base64Data}`);
                    foundImage = true;
                } else if (part.text) {
                    setAiTip(part.text.trim());
                }
            }

            if (!foundImage) {
                throw new Error("L'IA n'a pas retourné d'image.");
            }

            // 5. Set rate limit timestamp on success
            localStorage.setItem('vs_last_used', Date.now().toString());

        } catch (e: any) {
            console.error("Gemini Virtual Showroom failed:", e);
            if (e.message && e.message.includes('quota')) {
                setError(t('quotaError'));
            } else {
                setError(e.message || "Une erreur inattendue est survenue.");
            }
        } finally {
            setIsLoading(false);
        }
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setUserRoomImage(URL.createObjectURL(file));
            handleGenerate(file);
        }
    };
    
    const handleCameraClick = async () => {
        setError(null);
        try {
            // Request camera permission. The browser will show the prompt.
            const stream = await startMicrophone();
            // Stop the stream immediately as we don't need to display it yet.
            stream.getTracks().forEach(track => track.stop());
            // For now, let the user know it's a future feature. A full implementation would open a camera view.
            alert("L'accès à la caméra est accordé. La fonctionnalité de capture de photos sera bientôt disponible !");
        } catch (err) {
            console.error("Camera access denied:", err);
            setError(t('cameraAccessDeniedError'));
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity duration-300" onClick={handleClose}>
            <div
                className="bg-[#0f1429] rounded-lg shadow-xl p-6 sm:p-8 w-full max-w-2xl m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative max-h-[90vh] flex flex-col"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex-shrink-0">
                    <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-3">
                            <SparklesIcon className="w-8 h-8 text-cyan-400" />
                            <div>
                                <h2 className="text-xl font-bold text-white">{t('virtualShowroomTitle')}</h2>
                                <p className="text-sm text-gray-400">{productTitle}</p>
                            </div>
                        </div>
                        <button onClick={handleClose} className="text-gray-400 hover:text-white">&times;</button>
                    </div>
                </div>

                <div className="overflow-y-auto flex-grow pr-2 -mr-2">
                    {!userRoomImage && !isLoading && !error && (
                         <div className="text-center py-10 flex flex-col items-center justify-center h-full">
                            <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                             <button onClick={() => fileInputRef.current?.click()} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg text-lg transition-colors flex items-center justify-center gap-3 w-full max-w-xs">
                                <UploadIcon className="w-6 h-6" />
                                {t('uploadYourRoom')}
                            </button>
                            <div className="my-4 flex items-center w-full max-w-xs">
                                <div className="flex-grow border-t border-gray-600"></div>
                                <span className="flex-shrink mx-4 text-gray-400 text-sm uppercase">{t('or')}</span>
                                <div className="flex-grow border-t border-gray-600"></div>
                            </div>
                             <button onClick={handleCameraClick} className="bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-6 rounded-lg text-lg transition-colors flex items-center justify-center gap-3 w-full max-w-xs">
                                <CameraIcon className="w-6 h-6" />
                                {t('useCamera')}
                            </button>
                            <p className="mt-6 text-sm text-gray-400 max-w-sm mx-auto">{t('uploadInstruction')}</p>
                        </div>
                    )}

                    {isLoading && (
                        <div className="text-center py-10">
                            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500 mx-auto mb-4"></div>
                            <p className="text-lg text-gray-300">{t('generatingVisualization')}</p>
                        </div>
                    )}
                    
                     {error && (
                        <div className="text-center py-10 bg-red-900/50 p-4 rounded-lg">
                            <p className="text-red-300">{error}</p>
                             <button onClick={resetState} className="mt-4 text-sm text-blue-400 hover:underline">Réessayer</button>
                        </div>
                    )}

                    {generatedImage && (
                        <div>
                            <img src={generatedImage} alt="Visualization" className="w-full h-auto rounded-lg shadow-lg" />
                            {aiTip && (
                                <div className="mt-4 bg-slate-800 p-4 rounded-lg">
                                    <h4 className="font-semibold text-gray-200">{t('aiTip')}:</h4>
                                    <p className="italic text-gray-300">"{aiTip}"</p>
                                </div>
                            )}
                             <button onClick={resetState} className="mt-4 w-full text-center text-sm text-blue-400 hover:underline">
                                Essayer avec une autre image
                            </button>
                        </div>
                    )}
                </div>

                <style>{`
                    @keyframes modal-pop { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </div>
        </div>
    );
};

export default VirtualShowroomModal;