import React, { useState, useEffect } from 'react';
import { Listing } from '../services/types';
import { MOCK_LISTINGS } from '../constants/mockData';
import { useLocalization } from '../hooks/useLocalization';
import ListingGrid from './ListingGrid';
import CalendarHistoryIcon from './icons/CalendarHistoryIcon';
import CloseIcon from './icons/CloseIcon';

interface VisitedPreviouslyProps {
    market: 'dz' | 'europe';
}

const VisitedPreviously: React.FC<VisitedPreviouslyProps> = ({ market }) => {
    const { t } = useLocalization();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [listings, setListings] = useState<Listing[]>([]);
    const [loading, setLoading] = useState(true);

    // Load listings when modal opens for fresh data
    useEffect(() => {
        if (isModalOpen) {
            try {
                setLoading(true);
                const viewedIds: number[] = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
                const viewedListings = viewedIds
                    .map(id => MOCK_LISTINGS.find(listing => listing.id === id))
                    .filter((listing): listing is Listing => Boolean(listing))
                    .filter(listing => (listing.market || 'dz') === market); // Filter by market
                setListings(viewedListings);
            } catch (error) {
                console.error("Failed to parse recently viewed listings from localStorage", error);
                setListings([]);
            } finally {
                setLoading(false);
            }
        }
    }, [isModalOpen, market]);

    return (
        <>
            <div className="container mx-auto px-4 my-8">
                <div
                    onClick={() => setIsModalOpen(true)}
                    className="group relative overflow-hidden rounded-2xl bg-gradient-to-tr from-blue-900/40 to-orange-900/20 p-6 text-center shadow-sm transition-all duration-300 flex items-center justify-center gap-4 cursor-pointer hover:shadow-lg hover:shadow-blue-500/30"
                    title={t('visitedPreviously')}
                >
                    <CalendarHistoryIcon className="w-10 h-10 text-orange-400 transition-transform duration-300 group-hover:scale-110" />
                    <h2 className="text-2xl font-extrabold text-white transition-transform duration-300 group-hover:scale-105">
                        {t('visitedPreviously')}
                    </h2>
                </div>
            </div>

            {isModalOpen && (
                <div 
                    className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center animate-fade-in"
                    onClick={() => setIsModalOpen(false)}
                >
                    <div
                        className="bg-[#0f1429] rounded-lg shadow-xl w-full max-w-4xl m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative flex flex-col"
                        style={{ height: '80vh', maxHeight: '800px' }}
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex-shrink-0 p-4 border-b border-gray-700 flex items-center justify-between">
                            <h2 className="text-xl font-bold text-white">{t('salesYouVisitedPreviously')}</h2>
                            <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-white">
                                <CloseIcon className="w-6 h-6" />
                            </button>
                        </div>

                        <div className="flex-grow p-6 overflow-y-auto bg-gray-900/50">
                            <ListingGrid
                                listings={listings}
                                loading={loading}
                                noResults={!loading && listings.length === 0}
                                noResultsMessage={t('noRecentlyViewedEmpty')}
                            />
                        </div>
                    </div>
                     <style>{`
                        @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
                        .animate-fade-in { animation: fade-in 0.3s ease-out; }
                        @keyframes modal-pop { from { transform: scale(0.9); } to { transform: scale(1); } }
                        .animate-modal-pop { animation: modal-pop 0.3s ease-out; }
                    `}</style>
                </div>
            )}
        </>
    );
};

export default VisitedPreviously;
