
export async function startMicrophone() {
  if (typeof navigator !== 'undefined' && navigator.mediaDevices?.getUserMedia) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      return stream;
    } catch (err) {
      console.error("Microphone permission denied or error:", err);
      throw err;
    }
  } else {
    throw new Error("getUserMedia not supported in this environment.");
  }
}

import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocalization } from '../hooks/useLocalization';
import { findSimilarByImage } from '../services/api';
import { fileToBase64 } from '../utils/imageUtils';
import CameraIcon from './icons/CameraIcon';
import UploadIcon from './icons/UploadIcon';
import SparklesIcon from './icons/SparklesIcon';

interface VisualSearchModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const VisualSearchModal: React.FC<VisualSearchModalProps> = ({ isOpen, onClose }) => {
    const { t } = useLocalization();
    const navigate = useNavigate();

    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isCameraOpen, setIsCameraOpen] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const streamRef = useRef<MediaStream | null>(null);

    const resetState = useCallback(() => {
        setIsLoading(false);
        setError(null);
        setIsCameraOpen(false);
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
    }, []);

    const handleClose = useCallback(() => {
        resetState();
        onClose();
    }, [onClose, resetState]);
    
    useEffect(() => {
        if (!isOpen) {
            resetState();
        }
    }, [isOpen, resetState]);

    const performSearch = async (base64Image: string, mimeType: string) => {
        setIsLoading(true);
        setError(null);
        try {
            const ids = await findSimilarByImage(base64Image, mimeType);
            if (ids.length > 0) {
                navigate(`/category/all?ids=${ids.join(',')}`);
                handleClose();
            } else {
                setError(t('noResultsFound'));
            }
        } catch (err) {
            setError(t('errorAnalyzingImage'));
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const base64 = await fileToBase64(file);
            performSearch(base64, file.type);
        }
    };
    
    const startCamera = async () => {
        setError(null);
        try {
            const stream = await startMicrophone();
            streamRef.current = stream;
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
            }
            setIsCameraOpen(true);
        } catch (err) {
            console.error("Camera access denied:", err);
            setError(t('cameraAccessDeniedError'));
        }
    };
    
    const takePicture = () => {
        const video = videoRef.current;
        const canvas = canvasRef.current;
        if (video && canvas) {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const ctx = canvas.getContext('2d');
            ctx?.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
            const dataUrl = canvas.toDataURL('image/jpeg');
            const base64 = dataUrl.split(',')[1];
            performSearch(base64, 'image/jpeg');
            resetState(); // close camera view after taking picture
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 transition-opacity duration-300" onClick={handleClose}>
            <div
                className="bg-[#0f1429] rounded-lg shadow-xl p-6 sm:p-8 w-full max-w-lg m-4 transform transition-all duration-300 scale-95 animate-modal-pop relative flex flex-col"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                        <SparklesIcon className="w-8 h-8 text-cyan-400" />
                        <div>
                            <h2 className="text-xl font-bold text-white">{t('visualSearchTitle')}</h2>
                        </div>
                    </div>
                    <button onClick={handleClose} className="text-gray-400 hover:text-white text-3xl">&times;</button>
                </div>
                
                <div className="flex-grow flex flex-col items-center justify-center">
                    {isLoading ? (
                        <div className="text-center">
                            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto mb-4"></div>
                            <p className="text-lg text-gray-300">{t('analyzingImage')}</p>
                        </div>
                    ) : error ? (
                        <div className="text-center bg-red-900/50 p-4 rounded-lg">
                            <p className="text-red-300">{error}</p>
                            <button onClick={resetState} className="mt-4 text-sm text-blue-400 hover:underline">Réessayer</button>
                        </div>
                    ) : isCameraOpen ? (
                        <div className="w-full aspect-video relative">
                            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover rounded-md bg-black"></video>
                            <canvas ref={canvasRef} className="hidden"></canvas>
                            <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
                                <button onClick={takePicture} className="w-16 h-16 rounded-full bg-white/30 border-4 border-white flex items-center justify-center hover:bg-white/50 transition"></button>
                            </div>
                        </div>
                    ) : (
                        <div className="text-center w-full">
                            <p className="text-gray-400 mb-6">{t('uploadInstruction', { defaultValue: "Upload an image or use your camera to find similar items." })}</p>
                            <div className="space-y-4">
                                <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                                <button onClick={() => fileInputRef.current?.click()} className="w-full max-w-xs mx-auto bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg text-lg transition-colors flex items-center justify-center gap-3">
                                    <UploadIcon className="w-6 h-6" />
                                    {t('uploadAnImage')}
                                </button>
                                <div className="my-4 flex items-center w-full max-w-xs mx-auto">
                                    <div className="flex-grow border-t border-gray-600"></div>
                                    <span className="flex-shrink mx-4 text-gray-400 text-sm uppercase">{t('or')}</span>
                                    <div className="flex-grow border-t border-gray-600"></div>
                                </div>
                                <button onClick={startCamera} className="w-full max-w-xs mx-auto bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-6 rounded-lg text-lg transition-colors flex items-center justify-center gap-3">
                                    <CameraIcon className="w-6 h-6" />
                                    {t('useYourCamera')}
                                </button>
                            </div>
                        </div>
                    )}
                </div>

                <style>{`
                    @keyframes modal-pop { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
                    .animate-modal-pop { animation: modal-pop 0.3s ease-out forwards; }
                `}</style>
            </div>
        </div>
    );
};

export default VisualSearchModal;