import React from 'react';
import { WantedItem } from '../services/types';
import { useLocalization } from '../hooks/useLocalization';
import { formatTimeAgo } from '../utils/time';
import BudgetIcon from './icons/BudgetIcon';
import CategoryIcon from './icons/CategoryIcon';
import LocationIcon from './icons/LocationIcon';

interface WantedItemCardProps {
    item: WantedItem;
}

const WantedItemCard: React.FC<WantedItemCardProps> = ({ item }) => {
    const { t, language } = useLocalization();

    return (
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-5 flex flex-col h-full shadow-lg transition-transform hover:scale-105 hover:border-blue-500/50">
            <div className="flex-grow">
                <p className="text-xs text-gray-400 mb-1">{item.category}</p>
                <h3 className="text-lg font-bold text-white mb-3">{item.title}</h3>
                <p className="text-sm text-gray-300 line-clamp-3 mb-4">{item.description}</p>
            </div>

            <div className="space-y-3 mt-auto pt-4 border-t border-slate-700/60">
                {item.budget && (
                    <div className="flex items-center gap-2 text-sm">
                        <BudgetIcon className="w-5 h-5 text-green-400 flex-shrink-0" />
                        <div>
                            <p className="text-xs text-gray-400">{t('budget')}</p>
                            <p className="font-semibold text-green-300">{item.budget}</p>
                        </div>
                    </div>
                )}
                <div className="flex items-center gap-2 text-sm">
                    <LocationIcon className="w-5 h-5 text-orange-400 flex-shrink-0" />
                     <div>
                        <p className="text-xs text-gray-400">{t('deliveryLocation')}</p>
                        <p className="font-semibold text-orange-300">{item.deliveryWilaya}</p>
                    </div>
                </div>
            </div>
            
            <div className="mt-4 text-xs text-gray-500 flex justify-between items-center">
                <span>{item.userName}</span>
                <span>{formatTimeAgo(item.createdAt, t, language)}</span>
            </div>
        </div>
    );
};

export default WantedItemCard;
