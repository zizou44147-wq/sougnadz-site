import React from 'react';
import { useWantedItems } from '../hooks/useWantedItems';
import { useLocalization } from '../hooks/useLocalization';
import WantedItemCard from './WantedItemCard';

const WantedItemsList: React.FC = () => {
    const { wantedItems } = useWantedItems();
    const { t } = useLocalization();

    if (wantedItems.length === 0) {
        return (
            <div className="text-center py-16 bg-slate-800/50 rounded-lg">
                <h3 className="text-xl font-bold text-white">{t('noWantedItems')}</h3>
                <p className="mt-2 text-gray-400">{t('beTheFirstWanted')}</p>
            </div>
        );
    }

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {wantedItems.map(item => (
                <WantedItemCard key={item.id} item={item} />
            ))}
        </div>
    );
};

export default WantedItemsList;
