import React, { memo } from 'react';

const AlgeriaFlagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 600" {...props}>
        <path fill="#fff" d="M0 0h900v600H0z"/>
        <path fill="#006233" d="M0 0h450v600H0z"/>
        <circle cx="450" cy="300" r="150" fill="#d21034"/>
        <circle cx="487.5" cy="300" r="125" fill="#fff"/>
        <g fill="#d21034" transform="translate(-56.25,-37.5)">
            <path d="M506.25,225 l-43.3,137.5 h137.5 l-94.2,-81.25 l-0,-175 l50.9,118.75z" />
        </g>
    </svg>
);

export default memo(AlgeriaFlagIcon);
