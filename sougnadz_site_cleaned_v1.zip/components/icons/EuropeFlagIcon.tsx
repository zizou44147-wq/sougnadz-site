import React, { memo } from 'react';

const EuropeFlagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => {
    // 5-pointed star path, radius 30, point up
    const starPath = "M0,-30 L8.816,-9.27 L28.53,-9.27 L13.856,5.92 L17.632,24.27 L0,13.09 L-17.632,24.27 L-13.856,5.92 L-28.53,-9.27 L-8.816,-9.27 Z";
    const stars = [];
    const numStars = 12;
    const circleRadius = 200; // 1/3 of height 600
    const centerX = 450;
    const centerY = 300;

    for (let i = 0; i < numStars; i++) {
        // Angle in radians, starting from the top (12 o'clock)
        const angle = (i * 360 / numStars) * Math.PI / 180;
        const x = centerX + circleRadius * Math.sin(angle);
        // Subtract from center Y because SVG y-axis is inverted
        const y = centerY - circleRadius * Math.cos(angle);
        
        stars.push(
            <path key={i} d={starPath} transform={`translate(${x}, ${y})`} />
        );
    }
    
    return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 600" {...props}>
            <rect width="900" height="600" fill="#003399"/>
            <g fill="#ffcc00">
                {stars}
            </g>
        </svg>
    );
};

export default memo(EuropeFlagIcon);