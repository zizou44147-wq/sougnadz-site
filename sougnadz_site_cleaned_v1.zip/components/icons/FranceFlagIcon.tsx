

import React, { memo } from 'react';

const FranceFlagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 600" {...props}>
        <rect fill="#fff" width="900" height="600"/>
        <rect fill="#002654" width="300" height="600"/>
        <rect fill="#ce1126" x="600" width="300" height="600"/>
    </svg>
);

export default memo(FranceFlagIcon);