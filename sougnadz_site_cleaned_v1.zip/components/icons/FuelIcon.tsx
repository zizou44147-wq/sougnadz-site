import React, { memo } from 'react';

const FuelIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 7.5l.415-.207a.75.75 0 011.085.67V10.5m0 0h6m-6 0a.75.75 0 00.75.75h4.5a.75.75 0 00.75-.75V7.5a.75.75 0 00-.75-.75h-4.5A.75.75 0 0010.5 7.5v3z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 18.75v-13.5a1.5 1.5 0 011.5-1.5h13.5a1.5 1.5 0 011.5 1.5v13.5m-16.5 0h16.5" />
    </svg>
);

export default memo(FuelIcon);
