import React, { memo } from 'react';

const PinIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5.068l4.243 4.243a1 1 0 01-1.414 1.414L10 11.414l-3.828 3.828a1 1 0 01-1.414-1.414L8.932 10.07 8.932 4a1 1 0 011-1H10zm-2 8a2 2 0 104 0 2 2 0 00-4 0z" clipRule="evenodd" />
        <path d="M2.5 5.5a1 1 0 00-1 1v2a1 1 0 001 1h15a1 1 0 001-1v-2a1 1 0 00-1-1h-15z" />
    </svg>
);

export default memo(PinIcon);