import React, { memo } from 'react';

const StarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M10.868 2.884c.321-.662 1.215-.662 1.536 0l1.68 3.452a1 1 0 00.95.69h3.623c.698 0 1.002.89.472 1.36l-2.928 2.128a1 1 0 00-.364 1.118l1.68 3.452c.321.662-.534 1.296-1.148.885l-2.928-2.128a1 1 0 00-1.175 0l-2.928 2.128c-.614.41-1.47-.223-1.148-.885l1.68-3.452a1 1 0 00-.364-1.118L2.24 8.386c-.53-.47-.226-1.36.472-1.36h3.623a1 1 0 00.95-.69l1.68-3.452z" clipRule="evenodd" />
    </svg>
);

export default memo(StarIcon);