import React, { memo } from 'react';

const UKFlagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 600" {...props}>
        <rect fill="#00247d" width="1200" height="600"/>
        <path d="m0 0 600 300M600 0l-600 300" stroke="#fff" strokeWidth="60"/>
        <path d="m0 0 600 300M600 0l-600 300" transform="translate(600)" stroke="#fff" strokeWidth="60"/>
        <path d="m0 0 600 300M600 0l-600 300" stroke="#cf142b" strokeWidth="40"/>
        <path d="m0 0 600 300M600 0l-600 300" transform="translate(600)" stroke="#cf142b" strokeWidth="40"/>
        <path d="M0 300h1200M600 0v600" stroke="#fff" strokeWidth="200"/>
        <path d="M0 300h1200M600 0v600" stroke="#cf142b" strokeWidth="120"/>
    </svg>
);

export default memo(UKFlagIcon);
