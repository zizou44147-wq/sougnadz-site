import React, { memo } from 'react';

const UsersIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.964A3 3 0 0012 12v-1.5a3 3 0 00-3-3H6a3 3 0 00-3 3v1.5a3 3 0 003 3m-3.75-2.964A9.094 9.094 0 0112 18.72m-12 0a9.094 9.094 0 003.741 .479 3 3 0 004.682-2.72m-8.423-2.964a3 3 0 013-3v1.5a3 3 0 01-3 3H6a3 3 0 01-3-3v-1.5a3 3 0 013-3m12 0a3 3 0 00-3-3H9a3 3 0 00-3 3v1.5a3 3 0 003 3m7.5-2.964a3 3 0 013 3H12v-1.5a3 3 0 013-3h1.5a3 3 0 013 3v1.5a3 3 0 01-3 3" />
    </svg>
);

export default memo(UsersIcon);