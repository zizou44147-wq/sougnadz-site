// src/constants/categories.ts
import { TranslationKey } from '../hooks/useLocalization';

// FIX: Added SubCategory interface to be used in Category
export interface SubCategory {
  slug: string;
  labelKey: TranslationKey;
  imageUrl: string;
}

export interface Category {
  slug: string;
  labelKey: TranslationKey;
  apiName: string;
  color: string;
  // FIX: Added optional subCategories property to fix type error
  subCategories?: SubCategory[];
}

export const CATEGORIES: Category[] = [
  { 
    slug: 'marche-immobilier-locations', 
    labelKey: 'categoryRealEstate', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Immobilier', 
    color: 'from-emerald-500 to-teal-600',
    // FIX: Added subcategory data
    subCategories: [
      { slug: 'vente', labelKey: 'transactionVente', imageUrl: 'https://picsum.photos/seed/immo-vente/200' },
      { slug: 'location', labelKey: 'transactionLocation', imageUrl: 'https://picsum.photos/seed/immo-location/200' },
      { slug: 'colocation', labelKey: 'transactionColocation', imageUrl: 'https://picsum.photos/seed/immo-colocation/200' },
      { slug: 'location_vacances', labelKey: 'transactionLocationVacances', imageUrl: 'https://picsum.photos/seed/immo-vacances/200' }
    ]
  },
  { 
    slug: 'marche-des-vehicules-et-autos', 
    labelKey: 'categoryVehicles', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Automobiles & Véhicules', 
    color: 'from-sky-500 to-blue-600',
    // FIX: Added subcategory data
    subCategories: [
      { slug: 'voitures', labelKey: 'subcat_voitures', imageUrl: 'https://picsum.photos/seed/sub-cars/200' },
      { slug: 'motos_scooters', labelKey: 'subcat_motos', imageUrl: 'https://picsum.photos/seed/sub-motos/200' },
      { slug: 'utilitaires', labelKey: 'subcat_utilitaires', imageUrl: 'https://picsum.photos/seed/sub-util/200' },
      { slug: 'camion', labelKey: 'subcat_camions', imageUrl: 'https://picsum.photos/seed/sub-trucks/200' },
      { slug: 'bateaux_barques', labelKey: 'subcat_bateaux', imageUrl: 'https://picsum.photos/seed/sub-boats/200' }
    ]
  },
  { 
    slug: 'magasin-de-pieces-detachees', 
    labelKey: 'categorySpareParts', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Pièces détachées', 
    color: 'from-gray-500 to-slate-600',
  },
  { 
    slug: 'smartphones-neufs-occasion', 
    labelKey: 'categorySmartphones', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Téléphones & Accessoires', 
    color: 'from-fuchsia-500 to-pink-600',
  },
  { 
    slug: 'ordinateurs-accessoires', 
    labelKey: 'categoryComputers', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Informatique', 
    color: 'from-cyan-500 to-indigo-600',
  },
  { 
    slug: 'appareils-menagers-neufs-occasions', 
    labelKey: 'categoryAppliances', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Électroménager & Électronique', 
    color: 'from-blue-400 to-purple-500',
  },
  { 
    slug: 'vetements-mode', 
    labelKey: 'categoryClothing', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Vêtements & Mode', 
    color: 'from-rose-400 to-fuchsia-500',
  },
  { 
    slug: 'soins-beaute', 
    labelKey: 'categoryBeauty', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Santé & Beauté', 
    color: 'from-green-400 to-lime-500',
  },
  { 
    slug: 'decoration-meubles', 
    labelKey: 'categoryFurniture', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Meubles & Maison', 
    color: 'from-amber-600 to-yellow-700',
  },
  { 
    slug: 'divertissement-loisirs', 
    labelKey: 'categoryEntertainment', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Loisirs & Divertissements', 
    color: 'from-red-500 to-orange-600',
  },
  { 
    slug: 'emplois-opportunites', 
    labelKey: 'categoryJobs', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Emploi', 
    color: 'from-lime-500 to-emerald-600',
  },
  { 
    slug: 'equipements-articles-divers', 
    labelKey: 'categoryMiscGoods', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Matériaux & Équipement', 
    color: 'from-yellow-700 to-amber-800',
  },
  { 
    slug: 'produits-alimentaires-boissons', 
    labelKey: 'categoryFood', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Alimentaires', 
    color: 'from-orange-500 to-red-600',
  },
  { 
    slug: 'voyages-offres-touristiques', 
    labelKey: 'categoryTravel', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Voyages', 
    color: 'from-teal-400 to-cyan-500',
  },
  { 
    slug: 'chercheurs-d-emploi', 
    labelKey: 'categoryJobSeekers', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Emploi', 
    color: 'from-indigo-400 to-blue-500',
  },
  { 
    slug: 'projets-caritatifs-benevoles', 
    labelKey: 'categoryCharity', 
    // FIX: Corrected apiName to match mock data
    apiName: 'Services', 
    color: 'from-amber-500 to-orange-600',
  },
  { 
    slug: 'vente-d-outils-agricoles', 
    labelKey: 'categoryAgriTools', 
    apiName: 'Agricultural Tool Sales', 
    color: 'from-green-600 to-lime-700',
  },
];
