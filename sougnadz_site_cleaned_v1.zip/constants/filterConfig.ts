import { CategoryFilterConfig, FilterDefinition } from '../services/types';

const LOCATION_FILTER: FilterDefinition = {
    key: 'location',
    labelKey: 'adLocation',
    type: 'accordion-group',
    subFilters: [
        {
            key: 'wilaya',
            labelKey: 'filterWilaya',
            type: 'select',
            options: [] // Populated dynamically
        },
        {
            key: 'commune',
            labelKey: 'filterCommune',
            type: 'select',
            options: [] // Populated dynamically
        }
    ]
};

const DATE_FILTER: FilterDefinition = {
    key: 'datePosted',
    labelKey: 'filterDatePosted',
    type: 'accordion-group',
    subFilters: [
        {
            key: 'dateRange',
            labelKey: 'filterDateRange',
            type: 'radio-group',
            options: [
                { labelKey: 'dateAllTime', value: 'all-time' },
                { labelKey: 'dateLast24h', value: '24h' },
                { labelKey: 'dateLast7d', value: '7d' },
                { labelKey: 'dateLast30d', value: '30d' },
                { labelKey: 'dateCustom', value: 'custom' },
            ]
        },
        {
            key: 'customDateRange',
            labelKey: 'filterCustomDateRange',
            type: 'date-range',
            minKey: 'dateFrom',
            maxKey: 'dateTo'
        }
    ]
};

const GENERIC_FILTERS_BASE: FilterDefinition[] = [
    {
        key: 'state',
        labelKey: 'filterState',
        type: 'accordion-group',
        subFilters: [{
            key: 'etat',
            labelKey: 'filterState',
            type: 'radio-group',
            options: [
                { labelKey: 'sellerAll', value: '' },
                { labelKey: 'stateNew', value: 'neuf' },
                { labelKey: 'stateUsed', value: 'occasion' },
                { labelKey: 'stateLikeNew', value: 'comme_neuf' },
            ]
        }]
    },
    {
        key: 'seller',
        labelKey: 'filterSellerType',
        type: 'accordion-group',
        subFilters: [{
            key: 'sellerType',
            labelKey: 'filterSellerType',
            type: 'radio-group',
            options: [
                { labelKey: 'sellerAll', value: '' },
                { labelKey: 'sellerParticulier', value: 'particulier' },
                { labelKey: 'sellerStore', value: 'store' },
            ]
        }]
    },
];


const PRICE_FILTER: FilterDefinition = {
    key: 'price',
    labelKey: 'filterPrice',
    type: 'accordion-group',
    subFilters: [{
        key: 'price',
        labelKey: 'filterPrice',
        type: 'range-number',
        minKey: 'priceMin',
        maxKey: 'priceMax'
    }]
};

const GENERIC_FILTERS: FilterDefinition[] = [LOCATION_FILTER, ...GENERIC_FILTERS_BASE, DATE_FILTER];
const GENERIC_FILTERS_WITH_PRICE: FilterDefinition[] = [PRICE_FILTER, LOCATION_FILTER, ...GENERIC_FILTERS_BASE, DATE_FILTER];

export const CATEGORY_FILTERS: CategoryFilterConfig = {
    'marche-des-vehicules-et-autos': [
        {
            key: 'brandModel',
            labelKey: 'filterBrand', // Main accordion title
            type: 'accordion-group',
            subFilters: [
                { key: 'marque', labelKey: 'filterBrand', type: 'select' },
                { key: 'modele', labelKey: 'filterModel', type: 'select' }
            ]
        },
        {
            key: 'year',
            labelKey: 'filterYear',
            type: 'accordion-group',
            subFilters: [{
                key: 'year',
                labelKey: 'filterYear',
                type: 'range-number',
                minKey: 'yearMin',
                maxKey: 'yearMax'
            }]
        },
        {
            key: 'engine',
            labelKey: 'engine',
            type: 'accordion-group',
            subFilters: [
                { key: 'engine', labelKey: 'engine', type: 'select' },
            ]
        },
        {
            key: 'fuel',
            labelKey: 'filterFuel',
            type: 'accordion-group',
            subFilters: [{
                key: 'energie',
                labelKey: 'filterFuel',
                type: 'checkbox-group',
                options: [
                    { labelKey: 'fuelEssence', value: 'essence' },
                    { labelKey: 'fuelDiesel', value: 'diesel' },
                    { labelKey: 'fuelGpl', value: 'gpl' },
                    { labelKey: 'fuelHybrid', value: 'hybride' },
                    { labelKey: 'fuelElectric', value: 'electrique' },
                    { labelKey: 'fuelOther', value: 'autre' },
                ]
            }]
        },
        LOCATION_FILTER,
        {
            key: 'price',
            labelKey: 'filterPriceMillions',
            type: 'accordion-group',
            subFilters: [{
                key: 'price',
                labelKey: 'filterPriceMillions',
                type: 'range-number',
                minKey: 'priceMinMillions',
                maxKey: 'priceMaxMillions'
            }]
        },
        {
            key: 'km',
            labelKey: 'filterKm',
            type: 'accordion-group',
            subFilters: [{
                key: 'km',
                labelKey: 'filterKm',
                type: 'range-number',
                minKey: 'kmMin',
                maxKey: 'kmMax'
            }]
        },
        {
            key: 'gearbox',
            labelKey: 'filterTransmission',
            type: 'accordion-group',
            subFilters: [{
                key: 'boite',
                labelKey: 'filterTransmission',
                type: 'checkbox-group',
                options: [
                    { labelKey: 'gearboxManual', value: 'manuelle' },
                    { labelKey: 'gearboxAutomatic', value: 'automatique' },
                    { labelKey: 'gearboxSemiAutomatic', value: 'semi_automatique' },
                ]
            }]
        },
        {
            key: 'papers',
            labelKey: 'filterPapers',
            type: 'accordion-group',
            subFilters: [{
                key: 'papiers',
                labelKey: 'filterPapers',
                type: 'checkbox-group',
                options: [
                    { labelKey: 'papersCard', value: 'carte_grise_safia' },
                    { labelKey: 'papersLicense', value: 'licence_delai' },
                ]
            }]
        },
        {
            key: 'exchange',
            labelKey: 'filterExchange',
            type: 'accordion-group',
            subFilters: [{
                key: 'echange',
                labelKey: 'filterExchange',
                type: 'radio-group',
                options: [
                    { labelKey: 'exchangeAccepts', value: 'accepte' },
                    { labelKey: 'exchangeOnly', value: 'uniquement' },
                    { labelKey: 'exchangeNone', value: 'aucun' },
                ]
            }]
        },
        {
            key: 'seller',
            labelKey: 'filterSellerType',
            type: 'accordion-group',
            subFilters: [{
                key: 'sellerType',
                labelKey: 'filterSellerType',
                type: 'radio-group',
                options: [
                    { labelKey: 'sellerAll', value: '' },
                    { labelKey: 'sellerParticulier', value: 'particulier' },
                    { labelKey: 'sellerStore', value: 'store' },
                ]
            }]
        },
        DATE_FILTER,
    ],
    'marche-immobilier-locations': [
        {
            key: 'transaction',
            labelKey: 'filterTransactionType',
            type: 'accordion-group',
            subFilters: [{
                key: 'transactionType',
                labelKey: 'filterTransactionType',
                type: 'radio-group',
                options: [
                    { labelKey: 'categoryToutesLesCategories', value: '' },
                    { labelKey: 'transactionVente', value: 'vente' },
                    { labelKey: 'transactionLocation', value: 'location' },
                    { labelKey: 'transactionColocation', value: 'colocation' },
                    { labelKey: 'transactionLocationVacances', value: 'location_vacances' },
                ],
            }]
        },
        {
            key: 'property',
            labelKey: 'filterPropertyType',
            type: 'accordion-group',
            subFilters: [{
                key: 'propertyType',
                labelKey: 'filterPropertyType',
                type: 'radio-group',
                options: [
                    { labelKey: 'propertyAppartement', value: 'appartement' },
                    { labelKey: 'propertyMaison', value: 'maison' },
                    { labelKey: 'propertyVilla', value: 'villa' },
                    { labelKey: 'propertyTerrain', value: 'terrain' },
                    { labelKey: 'propertyBureau', value: 'bureau' },
                    { labelKey: 'propertyLocal', value: 'local' },
                ]
            }]
        },
        LOCATION_FILTER,
        PRICE_FILTER,
        {
            key: 'surface',
            labelKey: 'filterSurface',
            type: 'accordion-group',
            subFilters: [{
                key: 'surface',
                labelKey: 'filterSurface',
                type: 'range-number',
                minKey: 'surfaceMin',
                maxKey: 'surfaceMax'
            }]
        },
        {
            key: 'rooms',
            labelKey: 'filterRooms',
            type: 'accordion-group',
            subFilters: [{
                key: 'rooms',
                labelKey: 'filterRooms',
                type: 'range-number',
                minKey: 'roomsMin',
                maxKey: 'roomsMax'
            }]
        },
        {
            key: 'furnished',
            labelKey: 'filterFurnished',
            type: 'accordion-group',
            subFilters: [{
                key: 'furnished',
                labelKey: 'filterFurnished',
                type: 'radio-group',
                options: [
                    { labelKey: 'sellerAll', value: '' },
                    { labelKey: 'furnishedYes', value: 'oui' },
                    { labelKey: 'furnishedNo', value: 'non' },
                ]
            }]
        },
        DATE_FILTER,
    ],
    'magasin-de-pieces-detachees': GENERIC_FILTERS_WITH_PRICE,
    'smartphones-neufs-occasion': GENERIC_FILTERS_WITH_PRICE,
    'ordinateurs-accessoires': GENERIC_FILTERS_WITH_PRICE,
    'appareils-menagers-neufs-occasions': GENERIC_FILTERS_WITH_PRICE,
    'vetements-mode': GENERIC_FILTERS_WITH_PRICE,
    'soins-beaute': GENERIC_FILTERS_WITH_PRICE,
    'decoration-meubles': GENERIC_FILTERS_WITH_PRICE,
    'divertissement-loisirs': GENERIC_FILTERS_WITH_PRICE,
    'equipements-articles-divers': GENERIC_FILTERS_WITH_PRICE,
    'produits-alimentaires-boissons': GENERIC_FILTERS_WITH_PRICE,
    'voyages-offres-touristiques': GENERIC_FILTERS_WITH_PRICE,
    'vente-d-outils-agricoles': GENERIC_FILTERS_WITH_PRICE,
    'emplois-opportunites': GENERIC_FILTERS,
    'chercheurs-d-emploi': GENERIC_FILTERS,
    'projets-caritatifs-benevoles': GENERIC_FILTERS,
};