import React, { createContext, useState, useContext, ReactNode, useCallback } from 'react';

// Define a user object structure
interface User {
    id: string;
    name: string;
    avatar: string;
}

interface AuthContextType {
    isLoggedIn: boolean;
    currentUser: User | null;
    isAuthModalOpen: boolean;
    login: () => void;
    logout: () => void;
    openAuthModal: () => void;
    closeAuthModal: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// To simulate being the site owner, you can change this ID.
// Any other ID will be treated as a regular user.
const SITE_OWNER_ID = 'site-owner-admin-123';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

    const login = useCallback(() => {
        // By default, this logs in a regular user.
        // To test as the site owner with full permissions, change the id to SITE_OWNER_ID.
        setCurrentUser({ 
            id: 'karim-dz-123', // Unique ID for a regular user
            name: 'Karim DZ', 
            avatar: 'https://i.pravatar.cc/150?u=karimdz' 
        });
        /*
        // UNCOMMENT THIS TO LOGIN AS THE SITE OWNER
        setCurrentUser({ 
            id: SITE_OWNER_ID,
            name: 'Admin Sougnadz', 
            avatar: 'https://i.pravatar.cc/150?u=admin-sougnadz' 
        });
        */
    }, []);

    const logout = useCallback(() => setCurrentUser(null), []);
    const openAuthModal = useCallback(() => setIsAuthModalOpen(true), []);
    const closeAuthModal = useCallback(() => setIsAuthModalOpen(false), []);

    const value = { 
        isLoggedIn: !!currentUser, 
        currentUser,
        isAuthModalOpen, 
        login, 
        logout, 
        openAuthModal, 
        closeAuthModal 
    };

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = (): AuthContextType => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};