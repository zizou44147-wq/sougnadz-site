import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useMemo } from 'react';
import { useLocalization } from './useLocalization';

export interface GuestbookMessage {
  id: number;
  text: string;
  createdAt: string;
  isPinned?: boolean;
  author: {
    id: string;
    name: string;
    avatar: string;
  };
}

interface GuestbookContextType {
  messages: GuestbookMessage[];
  guestMessageIds: number[];
  addMessage: (text: string, author: GuestbookMessage['author']) => void;
  deleteMessage: (id: number) => void;
  editMessage: (id: number, newText: string) => void;
  togglePinMessage: (id: number) => void;
}

const GuestbookContext = createContext<GuestbookContextType | undefined>(undefined);

const GUESTBOOK_KEY = 'sougnadzGuestbook_v2';
const GUEST_MESSAGES_KEY = 'sougnadzGuestbook_guestSession';

const PROFANITY_LIST_FR = ['merde', 'con', 'putain', 'salope', 'enculé', 'fdp'];
const PROFANITY_LIST_AR = ['كلب', 'حقير', 'حيوان', 'زبي', 'سخيف', 'تبون', 'شنقريحة'];
const PROFANITY_LIST = [...PROFANITY_LIST_FR, ...PROFANITY_LIST_AR];


export const GuestbookProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<GuestbookMessage[]>([]);
  const [guestMessageIds, setGuestMessageIds] = useState<number[]>([]);
  const { t } = useLocalization();

  useEffect(() => {
    try {
      const storedMessages = localStorage.getItem(GUESTBOOK_KEY);
      if (storedMessages) {
        setMessages(JSON.parse(storedMessages));
      }
      const storedGuestIds = sessionStorage.getItem(GUEST_MESSAGES_KEY);
      if (storedGuestIds) {
        setGuestMessageIds(JSON.parse(storedGuestIds));
      }
    } catch (error) {
      console.error('Failed to load guestbook messages from storage', error);
    }
  }, []);

  const updateAndPersistMessages = (newMessages: GuestbookMessage[]) => {
    setMessages(newMessages);
    try {
      localStorage.setItem(GUESTBOOK_KEY, JSON.stringify(newMessages));
    } catch (error) {
      console.error('Failed to save guestbook messages to localStorage', error);
    }
  };

  const updateAndPersistGuestIds = (newIds: number[]) => {
    setGuestMessageIds(newIds);
    try {
      sessionStorage.setItem(GUEST_MESSAGES_KEY, JSON.stringify(newIds));
    } catch (error) {
      console.error('Failed to save guest message IDs to sessionStorage', error);
    }
  };


  const addMessage = useCallback((text: string, author: GuestbookMessage['author']) => {
    const trimmedText = text.trim();
    if (!trimmedText) return;

    // Profanity filter
    const hasProfanity = PROFANITY_LIST.some(word => 
        new RegExp(`\\b${word}\\b`, 'i').test(trimmedText)
    );

    if (hasProfanity) {
        alert("Votre message contient des mots inappropriés et a été bloqué. (Your message contains inappropriate words and has been blocked.)");
        return;
    }

    const newMessage: GuestbookMessage = {
      id: Date.now(),
      text: trimmedText,
      createdAt: new Date().toISOString(),
      isPinned: false,
      author,
    };

    setMessages(prevMessages => {
      const lastMessage = prevMessages[0];
      if (lastMessage && lastMessage.author.id === author.id && lastMessage.text === trimmedText) {
        console.warn("Duplicate message submission prevented.");
        return prevMessages;
      }
      
      const updatedMessages = [newMessage, ...prevMessages];
      updateAndPersistMessages(updatedMessages);

      if (author.id.startsWith('guest')) {
          setGuestMessageIds(prevIds => {
              const newIds = [...prevIds, newMessage.id];
              updateAndPersistGuestIds(newIds);
              return newIds;
          });
      }
      
      // Intelligent Auto-Reply
      setTimeout(() => {
          const replyText = `${t('guestbookAutoReply', { name: author.name })}\n\n${t('guestbookAutoReplyPS')}`;
          const botMessage: GuestbookMessage = {
              id: Date.now() + 1, // Ensure unique ID
              text: replyText,
              createdAt: new Date().toISOString(),
              isPinned: false,
              author: {
                  id: 'sougnadz-bot',
                  name: 'sougnadz.com',
                  avatar: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path fill='%230B5FA5' d='M0,50 A50,50 0 0,1 100,50 L50,50 Z' /><path fill='%23E87A16' d='M0,50 A50,50 0 0,0 100,50 L50,50 Z' /></svg>"
              }
          };
          
          setMessages(currentMessages => {
              const newBotMessages = [botMessage, ...currentMessages];
              updateAndPersistMessages(newBotMessages);
              return newBotMessages;
          });

      }, 1500);

      return updatedMessages;
    });
  }, [t]);

  const deleteMessage = useCallback((id: number) => {
    setMessages(prevMessages => {
        const updatedMessages = prevMessages.filter(msg => msg.id !== id);
        updateAndPersistMessages(updatedMessages);
        return updatedMessages;
    });
    setGuestMessageIds(prevIds => {
        const newIds = prevIds.filter(guestId => guestId !== id);
        if (newIds.length < prevIds.length) {
            updateAndPersistGuestIds(newIds);
        }
        return newIds;
    });
  }, []);

  const editMessage = useCallback((id: number, newText: string) => {
    setMessages(prevMessages => {
        const updatedMessages = prevMessages.map(msg => 
            msg.id === id ? { ...msg, text: newText.trim() } : msg
        );
        updateAndPersistMessages(updatedMessages);
        return updatedMessages;
    });
  }, []);

  const togglePinMessage = useCallback((id: number) => {
    setMessages(prevMessages => {
        const updatedMessages = prevMessages.map(msg => 
            msg.id === id ? { ...msg, isPinned: !msg.isPinned } : msg
        );
        updateAndPersistMessages(updatedMessages);
        return updatedMessages;
    });
  }, []);
  
  const sortedMessages = useMemo(() => {
    const pinned = messages.filter(m => m.isPinned).sort((a, b) => b.id - a.id);
    const unpinned = messages.filter(m => !m.isPinned).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return [...pinned, ...unpinned];
  }, [messages]);


  return (
    <GuestbookContext.Provider value={{ messages: sortedMessages, guestMessageIds, addMessage, deleteMessage, editMessage, togglePinMessage }}>
      {children}
    </GuestbookContext.Provider>
  );
};

export const useGuestbook = (): GuestbookContextType => {
  const context = useContext(GuestbookContext);
  if (!context) {
    throw new Error('useGuestbook must be used within a GuestbookProvider');
  }
  return context;
};