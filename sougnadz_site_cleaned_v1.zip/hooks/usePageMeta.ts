import { useEffect } from 'react';

interface PageMeta {
    title: string;
    description: string;
    keywords?: string;
    imageUrl?: string;
}

const setMetaTag = (attr: 'name' | 'property', value: string, content: string) => {
    let element = document.querySelector(`meta[${attr}='${value}']`) as HTMLMetaElement;
    if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, value);
        document.head.appendChild(element);
    }
    element.setAttribute('content', content);
};

export const usePageMeta = ({ title, description, keywords, imageUrl }: PageMeta) => {
    useEffect(() => {
        // Set basic meta tags
        document.title = title;
        setMetaTag('name', 'description', description);
        if (keywords) {
            setMetaTag('name', 'keywords', keywords);
        }

        // Set Open Graph (for social sharing) tags
        setMetaTag('property', 'og:title', title);
        setMetaTag('property', 'og:description', description);
        setMetaTag('property', 'og:type', 'website');
        if (imageUrl) {
            setMetaTag('property', 'og:image', imageUrl);
        }

        // Set Twitter Card tags
        setMetaTag('name', 'twitter:card', 'summary_large_image');
        setMetaTag('name', 'twitter:title', title);
        setMetaTag('name', 'twitter:description', description);
        if (imageUrl) {
            setMetaTag('name', 'twitter:image', imageUrl);
        }

    }, [title, description, keywords, imageUrl]);
};