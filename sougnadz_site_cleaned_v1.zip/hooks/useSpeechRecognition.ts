import { useState, useEffect, useRef, useCallback } from 'react';
import { useLocalization } from './useLocalization';

// FIX: Added type definitions for the Web Speech API to resolve TypeScript errors.
// These types are not always included in default TS DOM libs.
interface SpeechRecognitionEvent extends Event {
    readonly resultIndex: number;
    readonly results: SpeechRecognitionResultList;
}

interface SpeechRecognitionResultList {
    readonly length: number;
    item(index: number): SpeechRecognitionResult;
    [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
    readonly isFinal: boolean;
    readonly length: number;
    item(index: number): SpeechRecognitionAlternative;
    [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionAlternative {
    readonly transcript: string;
    readonly confidence: number;
}

type SpeechRecognitionErrorCode =
  | 'no-speech'
  | 'aborted'
  | 'audio-capture'
  | 'network'
  | 'not-allowed'
  | 'service-not-allowed'
  | 'bad-grammar'
  | 'language-not-supported';

interface SpeechRecognitionErrorEvent extends Event {
    readonly error: SpeechRecognitionErrorCode;
    readonly message: string;
}

interface SpeechRecognition extends EventTarget {
    continuous: boolean;
    interimResults: boolean;
    lang: string;
    start(): void;
    stop(): void;
    onstart: ((this: SpeechRecognition, ev: Event) => any) | null;
    onresult: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
    onerror: ((this: SpeechRecognition, ev: SpeechRecognitionErrorEvent) => any) | null;
    onend: ((this: SpeechRecognition, ev: Event) => any) | null;
}


interface SpeechRecognitionHook {
    isListening: boolean;
    transcript: string;
    startListening: () => void;
    stopListening: () => void;
    isSupported: boolean;
    error: string | null;
}

const useSpeechRecognition = (onFinalResult?: (transcript: string) => void): SpeechRecognitionHook => {
    const { language } = useLocalization();
    const [isListening, setIsListening] = useState(false);
    const [transcript, setTranscript] = useState('');
    const [error, setError] = useState<string | null>(null);
    const recognitionRef = useRef<SpeechRecognition | null>(null);
    const isSupported = typeof window !== 'undefined' && ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window);

    useEffect(() => {
      if (!isSupported) return;

      // FIX: Cast window to `any` to access SpeechRecognition properties which are not in standard DOM types.
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      const recognition = recognitionRef.current;
      
      recognition.continuous = false; // Stop after the first final result
      recognition.interimResults = true;
      
      const langMap = {
        fr: 'fr-FR',
        ar: 'ar-DZ',
        en: 'en-US'
      };
      recognition.lang = langMap[language];

      recognition.onstart = () => {
          setIsListening(true);
          setError(null);
          setTranscript('');
      };

      recognition.onresult = (event: SpeechRecognitionEvent) => {
          let interimTranscript = '';
          let finalTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; ++i) {
              if (event.results[i].isFinal) {
                  finalTranscript += event.results[i][0].transcript;
              } else {
                  interimTranscript += event.results[i][0].transcript;
              }
          }
          setTranscript(interimTranscript + finalTranscript);
          if (finalTranscript && onFinalResult) {
              onFinalResult(finalTranscript.trim());
          }
      };
      
      recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
          console.error('Speech recognition error', event.error);
          if(event.error === 'not-allowed' || event.error === 'service-not-allowed') {
            setError("micPermissionDenied"); // Use key for translation
          } else {
            setError("voiceError");
          }
          setIsListening(false);
      };

      recognition.onend = () => {
          setIsListening(false);
      };

      return () => {
        if (recognitionRef.current) {
            recognitionRef.current.stop();
        }
      };
    }, [isSupported, onFinalResult, language]);

    const startListening = useCallback(async () => {
        if (recognitionRef.current && !isListening) {
            setError(null);
            try {
                // Proactively check permission status
                if (navigator.permissions) {
                    const permissionStatus = await navigator.permissions.query({ name: 'microphone' as PermissionName });
                    if (permissionStatus.state === 'denied') {
                        setError("micPermissionDenied");
                        setIsListening(false);
                        return; // Don't even try to start
                    }
                }
                recognitionRef.current.start();
            } catch (e) {
                console.error("Error starting speech recognition:", e);
                if ((e as DOMException).name === 'NotAllowedError') {
                    setError("micPermissionDenied");
                } else {
                    setError("voiceError");
                }
            }
        }
    }, [isListening]);

    const stopListening = useCallback(() => {
        if (recognitionRef.current && isListening) {
            recognitionRef.current.stop();
        }
    }, [isListening]);

    return { isListening, transcript, startListening, stopListening, isSupported, error };
};

export default useSpeechRecognition;