import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';

// Define the shape of user-added car data
interface UserCar {
  brand: string;
  models: string[];
}

interface UserDataContextType {
  userCarData: UserCar[];
  addCarModel: (brand: string, model: string) => void;
  userEngines: string[];
  addEngine: (engine: string) => void;
}

const UserDataContext = createContext<UserDataContextType | undefined>(undefined);

const USER_CAR_DATA_KEY = 'userCarData';
const USER_ENGINES_KEY = 'userEngines';

export const UserDataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [userCarData, setUserCarData] = useState<UserCar[]>([]);
  const [userEngines, setUserEngines] = useState<string[]>([]);

  // Load data from localStorage on initial render
  useEffect(() => {
    try {
      const storedCarData = localStorage.getItem(USER_CAR_DATA_KEY);
      if (storedCarData) {
        setUserCarData(JSON.parse(storedCarData));
      }
      const storedEngineData = localStorage.getItem(USER_ENGINES_KEY);
      if (storedEngineData) {
        setUserEngines(JSON.parse(storedEngineData));
      }
    } catch (error) {
      console.error("Failed to load user data from localStorage", error);
    }
  }, []);

  const addCarModel = (brand: string, model: string) => {
    setUserCarData(prevData => {
      const newBrand = brand.trim();
      const newModel = model.trim();
      if (!newBrand || !newModel) return prevData;

      const updatedData = JSON.parse(JSON.stringify(prevData)); // Deep copy
      const brandIndex = updatedData.findIndex((item: UserCar) => item.brand.toLowerCase() === newBrand.toLowerCase());

      if (brandIndex > -1) {
        // Brand exists, add model if it's not already there
        const existingModels = updatedData[brandIndex].models;
        if (!existingModels.some((m: string) => m.toLowerCase() === newModel.toLowerCase())) {
          updatedData[brandIndex] = {
            ...updatedData[brandIndex],
            models: [...existingModels, newModel].sort(),
          };
        }
      } else {
        // New brand
        updatedData.push({ brand: newBrand, models: [newModel] });
      }
      
      const sortedData = updatedData.sort((a: UserCar, b: UserCar) => a.brand.localeCompare(b.brand));

      // Persist to localStorage
      localStorage.setItem(USER_CAR_DATA_KEY, JSON.stringify(sortedData));
      return sortedData;
    });
  };

  const addEngine = (engine: string) => {
    setUserEngines(prevEngines => {
        const newEngine = engine.trim();
        if (!newEngine || prevEngines.some(e => e.toLowerCase() === newEngine.toLowerCase())) {
            return prevEngines;
        }
        const updatedEngines = [...prevEngines, newEngine].sort();
        localStorage.setItem(USER_ENGINES_KEY, JSON.stringify(updatedEngines));
        return updatedEngines;
    });
  };


  return (
    <UserDataContext.Provider value={{ userCarData, addCarModel, userEngines, addEngine }}>
      {children}
    </UserDataContext.Provider>
  );
};

export const useUserData = (): UserDataContextType => {
  const context = useContext(UserDataContext);
  if (!context) {
    throw new Error('useUserData must be used within a UserDataProvider');
  }
  return context;
};