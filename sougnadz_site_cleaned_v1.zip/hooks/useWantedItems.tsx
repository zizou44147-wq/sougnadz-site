import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { WantedItem } from '../services/types';

interface NewWantedItem {
    title: string;
    category: string;
    description: string;
    budget?: string;
    deliveryWilaya: string;
}

interface WantedItemsContextType {
    wantedItems: WantedItem[];
    addWantedItem: (item: NewWantedItem) => void;
}

const WantedItemsContext = createContext<WantedItemsContextType | undefined>(undefined);

const WANTED_ITEMS_KEY = 'wantedItems';

export const WantedItemsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [wantedItems, setWantedItems] = useState<WantedItem[]>([]);

    useEffect(() => {
        try {
            const storedData = localStorage.getItem(WANTED_ITEMS_KEY);
            if (storedData) {
                setWantedItems(JSON.parse(storedData));
            }
        } catch (error) {
            console.error("Failed to load wanted items from localStorage", error);
        }
    }, []);

    const addWantedItem = (item: NewWantedItem) => {
        setWantedItems(prevItems => {
            const newItem: WantedItem = {
                ...item,
                id: Date.now().toString(),
                userName: "Mock User", // Replace with real user data when available
                createdAt: new Date().toISOString(),
            };
            
            const updatedItems = [newItem, ...prevItems];
            
            localStorage.setItem(WANTED_ITEMS_KEY, JSON.stringify(updatedItems));
            return updatedItems;
        });
    };

    return (
        <WantedItemsContext.Provider value={{ wantedItems, addWantedItem }}>
            {children}
        </WantedItemsContext.Provider>
    );
};

export const useWantedItems = (): WantedItemsContextType => {
    const context = useContext(WantedItemsContext);
    if (!context) {
        throw new Error('useWantedItems must be used within a WantedItemsProvider');
    }
    return context;
};
