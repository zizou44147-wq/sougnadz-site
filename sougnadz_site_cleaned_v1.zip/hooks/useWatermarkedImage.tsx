import { useState, useEffect } from 'react';
import { applyWatermark } from '../utils/imageUtils';

const imageCache = new Map<string, string>();

export const useWatermarkedImage = (imageUrl: string | undefined) => {
    const [watermarkedUrl, setWatermarkedUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (!imageUrl) {
            setIsLoading(false);
            return;
        }

        let isCancelled = false;
        
        const processImage = async () => {
            if (imageCache.has(imageUrl)) {
                if (!isCancelled) {
                    setWatermarkedUrl(imageCache.get(imageUrl)!);
                    setIsLoading(false);
                }
                return;
            }

            try {
                setIsLoading(true);
                const dataUrl = await applyWatermark(imageUrl);
                if (!isCancelled) {
                    imageCache.set(imageUrl, dataUrl);
                    setWatermarkedUrl(dataUrl);
                }
            } catch (error) {
                console.error("Failed to apply watermark", error);
                if (!isCancelled) {
                    setWatermarkedUrl(imageUrl); // Fallback to original
                }
            } finally {
                if (!isCancelled) {
                    setIsLoading(false);
                }
            }
        };

        processImage();

        return () => {
            isCancelled = true;
        };
    }, [imageUrl]);

    return { watermarkedUrl, isLoading };
};


export const useWatermarkedImages = (imageUrls: string[] | undefined) => {
    const [watermarkedUrls, setWatermarkedUrls] = useState<(string | null)[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (!imageUrls || imageUrls.length === 0) {
            setIsLoading(false);
            setWatermarkedUrls([]);
            return;
        }
        
        let isCancelled = false;

        const processImages = async () => {
            setIsLoading(true);
            const results: (string | null)[] = [];
            for (const url of imageUrls) {
                if (isCancelled) return;
                
                if (imageCache.has(url)) {
                    results.push(imageCache.get(url)!);
                } else {
                    try {
                        const dataUrl = await applyWatermark(url);
                        imageCache.set(url, dataUrl);
                        results.push(dataUrl);
                    } catch (error) {
                        console.error("Failed to apply watermark to array image", error);
                        results.push(url); // Fallback
                    }
                }
            }

            if (!isCancelled) {
                setWatermarkedUrls(results);
                setIsLoading(false);
            }
        };

        processImages();
        
        return () => {
            isCancelled = true;
        };

    }, [imageUrls]);

    return { watermarkedUrls, isLoading };
};
