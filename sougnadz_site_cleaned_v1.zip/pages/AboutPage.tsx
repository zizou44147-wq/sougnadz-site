import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocalization } from '../hooks/useLocalization';
import GiftIcon from '../components/icons/GiftIcon';
import UsersIcon from '../components/icons/UsersIcon';
import ShieldCheckIcon from '../components/icons/ShieldCheckIcon';

const AboutPage: React.FC = () => {
    const { t } = useLocalization();
    const navigate = useNavigate();

    useEffect(() => {
        const scriptId = 'page-structured-data';
        document.getElementById(scriptId)?.remove();

        const script = document.createElement('script');
        script.id = scriptId;
        script.type = 'application/ld+json';
        const structuredData = {
            '@context': 'https://schema.org',
            '@type': 'AboutPage',
            'name': t('aboutTitle'),
            'description': t('aboutMissionText'),
            'url': window.location.href,
        };
        script.textContent = JSON.stringify(structuredData);
        document.head.appendChild(script);

        return () => {
            document.getElementById(scriptId)?.remove();
        };
    }, [t]);

    const features = [
        {
            icon: <GiftIcon className="w-10 h-10 text-orange-500" />,
            title: t('aboutFeature1Title'),
            text: t('aboutFeature1Text'),
        },
        {
            icon: <UsersIcon className="w-10 h-10 text-blue-500" />,
            title: t('aboutFeature2Title'),
            text: t('aboutFeature2Text'),
        },
        {
            icon: <ShieldCheckIcon className="w-10 h-10 text-green-500" />,
            title: t('aboutFeature3Title'),
            text: t('aboutFeature3Text'),
        },
    ];

    return (
        <div className="bg-white dark:bg-slate-900">
            <div className="relative pt-16 pb-20 px-4 sm:px-6 lg:pt-24 lg:pb-28 lg:px-8">
                <div className="absolute inset-0">
                    <div className="bg-white dark:bg-slate-900 h-1/3 sm:h-2/3"></div>
                </div>
                <div className="relative max-w-7xl mx-auto">
                    <div className="text-center">
                        <h1 className="text-3xl tracking-tight font-extrabold text-gray-900 dark:text-white sm:text-4xl">{t('aboutTitle')}</h1>
                    </div>

                    <div className="mt-12 max-w-lg mx-auto grid gap-8 lg:grid-cols-2 lg:max-w-none">
                        <div className="bg-gray-50 dark:bg-slate-800/50 rounded-2xl p-8">
                            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">{t('aboutMission')}</h2>
                            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                                {t('aboutMissionText')}
                            </p>
                        </div>
                        <div className="bg-gray-50 dark:bg-slate-800/50 rounded-2xl p-8">
                            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">{t('aboutStory')}</h2>
                            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                                {t('aboutStoryText')}
                            </p>
                        </div>
                    </div>
                    
                    <div className="mt-16 text-center">
                        <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white mb-10">{t('aboutWhyChooseUs')}</h2>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                            {features.map((feature, index) => (
                                <div key={index} className="flex flex-col items-center">
                                    <div className="bg-gray-100 dark:bg-slate-800 rounded-full p-5 mb-4">
                                        {feature.icon}
                                    </div>
                                    <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">{feature.title}</h3>
                                    <p className="text-gray-600 dark:text-gray-300">{feature.text}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="mt-16 text-center">
                        <button
                            onClick={() => navigate('/category/all')}
                            className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-8 rounded-full text-lg transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg"
                        >
                            {t('aboutCTA')}
                        </button>
                    </div>

                </div>
            </div>
        </div>
    );
};

export default AboutPage;