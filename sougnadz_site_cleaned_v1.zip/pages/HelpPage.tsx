import React, { useState, useMemo, useEffect } from 'react';
// FIX: Imported TranslationKey to provide strong typing for translation keys.
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import UserCircleIcon from '../components/icons/UserCircleIcon';
import PencilSquareIcon from '../components/icons/PencilSquareIcon';
import ShieldCheckIcon from '../components/icons/ShieldCheckIcon';
import CogIcon from '../components/icons/CogIcon';
import QuestionMarkCircleIcon from '../components/icons/QuestionMarkCircleIcon';
import ContactFormModal from '../components/ContactFormModal';

// FIX: Added interfaces for FAQ data to ensure keys are of type TranslationKey.
interface FaqItem {
    qKey: TranslationKey;
    aKey: TranslationKey;
}

interface FaqCategory {
    categoryKey: TranslationKey;
    icon: React.ReactNode;
    questions: FaqItem[];
}

const AccordionItem: React.FC<{ title: string; children: React.ReactNode; isOpen: boolean; onClick: () => void }> = ({ title, children, isOpen, onClick }) => {
    return (
        <div className="border-b border-gray-200 dark:border-gray-700">
            <button
                onClick={onClick}
                className="w-full flex justify-between items-center text-start py-4 font-semibold text-gray-800 dark:text-gray-200"
            >
                <span>{title}</span>
                <svg className={`w-5 h-5 text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
            </button>
            <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-screen pb-4' : 'max-h-0'}`}>
                <div className="text-gray-600 dark:text-gray-400 prose">
                    {children}
                </div>
            </div>
        </div>
    );
};

const HelpPage: React.FC = () => {
    const { t } = useLocalization();
    const [searchTerm, setSearchTerm] = useState('');
    const [openAccordion, setOpenAccordion] = useState<string | null>(null);
    const [isContactModalOpen, setIsContactModalOpen] = useState(false);

    // FIX: Applied strong typing to the faqData array.
    const faqData: FaqCategory[] = [
        {
            categoryKey: 'helpCatGettingStarted',
            icon: <UserCircleIcon className="w-8 h-8 text-blue-500" />,
            questions: [
                { qKey: 'helpQ1', aKey: 'helpA1' },
                { qKey: 'helpQ2', aKey: 'helpA2' },
                { qKey: 'helpQ3', aKey: 'helpA3' },
            ],
        },
        {
            categoryKey: 'helpCatPosting',
            icon: <PencilSquareIcon className="w-8 h-8 text-orange-500" />,
            questions: [
                { qKey: 'helpQ4', aKey: 'helpA4' },
                { qKey: 'helpQ5', aKey: 'helpA5' },
                { qKey: 'helpQ6', aKey: 'helpA6' },
            ],
        },
        {
            categoryKey: 'helpCatSafety',
            icon: <ShieldCheckIcon className="w-8 h-8 text-green-500" />,
            questions: [
                { qKey: 'helpQ7', aKey: 'helpA7' },
                { qKey: 'helpQ8', aKey: 'helpA8' },
            ],
        },
        {
            categoryKey: 'helpCatAccount',
            icon: <CogIcon className="w-8 h-8 text-purple-500" />,
            questions: [
                { qKey: 'helpQ9', aKey: 'helpA9' },
                { qKey: 'helpQ10', aKey: 'helpA10' },
            ],
        },
    ];

    useEffect(() => {
        const scriptId = 'faq-structured-data';
        document.getElementById(scriptId)?.remove();

        const script = document.createElement('script');
        script.id = scriptId;
        script.type = 'application/ld+json';

        const structuredData = {
            '@context': 'https://schema.org',
            '@type': 'FAQPage',
            'mainEntity': faqData.flatMap(category => category.questions.map(qa => ({
                '@type': 'Question',
                'name': t(qa.qKey),
                'acceptedAnswer': {
                    '@type': 'Answer',
                    'text': t(qa.aKey)
                }
            })))
        };

        script.textContent = JSON.stringify(structuredData);
        document.head.appendChild(script);

        return () => {
            document.getElementById(scriptId)?.remove();
        };
    }, [faqData, t]);


    const filteredFaq = useMemo(() => {
        if (!searchTerm.trim()) return faqData;

        const lowercasedFilter = searchTerm.toLowerCase();
        
        return faqData.map(category => {
            const filteredQuestions = category.questions.filter(
                q => t(q.qKey).toLowerCase().includes(lowercasedFilter) || t(q.aKey).toLowerCase().includes(lowercasedFilter)
            );
            return { ...category, questions: filteredQuestions };
        }).filter(category => category.questions.length > 0);

    }, [searchTerm, faqData, t]);


    return (
        <>
            <div className="bg-white dark:bg-gray-900">
                <div className="container mx-auto px-4 py-12">
                    {/* Header */}
                    <div className="text-center mb-12">
                        <h1 className="text-4xl sm:text-5xl font-extrabold text-gray-900 dark:text-white">
                            {t('helpPageTitle')}
                        </h1>
                        <p className="mt-4 text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                            {t('helpPageDescription')}
                        </p>
                    </div>

                    {/* Search Bar */}
                    <div className="max-w-2xl mx-auto mb-12">
                        <div className="relative">
                            <input
                                type="search"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                placeholder={t('helpSearchPlaceholder')}
                                className="w-full pl-12 pr-4 py-3 bg-gray-100 dark:bg-gray-800 border-2 border-transparent focus:border-blue-500 focus:ring-blue-500 rounded-full text-lg"
                            />
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                            </div>
                        </div>
                    </div>

                    {/* FAQ Content */}
                    <div className="space-y-12">
                        {filteredFaq.map((category) => (
                            <div key={category.categoryKey}>
                                <div className="flex items-center gap-4 mb-6">
                                    {category.icon}
                                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{t(category.categoryKey)}</h2>
                                </div>
                                <div className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-lg border border-gray-200 dark:border-gray-700/60">
                                    {category.questions.map((q) => (
                                        <AccordionItem
                                            key={q.qKey}
                                            title={t(q.qKey)}
                                            isOpen={openAccordion === q.qKey}
                                            onClick={() => setOpenAccordion(openAccordion === q.qKey ? null : q.qKey)}
                                        >
                                            <p>{t(q.aKey)}</p>
                                        </AccordionItem>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Contact Section */}
                    <div className="mt-16 text-center bg-blue-50 dark:bg-blue-900/40 p-8 rounded-2xl">
                        <QuestionMarkCircleIcon className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                        <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{t('helpContactTitle')}</h3>
                        <p className="mt-2 text-gray-600 dark:text-gray-400">{t('helpContactSubtitle')}</p>
                        <button 
                            onClick={() => setIsContactModalOpen(true)}
                            className="mt-6 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-colors">
                            {t('contactUs')}
                        </button>
                    </div>
                </div>
            </div>
            <ContactFormModal isOpen={isContactModalOpen} onClose={() => setIsContactModalOpen(false)} />
        </>
    );
};

export default HelpPage;