import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import ListingCarousel from '../components/ListingCarousel';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { WILAYAS } from '../constants/geodata';
import { ListingFilters, Commune } from '../services/types';
import { CATEGORIES } from '../constants/categories';
import NavbarLogo from '../components/NavbarLogo';
import { logSearchQuery } from '../services/api';
import AlgeriaFlagIcon from '../components/icons/AlgeriaFlagIcon';
import EuropeFlagIcon from '../components/icons/EuropeFlagIcon';
import VisitedPreviously from '../components/VisitedPreviously';
import VisualSearchModal from '../components/VisualSearchModal';
import CameraIcon from '../components/icons/CameraIcon';
import useSpeechRecognition from '../hooks/useSpeechRecognition';
import MicIcon from '../components/icons/MicIcon';
import Toast from '../components/Toast';
import { usePageMeta } from '../hooks/usePageMeta';
import ForYouGrid from '../components/ForYouGrid';
import Guestbook from '../components/Guestbook';

const SougnaEuropeCard: React.FC = () => {
    const { t, language } = useLocalization();
    const navigate = useNavigate();

    // --- Style functions and constants from NavbarLogo.tsx ---
    const textShadow3d = (color: string, highlight: string, depth = 4) => {
        let shadow = [];
        for (let i = 1; i <= depth; i++) {
            shadow.push(`${i * 0.02}em ${i * 0.03}em 0 ${color}`);
        }
        shadow.push(`0.01em -0.01em 0 ${highlight}`);
        shadow.push(`0.12em 0.15em 0.1em rgba(0,0,0,0.3)`);
        return shadow.join(', ');
    };

    const orangeOutlineValue = '0.025em';
    const whiteOutlineValue = '0.028em';

    const thinOrangeOutline = `
    -${orangeOutlineValue} -${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8),  
     ${orangeOutlineValue} -${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8),
    -${orangeOutlineValue}  ${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8),
     ${orangeOutlineValue}  ${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8)
  `;

    const thinWhiteOutline = `
    -${whiteOutlineValue} -${whiteOutlineValue} 0 rgba(255,255,255,0.8),  
     ${whiteOutlineValue} -${whiteOutlineValue} 0 rgba(255,255,255,0.8),
    -${whiteOutlineValue}  ${whiteOutlineValue} 0 rgba(255,255,255,0.8),
     ${whiteOutlineValue}  ${whiteOutlineValue} 0 rgba(255,255,255,0.8)
  `;

    const styles = {
        sougna: {
            color: '#0d244f',
            textShadow: `${thinOrangeOutline}, ${textShadow3d('#081630', '#3b61aa', 5)}`,
        },
        europe: {
            color: '#f97316',
            textShadow: `${thinWhiteOutline}, ${textShadow3d('#c25a12', '#fdba74', 5)}`,
        },
    };
    
    const [sougnaText, europeText] = t('sougnaEurope').split(' ');

    const logoContent = language === 'ar' ? (
        <div 
            className="relative inline-block font-cairo"
            style={{ fontWeight: 900, letterSpacing: 'normal' }}
            dir="rtl"
        >
            <div className="absolute -bottom-[0.2em] right-[-0.05em] w-[4em] h-[0.8em] z-0">
                <svg viewBox="0 0 100 20" preserveAspectRatio="none" className="w-full h-full">
                    <defs>
                        <linearGradient id="swoosh3D_europe" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stopColor="#fb923c" />
                            <stop offset="50%" stopColor="#f97316" />
                            <stop offset="100%" stopColor="#ea580c" />
                        </linearGradient>
                    </defs>
                    <path d="M 100,15 C 95,20 85,22 70,18 S 30,2 10,5 L 0,0 L 5,8 C 20,15 40,18 60,15 S 90,8 95,12 Z" fill="url(#swoosh3D_europe)" />
                </svg>
            </div>
             <div className="relative z-10 text-[1em]">
              <span style={{ ...styles.sougna, letterSpacing: '-0.05em' }} className="font-cairo">{sougnaText}</span>
              <span style={{ ...styles.europe, marginRight: '0.15em' }} className="font-cairo">{europeText}</span>
            </div>
        </div>
    ) : (
        <div
          className="relative inline-block font-nunito"
          style={{ fontWeight: 900, letterSpacing: '-0.02em' }}
        >
          <div className="absolute -bottom-[0.1em] left-[-0.15em] w-[4.8em] h-[0.8em] z-0">
              <svg viewBox="0 0 100 20" preserveAspectRatio="none" className="w-full h-full">
                  <defs>
                      <linearGradient id="swoosh3D_europe" x1="0%" y1="0%" x2="0%" y2="100%">
                          <stop offset="0%" stopColor="#fb923c" />
                          <stop offset="50%" stopColor="#f97316" />
                          <stop offset="100%" stopColor="#ea580c" />
                      </linearGradient>
                  </defs>
                  <path d="M 0,15 C 5,20 15,22 30,18 S 70,2 90,5 L 100,0 L 95,8 C 80,15 60,18 40,15 S 10,8 5,12 Z" fill="url(#swoosh3D_europe)" />
              </svg>
          </div>
          <div className="relative z-10 text-[1em]">
            <span style={styles.sougna}>{sougnaText}</span>
            <span style={{ ...styles.europe, marginLeft: '0.2em' }}>{europeText}</span>
          </div>
        </div>
    );
    // --- End of style replication ---

    return (
        <div className="container mx-auto px-4 mt-2 mb-4">
            <div
                onClick={() => navigate('/sougna-europe')}
                className="group relative cursor-pointer overflow-hidden rounded-2xl bg-gradient-to-tr from-blue-900/40 to-orange-900/20 p-6 text-center shadow-sm transition-all duration-300 border border-transparent hover:shadow-[0_0_25px_rgba(255,255,255,0.3)] hover:border-white/30"
            >
                <div className="relative z-10">
                    <div className="flex justify-center items-center gap-4 sm:gap-6 mb-3">
                        <EuropeFlagIcon className="w-12 h-12 sm:w-14 sm:h-14 rounded-full shadow-md transition-transform duration-300 group-hover:scale-110" />
                        <h2 className="text-3xl sm:text-4xl font-extrabold transition-transform duration-300 group-hover:scale-105">
                            {logoContent}
                        </h2>
                    </div>
                    <p className="text-md text-gray-300 max-w-2xl mx-auto">
                        {t('sougnaEuropeSubtitle')}
                    </p>
                </div>
            </div>
        </div>
    );
};


interface HeroSectionProps {
    onSearch: (filters: { geniusQuery: string }) => void;
    onPublishClick: () => void;
    onVisualSearchClick: () => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onSearch, onPublishClick, onVisualSearchClick }) => {
    const { t, language } = useLocalization();
    const navigate = useNavigate();
    const [query, setQuery] = useState('');
    const [voiceToast, setVoiceToast] = useState({ show: false, message: '', type: 'error' as 'success' | 'error' });

    const handleVoiceSearchResult = (finalTranscript: string) => {
        setQuery(finalTranscript);
        onSearch({ geniusQuery: finalTranscript });
    };
    
    const {
        isListening,
        transcript,
        startListening,
        isSupported,
        error: voiceError
    } = useSpeechRecognition(handleVoiceSearchResult);
    
    useEffect(() => {
        if(isListening) {
            setQuery(transcript);
        }
    }, [transcript, isListening]);
    
    useEffect(() => {
        if (voiceError) {
            setVoiceToast({ show: true, message: t(voiceError as TranslationKey, t('voiceError')), type: 'error' });
        }
    }, [voiceError, t]);

    const handleVoiceClick = () => {
        if (!isSupported) {
            setVoiceToast({ show: true, message: t('voiceUnsupported'), type: 'error' });
            return;
        }
        startListening();
    };

    const homeCategories = useMemo(() => 
        CATEGORIES.map(c => ({ slug: c.slug, labelKey: c.labelKey as TranslationKey}))
    , []);
    
    const handleCategoryClick = (slug: string) => {
        navigate(`/category/${slug}`);
    };
    
    const handleSearchClick = () => {
        onSearch({ geniusQuery: query });
    };

    return (
        <div className="relative text-center pt-4 pb-2 sm:pt-6 sm:pb-3 overflow-hidden bg-gradient-to-b from-gray-900 to-black">
            <Toast 
                message={voiceToast.message} 
                show={voiceToast.show} 
                onClose={() => setVoiceToast({ show: false, message: '', type: 'error' })}
                type={voiceToast.type} 
            />
            <div className="container mx-auto px-4 relative z-10">
                <div className="max-w-4xl mx-auto">
                    <div className="mb-4 animate-enter" style={{ animationDelay: '100ms' }}>
                        <NavbarLogo className="text-5xl sm:text-6xl" />
                    </div>
                    <h1 
                        className="text-4xl sm:text-5xl font-extrabold mt-2 text-white animate-enter" 
                        style={{ animationDelay: '250ms' }}
                    >
                        {t('heroTitle')}
                    </h1>
                    <p 
                        className="mt-3 text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto animate-enter" 
                        style={{ animationDelay: '400ms' }}
                    >
                        {t('heroSubtitle')}
                    </p>
                    <button 
                        onClick={onPublishClick} 
                        className="mt-6 inline-block bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-8 rounded-full text-lg transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-orange-500/40 active:translate-y-0 active:scale-95 animate-enter"
                        style={{ animationDelay: '550ms' }}
                    >
                        {t('publishAdFree')}
                    </button>
                    <div className="mt-6 max-w-3xl mx-auto animate-enter" style={{ animationDelay: '700ms' }}>
                        {/* Search Bar */}
                        <div className="flex flex-col sm:flex-row items-center gap-2 bg-slate-800 p-2 rounded-full backdrop-blur-sm border border-slate-700 shadow-lg">
                            <button onClick={onVisualSearchClick} className="flex-shrink-0 p-3 text-gray-400 hover:text-white transition-colors rounded-full hover:bg-slate-700" title={t('findByImage')}>
                                <CameraIcon className="w-6 h-6" />
                            </button>
                            <div className="h-6 w-px bg-slate-700 hidden sm:block"></div>
                            <div className="relative flex-grow w-full">
                                <input
                                    type="text"
                                    placeholder={isListening ? t('voiceListening') : t('smartSearchPlaceholder')}
                                    value={query}
                                    onChange={(e) => setQuery(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSearchClick()}
                                    className="w-full bg-transparent text-white placeholder-gray-400 px-4 py-2 focus:outline-none"
                                />
                                <button onClick={handleVoiceClick} className="absolute inset-y-0 end-0 flex items-center pr-3" title={t('voiceSearch')}>
                                    <MicIcon className={`w-5 h-5 transition-colors ${isListening ? 'text-red-500 animate-pulse' : 'text-gray-400 hover:text-white'}`} />
                                </button>
                            </div>
                            <button onClick={handleSearchClick} className="w-full sm:w-auto flex-shrink-0 bg-blue-600 hover:bg-blue-700 text-white font-bold p-3 rounded-full transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg active:scale-95 flex items-center justify-center sm:w-12 sm:h-12">
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                                <span className="sm:hidden ml-2">{t('searchButton')}</span>
                            </button>
                        </div>

                        <div className="mt-4 grid grid-cols-3 sm:grid-cols-5 gap-1.5 max-w-3xl mx-auto">
                            {homeCategories.map(cat => (
                                 <button
                                    key={cat.slug}
                                    onClick={() => handleCategoryClick(cat.slug)}
                                    className="category-fire-button w-full"
                                >
                                    {t(cat.labelKey)}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            <style>{`
                @keyframes enter-anim {
                    from {
                        opacity: 0;
                        transform: translateY(20px);
                        filter: blur(5px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                        filter: blur(0);
                    }
                }
                .animate-enter {
                    animation: enter-anim 0.8s ease-out both;
                }
            `}</style>
        </div>
    );
};


const HomePage: React.FC = () => {
    const { t } = useLocalization();
    const navigate = useNavigate();
    const [isVisualSearchModalOpen, setIsVisualSearchModalOpen] = useState(false);
    
    usePageMeta({
        title: `sougnadz.com | ${t('heroTitle')}`,
        description: t('heroSubtitle'),
        keywords: 'annonces algérie, ouedkniss, oued kniss, sougnadz, vente, achat, voitures, immobilier, téléphones, algérie, dz, سوق, واد كنيس, auto, immobilier, emploi, services, annonces gratuites, alger, oran, constantine'
    });
    
    const handleSearch = (filters: { geniusQuery: string }) => {
        const searchParams = new URLSearchParams();
        if (filters.geniusQuery.trim()) {
            searchParams.set('geniusQuery', filters.geniusQuery.trim());
            logSearchQuery(filters.geniusQuery.trim());
        }
        navigate(`/category/all?${searchParams.toString()}`);
    };
    
    const handleCarouselClick = useCallback((slug: string) => {
        navigate(`/category/${slug}`);
    }, [navigate]);

    const carousels = useMemo(() => {
        const strategicOrder: TranslationKey[] = [
            'categoryVehicles',
            'categoryRealEstate',
            'categorySpareParts',
            'categorySmartphones',
            'categoryComputers',
            'categoryAppliances',
            'categoryClothing',
            'categoryFurniture',
            'categoryJobs',
            'categoryJobSeekers',
            'categoryCharity',
        ];
        
        const allCarousels = CATEGORIES.map(cat => ({
            key: cat.labelKey,
            filters: { category: cat.apiName, market: 'dz' as const },
            slug: cat.slug,
        }));

        return allCarousels.sort((a, b) => {
            const indexA = strategicOrder.indexOf(a.key);
            const indexB = strategicOrder.indexOf(b.key);
            if (indexA === -1 && indexB === -1) return 0;
            if (indexA === -1) return 1;
            if (indexB === -1) return -1;
            return indexA - indexB;
        });
    }, []);

    return (
        <div className="bg-black">
            <Guestbook />
            <HeroSection 
                onSearch={handleSearch}
                onPublishClick={() => navigate('/post-ad')}
                onVisualSearchClick={() => setIsVisualSearchModalOpen(true)}
            />

            <SougnaEuropeCard />
            
            <VisitedPreviously market="dz" />

            <ForYouGrid market="dz" />

            {carousels.map(carousel => (
                 <ListingCarousel 
                    key={carousel.key} 
                    title={t(carousel.key)} 
                    filters={carousel.filters}
                    onViewAllClick={() => handleCarouselClick(carousel.slug)}
                />
            ))}
            
            <VisualSearchModal isOpen={isVisualSearchModalOpen} onClose={() => setIsVisualSearchModalOpen(false)} />
        </div>
    );
};

export default HomePage;
