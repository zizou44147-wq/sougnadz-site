import React, { useState, useCallback, useRef } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import { GoogleGenAI, Modality } from "@google/genai";
import UploadIcon from '../components/icons/UploadIcon';
import SparklesIcon from '../components/icons/SparklesIcon';

// Helper to convert file to base64 string
const fileToBase64 = (file: File): Promise<{ base64Data: string; mimeType: string }> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const result = reader.result as string;
            const [header, base64Data] = result.split(',');
            const mimeType = header.match(/:(.*?);/)?.[1] || file.type;
            resolve({ base64Data, mimeType });
        };
        reader.onerror = error => reject(error);
    });
};


const ImageEditorPage: React.FC = () => {
    const { t } = useLocalization();

    const [originalImageFile, setOriginalImageFile] = useState<File | null>(null);
    const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(null);
    const [editedImageUrl, setEditedImageUrl] = useState<string | null>(null);
    const [prompt, setPrompt] = useState<string>('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isDragging, setIsDragging] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileSelect = (file: File | null) => {
        if (file && file.type.startsWith('image/')) {
            setOriginalImageFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setOriginalImageUrl(reader.result as string);
                setEditedImageUrl(null);
                setError(null);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        handleFileSelect(e.target.files?.[0] || null);
    };

    const onDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(true);
    };
    const onDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
    };
    const onDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
    };
    const onDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        handleFileSelect(e.dataTransfer.files?.[0] || null);
    };
    
    const handleGenerate = async () => {
        if (!prompt || !originalImageFile) return;

        setIsLoading(true);
        setError(null);
        setEditedImageUrl(null);

        try {
            if (!process.env.API_KEY) {
                throw new Error("API_KEY environment variable not set");
            }

            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const { base64Data, mimeType } = await fileToBase64(originalImageFile);
            
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: {
                    parts: [
                        {
                            inlineData: {
                                data: base64Data,
                                mimeType: mimeType,
                            },
                        },
                        { text: prompt },
                    ],
                },
                config: {
                    responseModalities: [Modality.IMAGE],
                },
            });
            
            let foundImage = false;
            if (response.candidates && response.candidates.length > 0) {
                 for (const part of response.candidates[0].content.parts) {
                    if (part.inlineData) {
                        const base64ImageBytes: string = part.inlineData.data;
                        const responseMimeType: string = part.inlineData.mimeType;
                        const imageUrl = `data:${responseMimeType};base64,${base64ImageBytes}`;
                        setEditedImageUrl(imageUrl);
                        foundImage = true;
                        break; 
                    }
                }
            }
           
            if (!foundImage) {
                throw new Error("No image was returned by the API.");
            }

        } catch (err) {
            console.error("Error editing image with Gemini:", err);
            setError(t('errorEditingImage'));
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleStartOver = () => {
        setOriginalImageFile(null);
        setOriginalImageUrl(null);
        setEditedImageUrl(null);
        setPrompt('');
        setError(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    const handleDownload = () => {
        if (!editedImageUrl) return;
        const link = document.createElement('a');
        link.href = editedImageUrl;
        link.download = `edited_${originalImageFile?.name || 'image.png'}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="bg-slate-900 min-h-screen py-12">
            <div className="container mx-auto px-4 text-white">
                <header className="text-center mb-10">
                    <h1 className="text-4xl font-extrabold mb-2">{t('imageEditorTitle')}</h1>
                    <p className="text-lg text-slate-400 max-w-2xl mx-auto">{t('imageEditorDescription')}</p>
                </header>

                <main>
                    {!originalImageUrl ? (
                        <div
                            onDragEnter={onDragEnter}
                            onDragLeave={onDragLeave}
                            onDragOver={onDragOver}
                            onDrop={onDrop}
                            onClick={() => fileInputRef.current?.click()}
                            className={`mx-auto max-w-3xl border-4 border-dashed rounded-2xl p-10 text-center cursor-pointer transition-all duration-300 ${isDragging ? 'border-blue-500 bg-slate-800' : 'border-slate-700 hover:border-blue-600 hover:bg-slate-800/50'}`}
                        >
                            <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
                            <UploadIcon className="w-16 h-16 mx-auto text-slate-500 mb-4" />
                            <h2 className="text-xl font-semibold">{t('uploadYourImage')}</h2>
                            <p className="text-slate-400">{isDragging ? t('dropHere') : t('dragDropOrClick')}</p>
                        </div>
                    ) : (
                        <div className="space-y-8">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <div className="text-center">
                                    <h3 className="text-xl font-bold mb-3">{t('originalImage')}</h3>
                                    <img src={originalImageUrl} alt="Original" className="rounded-lg shadow-lg w-full aspect-square object-contain bg-black" />
                                </div>
                                <div className="text-center">
                                    <h3 className="text-xl font-bold mb-3">{t('editedImage')}</h3>
                                    <div className="rounded-lg shadow-lg w-full aspect-square bg-black flex items-center justify-center">
                                        {isLoading ? (
                                            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
                                        ) : editedImageUrl ? (
                                            <img src={editedImageUrl} alt="Edited" className="w-full h-full object-contain" />
                                        ) : error ? (
                                             <div className="text-red-400 p-4">{error}</div>
                                        ) : (
                                            <SparklesIcon className="w-24 h-24 text-slate-700" />
                                        )}
                                    </div>
                                </div>
                            </div>

                            <div className="max-w-3xl mx-auto space-y-4">
                                <div className="flex items-center gap-4">
                                    <textarea
                                        value={prompt}
                                        onChange={(e) => setPrompt(e.target.value)}
                                        placeholder={t('editPromptPlaceholder')}
                                        rows={2}
                                        className="flex-grow bg-slate-800 border border-slate-700 rounded-lg shadow-sm py-3 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                                    />
                                    <button
                                        onClick={handleGenerate}
                                        disabled={isLoading || !prompt}
                                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-colors disabled:bg-blue-400/50 disabled:cursor-not-allowed flex items-center gap-2"
                                    >
                                        <SparklesIcon className="w-5 h-5" />
                                        {isLoading ? t('generatingImage') : t('generate')}
                                    </button>
                                </div>

                                <div className="text-center text-xs text-slate-500">
                                    <p>
                                        {t('tryPromptsLike')} {' '}
                                        <span className="italic">"{t('promptExample1')}"</span>,{' '}
                                        <span className="italic">"{t('promptExample2')}"</span>,{' '}
                                        <span className="italic">"{t('promptExample3')}"</span>
                                    </p>
                                </div>

                                {editedImageUrl && (
                                    <div className="flex items-center justify-center gap-4 pt-4">
                                        <button onClick={handleDownload} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-5 rounded-lg transition-colors">{t('downloadImage')}</button>
                                        <button onClick={handleStartOver} className="bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-5 rounded-lg transition-colors">{t('startOver')}</button>
                                    </div>
                                )}
                                {!editedImageUrl && (
                                      <div className="flex items-center justify-center gap-4 pt-4">
                                          <button onClick={handleStartOver} className="bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-5 rounded-lg transition-colors">{t('startOver')}</button>
                                      </div>
                                )}
                            </div>
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
};

export default ImageEditorPage;
