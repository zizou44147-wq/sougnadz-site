import React, { useEffect, useState, useMemo, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchListingById } from '../services/api';
import { Listing } from '../services/types';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import DonationModal from '../components/DonationModal';
import Toast from '../components/Toast';
import PhoneIcon from '../components/icons/PhoneIcon';
import WhatsAppIcon from '../components/icons/WhatsAppIcon';
import ChatModal from '../components/ChatModal';
import ChatIcon from '../components/icons/ChatIcon';
import { useReportAd } from '../hooks/useReportAd';
import { CATEGORIES } from '../constants/categories';
import ArrowLeftIcon from '../components/icons/ArrowLeftIcon';
import ShareIcon from '../components/icons/ShareIcon';
import FacebookIcon from '../components/icons/FacebookIcon';
import TwitterIcon from '../components/icons/TwitterIcon';
import TelegramIcon from '../components/icons/TelegramIcon';
import LinkIcon from '../components/icons/LinkIcon';
import CheckIcon from '../components/icons/CheckIcon';
import ListingCarousel from '../components/ListingCarousel';
import VirtualShowroomModal from '../components/VirtualShowroomModal';
import SparklesIcon from '../components/icons/SparklesIcon';
import { useWatermarkedImage, useWatermarkedImages } from '../hooks/useWatermarkedImage';
import { usePageMeta } from '../hooks/usePageMeta';
import StarIcon from '../components/icons/StarIcon';

const UserStatus: React.FC<{ isOnline: boolean }> = ({ isOnline }) => {
    const { t } = useLocalization();
    const color = isOnline ? 'text-green-400' : 'text-gray-400';
    const bgColor = isOnline ? 'bg-green-400' : 'bg-gray-400';
    return (
        <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${bgColor}`}></span>
            <span className={`text-xs font-semibold ${color}`}>{isOnline ? t('online') : t('offline')}</span>
        </div>
    );
};

const ListingDetailsPage: React.FC = () => {
    const { t, language } = useLocalization();
    const { listingId: listingIdParam } = useParams<{ listingId: string }>();
    const { openReportAdModal } = useReportAd();
    const navigate = useNavigate();
    const [listing, setListing] = useState<Listing | null>(null);
    const [loading, setLoading] = useState(true);
    const [mainImage, setMainImage] = useState<string>('');
    const [isDonationModalOpen, setIsDonationModalOpen] = useState(false);
    const [showToast, setShowToast] = useState(false);
    const [isLightboxOpen, setIsLightboxOpen] = useState(false);
    const [currentLightboxIndex, setCurrentLightboxIndex] = useState(0);
    const [isChatModalOpen, setIsChatModalOpen] = useState(false);
    const [showPhoneNumber, setShowPhoneNumber] = useState(false);
    const [isShareMenuOpen, setIsShareMenuOpen] = useState(false);
    const [linkCopied, setLinkCopied] = useState(false);
    const shareMenuRef = useRef<HTMLDivElement>(null);
    const [isVsModalOpen, setIsVsModalOpen] = useState(false);
    
    const listingId = useMemo(() => listingIdParam ? parseInt(listingIdParam, 10) : undefined, [listingIdParam]);
    
    usePageMeta({
        title: listing ? `${listing.title} - ${listing.price}` : t('listingDetails'),
        description: listing?.description ? `${listing.description.substring(0, 155)}...` : t('listingDetails'),
        keywords: listing ? `${listing.title}, ${listing.category}, ${listing.location}, ${listing.meta.brand || ''}, ${listing.meta.model || ''}` : 'annonce, algérie',
        imageUrl: listing?.imageUrl,
    });


    const carTitle = useMemo(() => {
        if (listing && listing.category === 'Automobiles & Véhicules' && listing.meta.brand && listing.meta.model) {
            const mainTitle = `${listing.meta.brand} ${listing.meta.model}`;
            const subTitle = listing.title.replace(mainTitle, '').trim();
            return { main: mainTitle, sub: subTitle };
        }
        return { main: listing?.title || '', sub: null };
    }, [listing]);

    const allImages = useMemo(() => {
        if (!listing) return [];
        return [listing.imageUrl, ...(listing.images || [])];
    }, [listing]);

    const { watermarkedUrl: watermarkedMainImage, isLoading: isMainImageLoading } = useWatermarkedImage(mainImage);
    const { watermarkedUrls: watermarkedThumbnails, isLoading: areThumbnailsLoading } = useWatermarkedImages(allImages);
    const { watermarkedUrls: watermarkedLightboxImages, isLoading: areLightboxImagesLoading } = useWatermarkedImages(isLightboxOpen ? allImages : undefined);
    
    useEffect(() => {
        if (typeof listingId === 'number' && !isNaN(listingId)) {
            const viewed = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
            const updatedViewed = [listingId, ...viewed.filter((id: number) => id !== listingId)].slice(0, 10);
            localStorage.setItem('recentlyViewed', JSON.stringify(updatedViewed));
        }
    }, [listingId]);

    useEffect(() => {
        const scriptId = 'listing-structured-data';
        // Clean up previous script on unmount or before re-rendering
        const existingScript = document.getElementById(scriptId);
        if (existingScript) {
            existingScript.remove();
        }

        if (listing) {
            // AI-Powered SEO: Inject JSON-LD structured data for Google
            const script = document.createElement('script');
            script.id = scriptId;
            script.type = 'application/ld+json';

            const structuredData = {
                '@context': 'https://schema.org',
                '@type': 'Product',
                'name': listing.title,
                'image': listing.imageUrl,
                'description': listing.description,
                'sku': `sougnadz-${listing.id}`,
                'mpn': `sougnadz-${listing.id}`, // Manufacturer Part Number, can be same as SKU
                'brand': {
                    '@type': 'Brand',
                    'name': listing.meta.brand || 'N/A'
                },
                'offers': {
                    '@type': 'Offer',
                    'url': window.location.href,
                    'priceCurrency': 'DZD',
                    'price': listing.priceValue || listing.price.replace(/[^0-9]/g, ''),
                    'availability': 'https://schema.org/InStock',
                    'seller': {
                        '@type': 'Person',
                        'name': listing.user.name
                    }
                },
                ...(listing.user.rating && {
                    "aggregateRating": {
                        "@type": "AggregateRating",
                        "ratingValue": listing.user.rating,
                        "reviewCount": Math.floor(listing.user.rating * 5) + 3 // Mock review count
                    }
                })
            };
            
            script.textContent = JSON.stringify(structuredData);
            document.head.appendChild(script);
        }

        return () => {
            const scriptToRemove = document.getElementById(scriptId);
            if (scriptToRemove) {
                scriptToRemove.remove();
            }
        };
    }, [listing]);
    

    const openLightbox = (index: number) => {
        setCurrentLightboxIndex(index);
        setIsLightboxOpen(true);
    };

    const closeLightbox = () => {
        setIsLightboxOpen(false);
    };

    const nextImage = useMemo(() => () => {
        if (allImages.length === 0) return;
        setCurrentLightboxIndex((prevIndex) => (prevIndex + 1) % allImages.length);
    }, [allImages.length]);

    const prevImage = useMemo(() => () => {
         if (allImages.length === 0) return;
        setCurrentLightboxIndex((prevIndex) => (prevIndex - 1 + allImages.length) % allImages.length);
    }, [allImages.length]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (!isLightboxOpen) return;
            if (e.key === 'ArrowRight') nextImage();
            if (e.key === 'ArrowLeft') prevImage();
            if (e.key === 'Escape') closeLightbox();
        };

        window.addEventListener('keydown', handleKeyDown);

        const handleClickOutside = (event: MouseEvent) => {
            if (shareMenuRef.current && !shareMenuRef.current.contains(event.target as Node)) {
                setIsShareMenuOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            document.removeEventListener('mousedown', handleClickOutside);
        }
    }, [isLightboxOpen, nextImage, prevImage, language]);

    useEffect(() => {
        if (typeof listingId !== 'number' || isNaN(listingId)) {
            setLoading(false);
            setListing(null);
            return;
        }

        const loadListing = async () => {
            setLoading(true);
            const data = await fetchListingById(listingId);
            setListing(data || null);
            if (data) {
                setMainImage(data.imageUrl);
            }
            setLoading(false);
        };
        loadListing();
    }, [listingId]);
    
    const handleReportClick = () => {
        if (listing) {
            openReportAdModal(listing);
        }
    };
    
    const handleBackClick = () => {
        // -1 navigates back in the history stack.
        navigate(-1);
    };

    const handleCopyLink = () => {
        navigator.clipboard.writeText(window.location.href).then(() => {
            setLinkCopied(true);
            setTimeout(() => {
                setLinkCopied(false);
                setIsShareMenuOpen(false);
            }, 1500);
        });
    };

    const encodedTitle = encodeURIComponent(listing?.title || '');
    const listingUrl = window.location.href;

    const shareOptions = [
        { name: 'Facebook', icon: <FacebookIcon className="w-6 h-6" />, url: `https://www.facebook.com/sharer/sharer.php?u=${listingUrl}` },
        { name: 'Twitter', icon: <TwitterIcon className="w-6 h-6" />, url: `https://twitter.com/intent/tweet?url=${listingUrl}&text=${encodedTitle}` },
        { name: 'WhatsApp', icon: <WhatsAppIcon className="w-6 h-6" />, url: `https://api.whatsapp.com/send?text=${encodedTitle}%20${listingUrl}` },
        { name: 'Telegram', icon: <TelegramIcon className="w-6 h-6" />, url: `https://t.me/share/url?url=${listingUrl}&text=${encodedTitle}` }
    ];

    const categoryInfo = useMemo(() =>
        listing ? CATEGORIES.find(c => c.apiName === listing.category) : undefined
    , [listing]);

    const handleViewAllRelated = () => {
        if (categoryInfo) {
            navigate(`/category/${categoryInfo.slug}`);
        }
    };


    const renderDetails = () => {
        if (!listing) return null;

        const carDetailsConfig = [
            { metaKey: 'brand', labelKey: 'filterBrand' },
            { metaKey: 'model', labelKey: 'filterModel' },
            { metaKey: 'trim', labelKey: 'trim' },
            { metaKey: 'year', labelKey: 'filterYear' },
            { metaKey: 'km', labelKey: 'filterKm', format: (val: number) => `${val.toLocaleString(language === 'fr' ? 'fr-FR' : 'ar-DZ')} km` },
            { metaKey: 'engine', labelKey: 'engine' },
            { metaKey: 'fuel', labelKey: 'filterFuel', valueMapKey: 'fuel' },
            { metaKey: 'transmission', labelKey: 'filterTransmission', valueMapKey: 'transmission' },
            { metaKey: 'papers', labelKey: 'filterPapers', valueMapKey: 'papers' },
            { metaKey: 'exchange', labelKey: 'filterExchange', valueMapKey: 'exchange' },
        ];
        
        const immoDetailsConfig = [
             { metaKey: 'surface', labelKey: 'surface', format: (val: number) => `${val} m²` },
             { metaKey: 'rooms', labelKey: 'rooms' },
             { metaKey: 'furnished', labelKey: 'furnishedLabel' },
        ];

        const valueTranslationMap: { [key: string]: { [val: string]: TranslationKey } } = {
            fuel: { 'essence': 'fuelEssence', 'diesel': 'fuelDiesel', 'gpl': 'fuelGpl', 'hybride': 'fuelHybrid', 'electrique': 'fuelElectric', 'autre': 'fuelOther' },
            transmission: { 'manuelle': 'gearboxManual', 'automatique': 'gearboxAutomatic', 'semi_automatique': 'gearboxSemiAutomatic' },
            papers: { 'carte_grise_safia': 'papersCard', 'licence_delai': 'papersLicense' },
            exchange: { 'accepte': 'exchangeAccepts', 'uniquement': 'exchangeOnly', 'aucun': 'exchangeNone' }
        };

        let detailsToShow;
        if (listing.category === 'Automobiles & Véhicules') {
            detailsToShow = carDetailsConfig;
        } else if (listing.category === 'Immobilier') {
            detailsToShow = immoDetailsConfig;
        } else {
            detailsToShow = Object.keys(listing.meta).map(key => ({ metaKey: key, labelKey: key as TranslationKey }));
        }

        return (
            <div className="mt-8 p-6 bg-[#10162b] rounded-lg">
                <h3 className="text-xl font-semibold text-white mb-4">{t('listingDetails')}</h3>
                <dl className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-6">
                    {detailsToShow.map(detail => {
                        const value = listing.meta[detail.metaKey];
                        if (value === undefined || value === null || value === '') return null;

                        let displayValue;
                        if (detail.valueMapKey) {
                            const translationKey = valueTranslationMap[detail.valueMapKey]?.[String(value)];
                            displayValue = translationKey ? t(translationKey) : String(value);
                        } else if (detail.format) {
                            displayValue = detail.format(value as number);
                        } else {
                            const translatedLabel = t(detail.labelKey, detail.metaKey);
                             displayValue = String(value);
                             if (translatedLabel === detail.metaKey) {
                                 detail.labelKey = detail.metaKey.charAt(0).toUpperCase() + detail.metaKey.slice(1) as TranslationKey;
                             }
                        }

                        return (
                            <div key={detail.metaKey}>
                                <dt className="text-sm font-medium text-gray-400">{t(detail.labelKey, detail.metaKey.charAt(0).toUpperCase() + detail.metaKey.slice(1))}</dt>
                                <dd className="mt-1 font-semibold text-white">{displayValue}</dd>
                            </div>
                        );
                    })}
                </dl>
            </div>
        );
    };
    
    const priceTypeTranslation: { [key: string]: TranslationKey } = {
        fixe: 'priceFixe',
        negociable: 'priceNegociable',
        offre: 'priceOffre',
    };

    if (loading) return <div className="text-center py-20 text-2xl">Loading...</div>;
    if (!listing) return <div className="text-center py-20 text-2xl text-red-500">{t('noListingFound')}</div>;
    
    const isVSEnabled = ['Meubles & Maison', 'Électroménager & Électronique', 'Loisirs & Divertissements', 'Informatique'].includes(listing.category);

    return (
        <>
        <div className="container mx-auto px-4 py-8">
             <div className="mb-6">
                <button
                    onClick={handleBackClick}
                    className="inline-flex items-center gap-2 bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg hover:shadow-orange-500/40 active:translate-y-0 active:scale-95"
                >
                    <ArrowLeftIcon className="w-5 h-5" />
                    <span>{t('backToResults')}</span>
                </button>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column: Images & Details */}
                <div className="lg:col-span-2">
                    <div>
                         <div className="w-full h-[300px] md:h-[450px] bg-gray-800 rounded-lg mb-4 overflow-hidden group">
                            {isMainImageLoading ? (
                                <div className="w-full h-full animate-pulse"></div>
                            ) : (
                                <button onClick={() => openLightbox(allImages.indexOf(mainImage))} className="w-full h-full">
                                    <img src={watermarkedMainImage || mainImage} alt={listing.title} loading="lazy" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                                </button>
                            )}
                        </div>
                        <div className="flex gap-2">
                            {areThumbnailsLoading ? (
                                Array.from({ length: allImages.length }).map((_, index) => (
                                    <div key={index} className="w-20 h-20 md:w-24 md:h-24 flex-shrink-0 bg-gray-800 rounded-md animate-pulse"></div>
                                ))
                            ) : (
                                watermarkedThumbnails.map((img, index) => (
                                    <button
                                        key={index}
                                        onClick={() => setMainImage(allImages[index])}
                                        className={`w-20 h-20 md:w-24 md:h-24 flex-shrink-0 bg-gray-800 rounded-md cursor-pointer border-2 overflow-hidden transition-all ${mainImage === allImages[index] ? 'border-blue-500 scale-105' : 'border-transparent hover:border-blue-400'}`}
                                    >
                                        <img 
                                            src={img || allImages[index]} 
                                            alt={`thumbnail ${index + 1}`} 
                                            loading="lazy"
                                            className="w-full h-full object-cover"
                                        />
                                    </button>
                                ))
                            )}
                        </div>
                    </div>

                    <div className="mt-8 text-start">
                        <h1 className="text-3xl md:text-4xl font-bold text-white">{carTitle.main}</h1>
                        {carTitle.sub && <p className="text-xl text-gray-300 mt-1">{carTitle.sub}</p>}
                        <div className="flex items-baseline gap-3 mt-2">
                            <p className="text-3xl font-bold text-orange-400">
                                {listing.price}
                            </p>
                            {listing.meta.priceType && (
                                <span className="text-sm font-semibold text-gray-300 bg-gray-700 px-3 py-1 rounded-full">
                                    {t(priceTypeTranslation[listing.meta.priceType])}
                                </span>
                            )}
                        </div>
                        <p className="text-gray-400 mt-2">{listing.location}, {listing.commune}</p>
                    </div>

                    {renderDetails()}

                    <div className="mt-8 text-start">
                        <h3 className="text-xl font-semibold text-white mb-2">{t('description')}</h3>
                        <p className="text-gray-300 whitespace-pre-line">{listing.description || 'Pas de description disponible.'}</p>
                    </div>
                </div>

                {/* Right Column: Seller Info & Actions */}
                <div className="lg:col-span-1">
                    <div className="bg-[#10162b] p-6 rounded-lg shadow-md shadow-black/25 sticky top-24">
                        <h3 className="text-xl font-semibold text-white mb-4 text-start">{t('sellerInformation')}</h3>
                        <div className="flex items-start gap-4 mb-6">
                            <img src={listing.user.avatarUrl} alt={listing.user.name} className="w-16 h-16 rounded-full" />
                            <div className='flex-1'>
                                <p className="text-lg font-bold text-white">{listing.user.name}</p>
                                <UserStatus isOnline={listing.user.isOnline} />
                                {listing.user.rating && (
                                    <div className="flex items-center gap-1.5 mt-2">
                                        <StarIcon className="h-5 w-5 text-amber-400" />
                                        <span className="font-bold text-white">{listing.user.rating.toFixed(1)}</span>
                                        <span className="text-sm text-gray-400">({Math.floor(listing.user.rating * 5) + 3} {t('reviews')})</span>
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="space-y-3">
                             {isVSEnabled && (
                                <button 
                                    onClick={() => setIsVsModalOpen(true)}
                                    className="w-full bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white font-bold py-3 rounded-lg text-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-3 shadow-lg shadow-cyan-500/30"
                                >
                                    <SparklesIcon className="w-6 h-6" />
                                    <span>{t('tryInYourRoom')}</span>
                                </button>
                             )}
                             <a 
                                href={showPhoneNumber ? `tel:${listing.contact.phone}` : '#'}
                                onClick={() => setShowPhoneNumber(true)}
                                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg text-lg transition-colors flex items-center justify-center gap-3"
                            >
                                <PhoneIcon />
                                <span>{showPhoneNumber ? listing.contact.phone : t('showPhoneNumber')}</span>
                            </a>
                             <a 
                                href={`https://wa.me/${listing.contact.phone.replace(/\s/g, '')}`}
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-lg text-lg transition-colors flex items-center justify-center gap-3"
                            >
                                <WhatsAppIcon />
                                <span>{t('contactOnWhatsApp')}</span>
                            </a>
                            <button 
                                onClick={() => setIsChatModalOpen(true)}
                                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold py-3 rounded-lg text-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-3 shadow-lg shadow-purple-500/30"
                            >
                                <ChatIcon />
                                {t('chatWithSeller')}
                            </button>
                             <div className="relative" ref={shareMenuRef}>
                                <button
                                    onClick={() => setIsShareMenuOpen(prev => !prev)}
                                    className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-lg text-lg transition-colors flex items-center justify-center gap-3"
                                >
                                    <ShareIcon />
                                    <span>{t('share')}</span>
                                </button>
                                
                                <div className={`absolute bottom-full mb-2 w-full bg-[#1f2937] border border-gray-700 rounded-lg shadow-xl p-2 transition-all duration-300 ease-out origin-bottom ${isShareMenuOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
                                    <div className="flex justify-around items-center">
                                        {shareOptions.map(option => (
                                            <a
                                                key={option.name}
                                                href={option.url}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="p-3 rounded-full text-gray-300 hover:bg-gray-800"
                                                aria-label={`Share on ${option.name}`}
                                            >
                                                {option.icon}
                                            </a>
                                        ))}
                                        <button
                                            onClick={handleCopyLink}
                                            className="p-3 rounded-full text-gray-300 hover:bg-gray-800"
                                            aria-label="Copy link"
                                        >
                                            {linkCopied ? <CheckIcon className="w-6 h-6 text-green-500" /> : <LinkIcon className="w-6 h-6" />}
                                        </button>
                                    </div>
                                    {linkCopied && <p className="text-center text-xs text-green-500 mt-1">{t('linkCopied')}</p>}
                                </div>
                            </div>

                             {listing.category === 'Services' && listing.subCategory === 'actions-caritatives' && listing.donationInfo && (
                                 <button onClick={() => setIsDonationModalOpen(true)} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-lg text-lg transition-colors flex items-center justify-center gap-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                                    </svg>
                                    {t('supportCause')}
                                </button>
                            )}
                        </div>

                        <button 
                            onClick={handleReportClick}
                            className="w-full bg-red-900/30 hover:bg-red-900/50 text-red-300 text-sm font-medium py-2 rounded-lg transition-colors mt-6"
                        >
                            {t('reportAd')}
                        </button>
                    </div>
                </div>
            </div>
        </div>

        {listing && categoryInfo && (
            <div className="border-t border-gray-800 mt-8">
                <ListingCarousel
                    title={t('relatedListings')}
                    filters={{ category: listing.category }}
                    onViewAllClick={handleViewAllRelated}
                    excludeId={listing.id}
                />
            </div>
        )}

        {isLightboxOpen && (
            <div 
                className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center animate-fade-in"
                onClick={closeLightbox}
            >
                <button onClick={(e) => { e.stopPropagation(); closeLightbox(); }} className="absolute top-4 end-4 text-white text-4xl hover:text-gray-300 z-10">&times;</button>
                <button onClick={(e) => { e.stopPropagation(); prevImage(); }} className="absolute start-4 top-1/2 -translate-y-1/2 p-2 bg-white/20 rounded-full text-white hover:bg-white/40 z-10">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
                </button>
                <button onClick={(e) => { e.stopPropagation(); nextImage(); }} className="absolute end-4 top-1/2 -translate-y-1/2 p-2 bg-white/20 rounded-full text-white hover:bg-white/40 z-10">
                    <svg className="w-8 h-8 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
                </button>
                
                {(areLightboxImagesLoading || !watermarkedLightboxImages[currentLightboxIndex]) ? (
                    <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-white"></div>
                ) : (
                    <img 
                        src={watermarkedLightboxImages[currentLightboxIndex] || ''} 
                        alt="Lightbox view"
                        className="max-w-[90vw] max-h-[90vh] object-contain transition-transform duration-300 animate-zoom-in"
                        onClick={(e) => e.stopPropagation()}
                    />
                )}

                <style>{`
                    @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
                    .animate-fade-in { animation: fade-in 0.3s ease-out; }
                    @keyframes zoom-in { from { transform: scale(0.9); } to { transform: scale(1); } }
                    .animate-zoom-in { animation: zoom-in 0.3s ease-out; }
                `}</style>
            </div>
        )}
        
        {listing && (
             <ChatModal
                isOpen={isChatModalOpen}
                onClose={() => setIsChatModalOpen(false)}
                seller={listing.user}
            />
        )}
        
        {listing?.donationInfo && (
            <DonationModal
                isOpen={isDonationModalOpen}
                onClose={() => setIsDonationModalOpen(false)}
                donationInfo={listing.donationInfo}
                listingTitle={listing.title}
            />
        )}
        <Toast 
            message={t('messageSentSuccess')}
            show={showToast}
            onClose={() => setShowToast(false)}
        />
        {listing && (
            <VirtualShowroomModal
                isOpen={isVsModalOpen}
                onClose={() => setIsVsModalOpen(false)}
                productImageUrl={listing.imageUrl}
                productTitle={listing.title}
            />
        )}
        </>
    );
};

export default ListingDetailsPage;