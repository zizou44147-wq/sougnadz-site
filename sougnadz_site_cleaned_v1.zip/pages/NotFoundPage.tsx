import React from 'react';
import { Link } from 'react-router-dom';
import { useLocalization } from '../hooks/useLocalization';

const NotFoundPage: React.FC = () => {
    const { t } = useLocalization();

    return (
        <div className="flex flex-col items-center justify-center text-center py-20 min-h-[60vh]">
            <h1 className="text-6xl font-black text-blue-500">404</h1>
            <h2 className="text-3xl font-bold text-gray-100 mt-4">{t('pageNotFoundTitle')}</h2>
            <p className="text-gray-400 mt-2 max-w-sm">{t('pageNotFoundMessage')}</p>
            <Link 
                to="/"
                className="mt-8 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg"
            >
                {t('home')}
            </Link>
        </div>
    );
};

export default NotFoundPage;