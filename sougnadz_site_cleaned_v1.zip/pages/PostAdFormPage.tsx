import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { CATEGORIES, Category } from '../constants/categories';
import { WILAYAS } from '../constants/geodata';
import { CAR_DATA } from '../constants/carData';
import { Commune, Listing } from '../services/types';
import AutomobileListingCard from '../components/AutomobileListingCard';
import ListingCard from '../components/ListingCard';
import { MOCK_LISTINGS } from '../constants/mockData';
import CloseIcon from '../components/icons/CloseIcon';
import WhatsAppIcon from '../components/icons/WhatsAppIcon';
import FacebookIcon from '../components/icons/FacebookIcon';
import TwitterIcon from '../components/icons/TwitterIcon';

// --- LIVE PREVIEW COMPONENT ---
const AdPreviewCard: React.FC<{
    formData: any;
    mainImage: string | null;
    category?: Category;
}> = ({ formData, mainImage, category }) => {
    const { t } = useLocalization();

    const generatedTitle = useMemo(() => {
        const title = [formData.marque, formData.modele, formData.annee].filter(Boolean).join(' ');
        return title || t('adTitle');
    }, [formData.marque, formData.modele, formData.annee, t]);

    const mockListing: Listing = useMemo(() => ({
        id: 999,
        title: generatedTitle,
        category: category?.apiName || t('filterCategory'),
        price: formData.price ? `${Number(formData.price).toLocaleString()} DA` : t('filterPrice'),
        priceValue: Number(formData.price) || 0,
        imageUrl: mainImage || 'https://via.placeholder.com/800x600/1e293b/475569?text=Image',
        location: formData.wilaya || t('filterWilaya'),
        commune: formData.commune,
        user: { name: 'Vous', avatarUrl: 'https://i.pravatar.cc/150?u=currentuser', isOnline: true, quickReply: true, rating: 5 },
        meta: {
            brand: formData.marque,
            model: formData.modele,
            engine: formData.engine,
            year: formData.annee ? Number(formData.annee) : undefined,
            km: formData.kilometrage ? Number(formData.kilometrage) : undefined,
            fuel: formData.energie as any,
            transmission: formData.boite as any,
            papers: formData.papiers as any,
            priceType: formData.priceType as any,
            exchange: formData.echange as any,
            state: formData.etat as any,
            sellerType: formData.sellerType as any,
        },
        contact: { phone: '' },
        createdAt: new Date().toISOString(),
    }), [formData, mainImage, category, t, generatedTitle]);

    if (category?.apiName === 'Automobiles & Véhicules') {
        return <AutomobileListingCard listing={mockListing} />;
    }
    return <ListingCard listing={mockListing} />;
};

// --- CONFIRMATION MODAL ---
const ConfirmationModal: React.FC<{ isOpen: boolean; onClose: () => void; onConfirm: () => void; ad: Listing | null; itemType: string }> = ({ isOpen, onClose, onConfirm, ad, itemType }) => {
    const { t } = useLocalization();
    if (!isOpen || !ad) return null;
    
    return (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-slate-800 rounded-2xl shadow-xl w-full max-w-lg m-4 transform transition-all duration-300 scale-95 animate-modal-pop text-center p-8" onClick={e => e.stopPropagation()}>
                <h2 className="text-2xl font-bold text-white mb-4">{t('confirmPublicationTitle')}</h2>
                <p className="text-slate-300 mb-6">{t('confirmPublicationBody', { item: itemType })}</p>

                <div className="text-left bg-slate-900/50 p-4 rounded-lg border border-slate-700 mb-6">
                    <p className="font-bold text-white">{ad.title}</p>
                    <p className="text-orange-400">{ad.price}</p>
                    <p className="text-slate-400 text-sm">{ad.location}, {ad.commune}</p>
                </div>
                
                <p className="text-slate-300 font-semibold mb-6">{t('confirmShareEncouragement')}</p>

                <div className="flex flex-col sm:flex-row gap-4">
                    <button onClick={onClose} className="w-full bg-slate-600 hover:bg-slate-700 text-white font-bold py-3 px-4 rounded-lg transition-colors">{t('cancel')}</button>
                    <button onClick={onConfirm} className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-4 rounded-lg transition-colors">{t('confirmButton')}</button>
                </div>
            </div>
        </div>
    )
}

// --- SUCCESS MODAL ---
const SuccessModal: React.FC<{ isOpen: boolean; onClose: () => void; ad: Listing | null }> = ({ isOpen, onClose, ad }) => {
    const { t } = useLocalization();
    const TOTAL_TIME = 300; // 5 minutes
    const [timeLeft, setTimeLeft] = useState(TOTAL_TIME);

    useEffect(() => {
        if (isOpen) {
            setTimeLeft(TOTAL_TIME);
            const interval = setInterval(() => {
                setTimeLeft(prev => (prev > 0 ? prev - 1 : 0));
            }, 1000);
            return () => clearInterval(interval);
        }
    }, [isOpen]);

    if (!isOpen || !ad) return null;

    const adUrl = `${window.location.origin}/#/listing/${ad.id}`;
    const shareText = encodeURIComponent(`Découvrez mon annonce sur sougnadz.com: ${ad.title}`);

    return (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-slate-800 rounded-2xl shadow-xl w-full max-w-md m-4 transform transition-all duration-300 scale-95 animate-modal-pop text-center p-8" onClick={e => e.stopPropagation()}>
                <h2 className="text-2xl font-bold text-white mb-4">{t('publishSuccessTitle')}</h2>
                <p className="text-slate-300">{t('publishSuccessBody', { item: ad.category.toLowerCase().includes('auto') ? 'voiture' : 'produit', title: ad.title })}</p>
                <div className="my-6">
                    <p className="text-5xl font-mono font-bold text-orange-500">{`${Math.floor(timeLeft / 60)}:${(timeLeft % 60).toString().padStart(2, '0')}`}</p>
                </div>
                <p className="text-slate-300 font-semibold mb-4">{t('publishSuccessShare')}</p>
                <div className="flex justify-center gap-4">
                    <a href={`https://www.facebook.com/sharer/sharer.php?u=${adUrl}`} target="_blank" rel="noopener noreferrer" className="p-3 bg-blue-600 rounded-full hover:bg-blue-700 transition"><FacebookIcon className="w-6 h-6"/></a>
                    <a href={`https://twitter.com/intent/tweet?url=${adUrl}&text=${shareText}`} target="_blank" rel="noopener noreferrer" className="p-3 bg-sky-500 rounded-full hover:bg-sky-600 transition"><TwitterIcon className="w-6 h-6"/></a>
                    <a href={`https://api.whatsapp.com/send?text=${shareText}%20${adUrl}`} target="_blank" rel="noopener noreferrer" className="p-3 bg-green-500 rounded-full hover:bg-green-600 transition"><WhatsAppIcon className="w-6 h-6"/></a>
                </div>
                 <button onClick={onClose} className="mt-8 w-full bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-4 rounded-lg transition-colors">{t('close')}</button>
            </div>
        </div>
    );
};


const PostAdFormPage: React.FC = () => {
    const navigate = useNavigate();
    const { categorySlug } = useParams<{ categorySlug: string }>();
    const { t } = useLocalization();

    const [formData, setFormData] = useState<any>({});
    const [communes, setCommunes] = useState<Commune[]>([]);
    
    const [imagePreviews, setImagePreviews] = useState<string[]>([]);
    const [imageFiles, setImageFiles] = useState<File[]>([]);
    const [mainImageIndex, setMainImageIndex] = useState(0);
    const MAX_IMAGES = 5;
    
    const [formError, setFormError] = useState<string | null>(null);
    const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
    const [isConfirmationModalOpen, setIsConfirmationModalOpen] = useState(false);
    const [publishedAd, setPublishedAd] = useState<Listing | null>(null);
    const [adForConfirmation, setAdForConfirmation] = useState<Listing | null>(null);

    const category = useMemo(() =>
        CATEGORIES.find(c => c.slug === categorySlug), [categorySlug]
    );

    const carBrands = useMemo(() => CAR_DATA.map(c => c.brand).sort((a, b) => a.localeCompare(b)), []);
    const carModels = useMemo(() => {
        if (formData.marque) {
            return CAR_DATA.find(c => c.brand === formData.marque)?.models.map(m => m.name) || [];
        }
        return [];
    }, [formData.marque]);
    
    const availableEngines = useMemo(() => {
        if (formData.marque && formData.modele) {
            return CAR_DATA.find(c => c.brand === formData.marque)
                           ?.models.find(m => m.name === formData.modele)
                           ?.engines || [];
        }
        return [];
    }, [formData.marque, formData.modele]);


    useEffect(() => {
        if (formData.wilaya) {
            const wilayaData = WILAYAS.find(w => w.name === formData.wilaya);
            setCommunes(wilayaData ? wilayaData.communes : []);
            setFormData(prev => ({ ...prev, commune: '' }));
        } else {
            setCommunes([]);
        }
    }, [formData.wilaya]);

    useEffect(() => {
        return () => { imagePreviews.forEach(url => URL.revokeObjectURL(url)); };
    }, [imagePreviews]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        
        if (type === 'checkbox') {
             const { checked } = e.target as HTMLInputElement;
             const currentValues = (formData[name] as string[] || []);
             const newValues = checked
                ? [...currentValues, value]
                : currentValues.filter(v => v !== value);
            setFormData((prev: any) => ({ ...prev, [name]: newValues }));
        } else {
            setFormData((prev: any) => ({ ...prev, [name]: value }));
        }
    };

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const files = Array.from(e.target.files).slice(0, MAX_IMAGES - imagePreviews.length);
            if (files.length === 0) return;
            const newPreviews = files.map(file => URL.createObjectURL(file as Blob));
            const updatedPreviews = [...imagePreviews, ...newPreviews];
            setImagePreviews(updatedPreviews);
            setImageFiles(prev => [...prev, ...files]);
            // Set the last added image as the main one
            setMainImageIndex(updatedPreviews.length - 1); 
            e.target.value = ''; // Reset input
        }
    };

    const handleRemoveImage = (indexToRemove: number) => {
        URL.revokeObjectURL(imagePreviews[indexToRemove]);
        const newPreviews = imagePreviews.filter((_, i) => i !== indexToRemove);
        const newFiles = imageFiles.filter((_, i) => i !== indexToRemove);
        setImagePreviews(newPreviews);
        setImageFiles(newFiles);
        
        if (mainImageIndex === indexToRemove) {
            setMainImageIndex(newFiles.length > 0 ? newFiles.length - 1 : 0);
        } else if (mainImageIndex > indexToRemove) {
            setMainImageIndex(prev => prev - 1);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setFormError(null);

        const requiredFields = ['marque', 'modele', 'annee', 'kilometrage', 'energie', 'boite', 'price', 'priceType', 'wilaya', 'commune', 'phone1'];
        if (category?.slug !== 'marche-des-vehicules-et-autos') {
            requiredFields.splice(0, 6, 'title');
        }

        const missingField = requiredFields.find(field => !formData[field] || formData[field].length === 0);

        if (missingField || imageFiles.length === 0) {
            setFormError(`Veuillez remplir tous les champs obligatoires. Le champ manquant est: ${missingField || 'photos'}`);
            window.scrollTo(0, 0);
            return;
        }
        
        const generatedTitle = [formData.marque, formData.modele, formData.annee].filter(Boolean).join(' ');

        const newAd: Listing = {
            id: Date.now(),
            title: generatedTitle,
            category: category!.apiName,
            price: `${Number(formData.price).toLocaleString()} DA`,
            priceValue: Number(formData.price),
            imageUrl: imagePreviews[mainImageIndex],
            images: imagePreviews,
            description: formData.description,
            location: formData.wilaya!,
            commune: formData.commune,
            user: { name: 'Vous', avatarUrl: 'https://i.pravatar.cc/150?u=currentuser', isOnline: true },
            meta: { ...formData, title: generatedTitle },
            contact: { phone: formData.phone1, phone2: formData.phone2, whatsapp: formData.whatsapp },
            createdAt: new Date().toISOString(),
        };

        setAdForConfirmation(newAd);
        setIsConfirmationModalOpen(true);
    };

    const handleConfirmPublication = () => {
        if (!adForConfirmation) return;
        MOCK_LISTINGS.unshift(adForConfirmation);
        setPublishedAd(adForConfirmation);
        setIsConfirmationModalOpen(false);
        setIsSuccessModalOpen(true);
    };

    const handleCloseSuccessModal = () => {
        setIsSuccessModalOpen(false);
        setPublishedAd(null);
        navigate('/');
    };

    if (!category) {
        return (
            <div className="text-center py-20 text-white">
                <h1 className="text-2xl">Catégorie non trouvée</h1>
                <Link to="/post-ad" className="text-blue-400 hover:underline mt-4 inline-block">{t('backToCategories')}</Link>
            </div>
        );
    }
    
    const itemType = category.apiName.toLowerCase().includes('auto') ? 'voiture' : 'produit';

    return (
        <div className="bg-slate-900 text-white min-h-screen py-10">
            <form onSubmit={handleSubmit} className="container mx-auto px-4">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* --- Left Column: Form Fields --- */}
                    <div className="lg:col-span-2 space-y-8">
                        <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700">
                             <h2 className="text-2xl font-bold mb-1">{t('postAdFormHeader')}</h2>
                             <p className="text-slate-400 mb-6">{t('postAdFormSubheader')}</p>
                        </div>

                        {formError && <div className="bg-red-900/50 border border-red-700 text-red-300 p-4 rounded-lg">{formError}</div>}
                        
                        {/* --- DÉTAILS DE L'ANNONCE --- */}
                        <section className="bg-slate-800 p-6 rounded-2xl border border-slate-700">
                            <h2 className="text-2xl font-bold mb-6">{t('adDetailsSection')}</h2>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                
                                {category.slug === 'marche-des-vehicules-et-autos' ? (
                                    <>
                                        <div><label htmlFor="marque" className="block text-sm font-bold text-slate-300 mb-1">{t('filterBrand')} <span className="text-red-500">*</span></label><select name="marque" value={formData.marque || ''} onChange={handleInputChange} required className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3"><option value="">-- {t('filterBrand')} --</option>{carBrands.map(b => <option key={b} value={b}>{b}</option>)}</select></div>
                                        <div><label htmlFor="modele" className="block text-sm font-bold text-slate-300 mb-1">{t('filterModel')} <span className="text-red-500">*</span></label><select name="modele" value={formData.modele || ''} onChange={handleInputChange} required disabled={!formData.marque} className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3 disabled:opacity-50"><option value="">-- {t('filterModel')} --</option>{carModels.map(m => <option key={m} value={m}>{m}</option>)}</select></div>
                                        <div><label htmlFor="annee" className="block text-sm font-bold text-slate-300 mb-1">{t('filterYear')} <span className="text-red-500">*</span></label><input type="number" name="annee" id="annee" value={formData.annee || ''} onChange={handleInputChange} required className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3" /></div>
                                        <div><label htmlFor="kilometrage" className="block text-sm font-bold text-slate-300 mb-1">{t('filterKm')} <span className="text-red-500">*</span></label><input type="number" name="kilometrage" id="kilometrage" value={formData.kilometrage || ''} onChange={handleInputChange} required className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3" /></div>
                                        <div className="md:col-span-2"><label htmlFor="engine" className="block text-sm font-bold text-slate-300 mb-1">{t('engine')} <span className="text-red-500">*</span></label><select name="engine" value={formData.engine || ''} onChange={handleInputChange} required disabled={!formData.modele} className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3 disabled:opacity-50"><option value="">-- {t('selectEngine')} --</option>{availableEngines.map(e => <option key={e} value={e}>{e}</option>)}</select></div>
                                        <div className="md:col-span-2"><label className="block text-sm font-bold text-slate-300 mb-2">{t('filterFuel')} <span className="text-red-500">*</span></label><div className="flex flex-wrap gap-x-6 gap-y-2">{['essence', 'diesel', 'gpl', 'hybride', 'electrique', 'autre'].map(fuel => <label key={fuel} className="flex items-center gap-2 cursor-pointer"><input type="radio" name="energie" value={fuel} checked={formData.energie === fuel} onChange={handleInputChange} required className="w-4 h-4 text-blue-600 bg-slate-700 border-slate-600 focus:ring-blue-500"/>{t(`fuel${fuel.charAt(0).toUpperCase() + fuel.slice(1)}` as TranslationKey)}</label>)}</div></div>
                                        <div className="md:col-span-2"><label className="block text-sm font-bold text-slate-300 mb-2">{t('filterTransmission')} <span className="text-red-500">*</span></label><div className="flex flex-wrap gap-x-6 gap-y-2">{['manuelle', 'automatique', 'semi_automatique'].map(boite => <label key={boite} className="flex items-center gap-2 cursor-pointer"><input type="radio" name="boite" value={boite} checked={formData.boite === boite} onChange={handleInputChange} required className="w-4 h-4 text-blue-600 bg-slate-700 border-slate-600 focus:ring-blue-500"/>{t(`gearbox${boite.charAt(0).toUpperCase() + boite.slice(1).replace('_', '')}` as TranslationKey)}</label>)}</div></div>
                                        <div className="md:col-span-2"><label className="block text-sm font-bold text-slate-300 mb-2">{t('filterPapers')}</label><div className="flex flex-wrap gap-x-6 gap-y-2">{['carte_grise_safia', 'licence_delai'].map(paper => <label key={paper} className="flex items-center gap-2 cursor-pointer"><input type="checkbox" name="papiers" value={paper} checked={formData.papiers?.includes(paper)} onChange={handleInputChange} className="w-4 h-4 rounded text-blue-600 bg-slate-700 border-slate-600 focus:ring-blue-500"/>{t(paper === 'carte_grise_safia' ? 'papersCard' : 'papersLicense')}</label>)}</div></div>
                                    </>
                                ) : ( // Fallback for other categories
                                    <div className="md:col-span-2">
                                        <label htmlFor="title" className="block text-sm font-bold text-slate-300 mb-1">{t('adTitle')} <span className="text-red-500">*</span></label>
                                        <input type="text" name="title" id="title" value={formData.title || ''} onChange={handleInputChange} required className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500" />
                                    </div>
                                )}

                                <div className="md:col-span-2"><label htmlFor="price" className="block text-sm font-bold text-slate-300 mb-1">{t('adPrice')} (DA) <span className="text-red-500">*</span></label><input type="number" name="price" id="price" value={formData.price || ''} onChange={handleInputChange} required className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3" /></div>
                                
                                <div className="md:col-span-2">
                                    <label className="block text-sm font-bold text-slate-300 mb-2">{t('priceTypeLabel')} <span className="text-red-500">*</span></label>
                                    <div className="flex flex-wrap gap-x-6 gap-y-2">
                                        <label className="flex items-center gap-2 cursor-pointer"><input type="radio" name="priceType" value="fixe" checked={formData.priceType === 'fixe'} onChange={handleInputChange} required className="w-4 h-4 text-blue-600 bg-slate-700 border-slate-600 focus:ring-blue-500"/>{t('priceFixe')}</label>
                                        <label className="flex items-center gap-2 cursor-pointer"><input type="radio" name="priceType" value="negociable" checked={formData.priceType === 'negociable'} onChange={handleInputChange} required className="w-4 h-4 text-blue-600 bg-slate-700 border-slate-600 focus:ring-blue-500"/>{t('priceNegociable')}</label>
                                        <label className="flex items-center gap-2 cursor-pointer"><input type="radio" name="priceType" value="offre" checked={formData.priceType === 'offre'} onChange={handleInputChange} required className="w-4 h-4 text-blue-600 bg-slate-700 border-slate-600 focus:ring-blue-500"/>{t('priceOffre')}</label>
                                    </div>
                                </div>
                                
                                <div className="md:col-span-2"><label htmlFor="description" className="block text-sm font-bold text-slate-300 mb-1">{t('descriptionSection')}</label><textarea name="description" id="description" value={formData.description || ''} onChange={handleInputChange} rows={6} placeholder={t('tellUsAboutItemHelper')} className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3" /></div>
                                
                                <div className="md:col-span-2"><label className="block text-sm font-bold text-slate-300 mb-1">{t('locationSection')} <span className="text-red-500">*</span></label><div className="mt-1 grid grid-cols-1 md:grid-cols-2 gap-4"><select name="wilaya" value={formData.wilaya || ''} onChange={handleInputChange} required className="block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3"><option value="">-- {t('filterWilaya')} --</option>{WILAYAS.map(w => <option key={w.code} value={w.name}>{`${w.code} - ${w.name}`}</option>)}</select><select name="commune" value={formData.commune || ''} onChange={handleInputChange} required disabled={!formData.wilaya} className="block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3 disabled:opacity-50"><option value="">-- {t('selectCommune')} --</option>{communes.map(c => <option key={c.code} value={c.name}>{`${c.code} - ${c.name}`}</option>)}</select></div></div>

                            </div>
                        </section>

                        {/* --- CONTACT & PHOTOS --- */}
                        <section className="bg-slate-800 p-6 rounded-2xl border border-slate-700">
                             <h2 className="text-2xl font-bold mb-6">{t('contactInfoSection')} & {t('photosSection')}</h2>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div><label htmlFor="phone1" className="block text-sm font-bold text-slate-300 mb-1">{t('phone1Label')} <span className="text-red-500">*</span></label><input type="tel" name="phone1" id="phone1" value={formData.phone1 || ''} onChange={handleInputChange} required className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3" /></div>
                                <div><label htmlFor="phone2" className="block text-sm font-bold text-slate-300 mb-1">{t('phone2Label')}</label><input type="tel" name="phone2" id="phone2" value={formData.phone2 || ''} onChange={handleInputChange} className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3" /></div>
                                <div className="md:col-span-2 relative"><label htmlFor="whatsapp" className="block text-sm font-bold text-slate-300 mb-1">{t('whatsappLabel')}</label><div className="relative"><span className="absolute inset-y-0 left-0 flex items-center pl-3"><WhatsAppIcon className="w-5 h-5 text-green-400"/></span><input type="tel" name="whatsapp" id="whatsapp" value={formData.whatsapp || ''} onChange={handleInputChange} className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md py-2 px-3 pl-10" /></div></div>
                                
                                <div className="md:col-span-2">
                                    <label className="block text-sm font-bold text-slate-300 mb-1">{t('photosSection')} <span className="text-red-500">*</span></label>
                                    <p className="text-xs text-slate-400 mb-2">{t('photosSubheader')}</p>
                                    <div className="mt-2 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
                                        {imagePreviews.map((preview, index) => (
                                            <div key={index} onClick={() => setMainImageIndex(index)} className="relative aspect-square rounded-md overflow-hidden border-2 group cursor-pointer transition-all" style={{borderColor: mainImageIndex === index ? '#3b82f6' : '#334155'}}>
                                                <img src={preview} alt={`Preview ${index + 1}`} className="w-full h-full object-cover" />
                                                <button type="button" onClick={(e) => { e.stopPropagation(); handleRemoveImage(index); }} className="absolute top-1 right-1 text-white bg-red-600/80 rounded-full p-1 opacity-0 group-hover:opacity-100 transition"><CloseIcon className="w-4 h-4" /></button>
                                                {mainImageIndex === index && <div className="absolute bottom-0 left-0 right-0 bg-blue-600/80 text-white text-xs text-center py-0.5 font-bold">{t('mainImageTag')}</div>}
                                            </div>
                                        ))}
                                        {imagePreviews.length < MAX_IMAGES && ( <label htmlFor="file-upload" className="cursor-pointer aspect-square flex flex-col justify-center items-center p-2 border-2 border-slate-700 border-dashed rounded-md hover:border-blue-500 transition"><svg className="mx-auto h-8 w-8 text-slate-500" stroke="currentColor" fill="none" viewBox="0 0 48 48"><path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg><span className="mt-1 text-xs text-slate-400 text-center">{t('adUpload')}</span></label>)}
                                    </div>
                                    <input id="file-upload" name="file-upload" type="file" className="sr-only" multiple accept="image/*" onChange={handleImageChange} />
                                </div>
                            </div>
                        </section>
                        
                        <button type="submit" className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-4 px-4 rounded-lg text-xl transition-transform transform hover:scale-105 disabled:bg-orange-400 disabled:cursor-not-allowed">
                            {t('publishAdButton', { item: itemType })}
                        </button>
                    </div>

                    {/* --- Right Column: Live Preview --- */}
                    <div className="lg:col-span-1">
                        <div className="sticky top-24 space-y-6">
                            <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700">
                                <h3 className="text-xl font-bold mb-4 text-center">Aperçu de l'annonce</h3>
                                <div className="pointer-events-none">
                                    <AdPreviewCard formData={formData} mainImage={imagePreviews[mainImageIndex] || null} category={category} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <ConfirmationModal isOpen={isConfirmationModalOpen} onClose={() => setIsConfirmationModalOpen(false)} onConfirm={handleConfirmPublication} ad={adForConfirmation} itemType={itemType} />
            <SuccessModal isOpen={isSuccessModalOpen} onClose={handleCloseSuccessModal} ad={publishedAd} />
            <style>{`
                @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
                .animate-fade-in { animation: fade-in 0.3s ease-out; }
                @keyframes modal-pop { from { transform: scale(0.9); } to { transform: scale(1); } }
                .animate-modal-pop { animation: modal-pop 0.3s ease-out; }
            `}</style>
        </div>
    );
};

export default PostAdFormPage;