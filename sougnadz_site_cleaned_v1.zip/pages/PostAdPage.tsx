import React from 'react';
import { Link } from 'react-router-dom';
import { useLocalization } from '../hooks/useLocalization';
import { CATEGORIES } from '../constants/categories';
import NavbarLogo from '../components/NavbarLogo';

const PostAdPage: React.FC = () => {
    const { t } = useLocalization();

    return (
        <div className="bg-slate-900 min-h-screen py-10 px-4">
            <div className="container mx-auto text-center">
                <h1 className="text-3xl md:text-4xl font-extrabold text-white mb-2" dir={t('home') === 'الرئيسية' ? 'rtl' : 'ltr'}>
                    {t('postAdTitle')} <NavbarLogo className="text-4xl md:text-5xl inline-block" />
                </h1>
                <p className="text-slate-400 max-w-2xl mx-auto mb-10">{t('postAdSubtitle')}</p>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
                    {CATEGORIES.map(cat => (
                        <Link
                            to={`/post-ad/${cat.slug}`}
                            key={cat.slug}
                            className={`group relative aspect-[4/5] flex flex-col items-center justify-center p-4 rounded-2xl text-white font-bold text-center transition-all duration-300 transform hover:scale-105 hover:shadow-2xl bg-gradient-to-br ${cat.color}`}
                        >
                            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors rounded-2xl"></div>
                            <div className="relative z-10">
                                {/* Placeholder for potential future icon */}
                                <div className="mb-2 text-3xl">
                                    {cat.slug.startsWith('marche-des-vehicules') ? '🚗' : cat.slug.startsWith('marche-immobilier') ? '🏠' : '📦'}
                                </div>
                                <span className="text-base md:text-lg">{t(cat.labelKey)}</span>
                            </div>
                        </Link>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default PostAdPage;
