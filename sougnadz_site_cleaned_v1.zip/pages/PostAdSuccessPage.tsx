/*
  This page is deprecated. The success notification is now handled
  by a modal within the PostAdFormPage itself, providing a more
  modern and integrated user experience as per the user's request.
*/
import React from 'react';
import { Navigate } from 'react-router-dom';

const PostAdSuccessPage: React.FC = () => {
    // Redirect to home as this page is no longer in use.
    return <Navigate to="/" replace />;
};

export default PostAdSuccessPage;
