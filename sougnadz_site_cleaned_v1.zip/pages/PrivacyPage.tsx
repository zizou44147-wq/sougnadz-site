import React, { useEffect } from 'react';
import { useLocalization } from '../hooks/useLocalization';

const PrivacyPage: React.FC = () => {
    const { t } = useLocalization();
    
    useEffect(() => {
        const scriptId = 'page-structured-data';
        document.getElementById(scriptId)?.remove();

        const script = document.createElement('script');
        script.id = scriptId;
        script.type = 'application/ld+json';
        const structuredData = {
            '@context': 'https://schema.org',
            '@type': 'WebPage',
            'name': t('privacyPolicy'),
            'description': 'Our privacy policy explains how we collect, use, and protect your personal information on sougnadz.com.',
            'url': window.location.href,
            'dateModified': new Date().toISOString()
        };
        script.textContent = JSON.stringify(structuredData);
        document.head.appendChild(script);

        return () => {
            document.getElementById(scriptId)?.remove();
        };
    }, [t]);

    const Section: React.FC<{title: string, children: React.ReactNode}> = ({ title, children }) => (
        <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{title}</h2>
            <div className="space-y-4 text-gray-600 dark:text-gray-300">{children}</div>
        </div>
    );
    return (
        <div className="bg-white dark:bg-slate-900 py-12">
            <div className="container mx-auto px-4">
                <div className="max-w-4xl mx-auto">
                    <h1 className="text-4xl font-extrabold text-gray-900 dark:text-white mb-8 border-b pb-4 dark:border-slate-700">{t('privacyPolicy')}</h1>
                    
                    <Section title={`1. ${t('privacyP1Title')}`}>
                        <p>{t('privacyP1Text')}</p>
                    </Section>
                    
                    <Section title={`2. ${t('privacyP2Title')}`}>
                        <p>{t('privacyP2Text1')}</p>
                        <ul className="list-disc list-inside space-y-2">
                            <li>{t('privacyP2Li1')}</li>
                            <li>{t('privacyP2Li2')}</li>
                        </ul>
                        <p>{t('privacyP2Text2')}</p>
                    </Section>
                    
                    <Section title={`3. ${t('privacyP3Title')}`}>
                        <p>{t('privacyP3Text1')}</p>
                        <ul className="list-disc list-inside space-y-2">
                            <li>{t('privacyP3Li1')}</li>
                            <li>{t('privacyP3Li2')}</li>
                            <li>{t('privacyP3Li3')}</li>
                        </ul>
                    </Section>

                    <Section title={`4. ${t('privacyP4Title')}`}>
                        <p>{t('privacyP4Text')}</p>
                    </Section>

                    <Section title={`5. ${t('privacyP5Title')}`}>
                        <p>{t('privacyP5Text')}</p>
                    </Section>

                    <Section title={`6. ${t('privacyP6Title')}`}>
                        <p>{t('privacyP6Text')}</p>
                    </Section>
                </div>
            </div>
        </div>
    );
};

export default PrivacyPage;