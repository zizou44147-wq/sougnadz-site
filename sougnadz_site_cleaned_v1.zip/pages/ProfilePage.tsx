import React, { useState, useEffect } from 'react';
import { useLocalization } from '../hooks/useLocalization';
import Toast from '../components/Toast';

const NotificationPreferences: React.FC = () => {
    const { t } = useLocalization();
    const [isEnabled, setIsEnabled] = useState(false);
    const [topics, setTopics] = useState<string[]>([]);

    useEffect(() => {
        const preference = localStorage.getItem('notificationPreference') === 'true';
        setIsEnabled(preference);
        if (preference) {
            const savedTopics = JSON.parse(localStorage.getItem('notificationTopics') || '[]');
            setTopics(savedTopics);
        }
    }, []);

    const handleToggle = () => {
        const newIsEnabled = !isEnabled;
        setIsEnabled(newIsEnabled);
        localStorage.setItem('notificationPreference', String(newIsEnabled));
    };

    return (
        <div className="mt-8">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">{t('myNotificationPreferences')}</h3>
            <div className="bg-white dark:bg-slate-800 p-6 rounded-lg border border-gray-200 dark:border-slate-700">
                <div className="flex items-center justify-between">
                    <span className="font-medium text-gray-700 dark:text-gray-300">{t('notificationsStatus')}</span>
                    <div className="flex items-center gap-4">
                        <span className={`text-sm font-semibold ${isEnabled ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                            {isEnabled ? t('notificationsEnabled') : t('notificationsDisabled')}
                        </span>
                        <button
                            onClick={handleToggle}
                            className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${isEnabled ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-600'}`}
                            role="switch"
                            aria-checked={isEnabled}
                        >
                            <span
                                className={`inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${isEnabled ? 'translate-x-5' : 'translate-x-0'}`}
                            />
                        </button>
                    </div>
                </div>
                {isEnabled && (
                    <div className="mt-4 border-t border-gray-200 dark:border-slate-700 pt-4">
                        <h4 className="font-medium text-gray-700 dark:text-gray-300">{t('notificationTopics')}</h4>
                        {topics.length > 0 ? (
                            <div className="mt-2 flex flex-wrap gap-2">
                                {topics.map(topic => (
                                    <span key={topic} className="inline-flex items-center rounded-full bg-blue-100 dark:bg-blue-900/50 px-3 py-1 text-sm font-medium text-blue-800 dark:text-blue-200">
                                        {topic}
                                    </span>
                                ))}
                            </div>
                        ) : (
                            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">{t('noTopicsYet')}</p>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

const ProfilePage: React.FC = () => {
    const { t } = useLocalization();
    const [user, setUser] = useState({
        name: 'Mock User',
        email: 'mock.user@example.com',
        phone: '',
        avatar: 'https://i.pravatar.cc/150?u=mockuser'
    });
    const [showSuccessToast, setShowSuccessToast] = useState(false);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setUser(prev => ({ ...prev, [name]: value }));
    };
    
    const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const reader = new FileReader();
            reader.onload = (event) => {
                setUser(prev => ({ ...prev, avatar: event.target?.result as string }));
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        console.log('Saving profile:', user);
        setShowSuccessToast(true);
    };

    return (
        <>
            <div className="bg-white dark:bg-gray-900 py-12">
                <div className="container mx-auto px-4">
                    <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-8 text-center">
                        {t('profilePageTitle')}
                    </h1>
                    <div className="max-w-2xl mx-auto">
                        <div className="bg-gray-50 dark:bg-slate-800/50 border border-gray-200 dark:border-slate-700/60 rounded-xl p-8 shadow-md">
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="flex flex-col items-center space-y-4">
                                    <div className="relative group">
                                        <img 
                                            src={user.avatar} 
                                            alt="User Avatar" 
                                            className="w-32 h-32 rounded-full object-cover border-4 border-white dark:border-slate-700 shadow-lg"
                                        />
                                        <label htmlFor="avatar-upload" className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center text-white font-bold opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                                            {t('profileChangeAvatar')}
                                        </label>
                                        <input 
                                            id="avatar-upload" 
                                            type="file" 
                                            className="hidden" 
                                            accept="image/*"
                                            onChange={handleAvatarChange}
                                        />
                                    </div>
                                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{user.name}</h2>
                                </div>
                                
                                <div>
                                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                        {t('profileFullName')}
                                    </label>
                                    <input
                                        type="text"
                                        id="name"
                                        name="name"
                                        value={user.name}
                                        onChange={handleInputChange}
                                        className="mt-1 block w-full bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    />
                                </div>

                                <div>
                                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                        {t('profileEmail')}
                                    </label>
                                    <input
                                        type="email"
                                        id="email"
                                        name="email"
                                        value={user.email}
                                        disabled
                                        className="mt-1 block w-full bg-gray-200 dark:bg-slate-700/50 border border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 text-gray-500 dark:text-gray-400 cursor-not-allowed"
                                    />
                                </div>
                                
                                <div>
                                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                        {t('profilePhoneNumber')}
                                    </label>
                                    <input
                                        type="tel"
                                        id="phone"
                                        name="phone"
                                        value={user.phone}
                                        onChange={handleInputChange}
                                        placeholder="05 XX XX XX XX"
                                        className="mt-1 block w-full bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-700 rounded-md shadow-sm py-2 px-3 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    />
                                </div>

                                <div className="pt-4">
                                    <button
                                        type="submit"
                                        className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg hover:shadow-blue-500/40 active:translate-y-0 active:scale-95"
                                    >
                                        {t('profileSaveChanges')}
                                    </button>
                                </div>
                            </form>
                        </div>
                        <NotificationPreferences />
                    </div>
                </div>
            </div>
            <Toast
                message={t('profileChangesSaved')}
                show={showSuccessToast}
                onClose={() => setShowSuccessToast(false)}
            />
        </>
    );
};

export default ProfilePage;