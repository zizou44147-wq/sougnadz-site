import React, { useState, useEffect, useCallback } from 'react';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { getSavedSearches, deleteSearch, updateSearch, fetchListings } from '../services/api';
import { SavedSearch, ListingFilters } from '../services/types';
import { useNavigate } from 'react-router-dom';

const SavedSearchesPage: React.FC = () => {
    const { t } = useLocalization();
    const navigate = useNavigate();
    const [searches, setSearches] = useState<SavedSearch[]>([]);
    const [loading, setLoading] = useState(true);

    const loadSearches = useCallback(async () => {
        setLoading(true);
        const savedSearches = getSavedSearches();

        const updatedSearches = await Promise.all(savedSearches.map(async (search) => {
            const searchParams = new URLSearchParams(search.params);
            const filters: ListingFilters = {};
            for (const [key, value] of searchParams.entries()) {
                filters[key] = value.split(',');
            }
            filters.dateFrom = search.lastChecked;
            filters.dateRange = 'custom';
            
            const newResults = await fetchListings(filters);
            
            if (newResults.length > 0 && newResults.length !== search.newCount) {
              updateSearch(search.id, { newCount: newResults.length });
              return { ...search, newCount: newResults.length };
            }
            return search;
        }));

        setSearches(updatedSearches.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
        setLoading(false);
    }, []);

    useEffect(() => {
        loadSearches();
    }, [loadSearches]);

    const handleDelete = (id: string) => {
        deleteSearch(id);
        setSearches(prev => prev.filter(s => s.id !== id));
    };

    const handleSearchClick = (search: SavedSearch) => {
        updateSearch(search.id, { newCount: 0, lastChecked: new Date().toISOString() });
        navigate(`/category/all?${search.params}`);
    };
    
    const renderCriteria = (paramsString: string) => {
        const params = new URLSearchParams(paramsString);
        const criteria = [];
        if (params.get('query')) criteria.push(`"${params.get('query')}"`);
        if (params.get('wilaya')) criteria.push(params.get('wilaya'));
        if (params.get('priceMin')) criteria.push(`Min: ${params.get('priceMin')} DA`);
        if (params.get('priceMax')) criteria.push(`Max: ${params.get('priceMax')} DA`);
        
        return criteria.length > 0 ? criteria.slice(0, 3).join(' / ') : "Toutes les annonces";
    };

    return (
        <div className="container mx-auto px-4 py-8">
            <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-8">
                {t('savedSearches')}
            </h1>

            {loading && (
                <div className="space-y-4">
                    {Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg p-4 animate-pulse">
                            <div className="h-6 bg-gray-200 dark:bg-slate-700 rounded w-1/3 mb-2"></div>
                            <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded w-1/2"></div>
                        </div>
                    ))}
                </div>
            )}

            {!loading && searches.length === 0 && (
                <div className="text-center py-20 bg-gray-50 dark:bg-gray-900/30 rounded-lg">
                    <h3 className="text-2xl font-bold text-gray-800 dark:text-white">{t('noSavedSearches')}</h3>
                    <p className="mt-2 text-gray-500 dark:text-gray-400">
                        {t('noSavedSearchesDescription')}
                    </p>
                </div>
            )}

            {!loading && searches.length > 0 && (
                <div className="space-y-4">
                    {searches.map(search => (
                        <div key={search.id} className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg shadow-sm flex items-center justify-between p-4 gap-4 transition-all hover:shadow-md hover:border-blue-500/50">
                            <div className="flex-grow cursor-pointer" onClick={() => handleSearchClick(search)}>
                                <div className="flex items-center gap-3">
                                    <h2 className="text-lg font-bold text-gray-800 dark:text-white">{search.name}</h2>
                                    {search.newCount && search.newCount > 0 && (
                                        <span className="bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded-full animate-pulse">
                                            {search.newCount} {t('newResults')}
                                        </span>
                                    )}
                                </div>
                                <p className="text-sm text-gray-500 dark:text-gray-400 truncate">{renderCriteria(search.params)}</p>
                            </div>
                            <button 
                                onClick={() => handleDelete(search.id)}
                                className="p-2 text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50 rounded-full flex-shrink-0"
                                aria-label={t('deleteSearch')}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" />
                                </svg>
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default SavedSearchesPage;