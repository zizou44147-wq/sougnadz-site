import React, { useState, useCallback, useMemo } from 'react';
import { useLocalization, TranslationKey } from '../hooks/useLocalization';
import { ListingFilters } from '../services/types';
import { useNavigate } from 'react-router-dom';
import ListingCarousel from '../components/ListingCarousel';
import Guestbook from '../components/Guestbook';
import VisitedPreviously from '../components/VisitedPreviously';
import ForYouGrid from '../components/ForYouGrid';
import { CATEGORIES } from '../constants/categories';
import { EUROPE_COUNTRIES } from '../constants/geodata';
import MicIcon from '../components/icons/MicIcon';
import CameraIcon from '../components/icons/CameraIcon';


// A custom Hero Section for the Sougna Europe page
const EuropeHeroSection: React.FC<{ onSearch: (filters: ListingFilters) => void }> = ({ onSearch }) => {
    const { t, language } = useLocalization();
    const [query, setQuery] = useState('');
    const [country, setCountry] = useState('');

    const handleSearchClick = () => {
        onSearch({ geniusQuery: query, country, market: 'europe' });
    };

    const homeCategories = useMemo(() =>
        CATEGORIES.slice(0, 5).map(c => ({ slug: c.slug, labelKey: c.labelKey as TranslationKey }))
    , []);
    
    // --- Logo Style Replication ---
    const textShadow3d = (color: string, highlight: string, depth = 4) => {
        let shadow = [];
        for (let i = 1; i <= depth; i++) {
            shadow.push(`${i * 0.02}em ${i * 0.03}em 0 ${color}`);
        }
        shadow.push(`0.01em -0.01em 0 ${highlight}`);
        shadow.push(`0.12em 0.15em 0.1em rgba(0,0,0,0.3)`);
        return shadow.join(', ');
    };
    const orangeOutlineValue = '0.025em';
    const whiteOutlineValue = '0.028em';
    const thinOrangeOutline = `-${orangeOutlineValue} -${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8), ${orangeOutlineValue} -${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8), -${orangeOutlineValue} ${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8), ${orangeOutlineValue} ${orangeOutlineValue} 0 rgba(251, 146, 60, 0.8)`;
    const thinWhiteOutline = `-${whiteOutlineValue} -${whiteOutlineValue} 0 rgba(255,255,255,0.8), ${whiteOutlineValue} -${whiteOutlineValue} 0 rgba(255,255,255,0.8), -${whiteOutlineValue} ${whiteOutlineValue} 0 rgba(255,255,255,0.8), ${whiteOutlineValue} ${whiteOutlineValue} 0 rgba(255,255,255,0.8)`;
    const styles = {
        sougna: { color: '#0d244f', textShadow: `${thinOrangeOutline}, ${textShadow3d('#081630', '#3b61aa', 5)}` },
        europe: { color: '#f97316', textShadow: `${thinWhiteOutline}, ${textShadow3d('#c25a12', '#fdba74', 5)}` },
    };
    const [sougnaText, europeText] = t('sougnaEurope').split(' ');

    const logoContent = (
      <div className="relative inline-block font-nunito" style={{ fontWeight: 900, letterSpacing: '-0.02em' }}>
        <div className="absolute -bottom-[0.1em] left-[-0.15em] w-[4.8em] h-[0.8em] z-0">
          <svg viewBox="0 0 100 20" preserveAspectRatio="none" className="w-full h-full">
            <defs>
              <linearGradient id="swoosh3D_europe" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fb923c" />
                <stop offset="50%" stopColor="#f97316" />
                <stop offset="100%" stopColor="#ea580c" />
              </linearGradient>
            </defs>
            <path d="M 0,15 C 5,20 15,22 30,18 S 70,2 90,5 L 100,0 L 95,8 C 80,15 60,18 40,15 S 10,8 5,12 Z" fill="url(#swoosh3D_europe)" />
          </svg>
        </div>
        <div className="relative z-10 text-[1em]">
          <span style={styles.sougna}>{sougnaText}</span>
          <span style={{ ...styles.europe, marginLeft: '0.2em' }}>{europeText}</span>
        </div>
      </div>
    );
    // --- End Logo Style ---

    return (
        <div className="relative text-center pt-4 pb-2 sm:pt-6 sm:pb-3 overflow-hidden bg-gradient-to-b from-blue-900/30 to-black">
            <div className="container mx-auto px-4 relative z-10">
                <div className="max-w-4xl mx-auto">
                    <div className="mb-4 text-5xl sm:text-6xl animate-enter" style={{ animationDelay: '100ms' }}>
                        {logoContent}
                    </div>
                    <h1 className="text-4xl sm:text-5xl font-extrabold mt-2 text-white animate-enter" style={{ animationDelay: '250ms' }}>
                        {t('sougnaEuropeTitle')}
                    </h1>
                    <p className="mt-3 text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto animate-enter" style={{ animationDelay: '400ms' }}>
                        {t('sougnaEuropeSubtitle')}
                    </p>
                    <div className="mt-6 max-w-3xl mx-auto animate-enter" style={{ animationDelay: '700ms' }}>
                        <div className="flex flex-col sm:flex-row items-center gap-2 bg-slate-800 p-2 rounded-full backdrop-blur-sm border border-slate-700 shadow-lg">
                             <select value={country} onChange={(e) => setCountry(e.target.value)} className="bg-transparent text-white focus:outline-none p-3 rounded-full hover:bg-slate-700 appearance-none text-center">
                                <option value="" className="bg-slate-800">{t('allCountries')}</option>
                                {EUROPE_COUNTRIES.map(c => <option key={c} value={c} className="bg-slate-800">{c}</option>)}
                            </select>
                            <div className="h-6 w-px bg-slate-700 hidden sm:block"></div>
                            <div className="relative flex-grow w-full">
                                <input
                                    type="text"
                                    placeholder={t('searchPlaceholder')}
                                    value={query}
                                    onChange={(e) => setQuery(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSearchClick()}
                                    className="w-full bg-transparent text-white placeholder-gray-400 px-4 py-2 focus:outline-none"
                                />
                            </div>
                            <button onClick={handleSearchClick} className="w-full sm:w-auto flex-shrink-0 bg-blue-600 hover:bg-blue-700 text-white font-bold p-3 rounded-full transition-all duration-300 transform hover:-translate-y-0.5 hover:shadow-lg active:scale-95 flex items-center justify-center sm:w-12 sm:h-12">
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                                <span className="sm:hidden ml-2">{t('searchButton')}</span>
                            </button>
                        </div>
                        <div className="mt-4 grid grid-cols-3 sm:grid-cols-5 gap-1.5 max-w-3xl mx-auto">
                            {homeCategories.map(cat => (
                                <button key={cat.slug} className="category-fire-button w-full">{t(cat.labelKey)}</button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            <style>{`
                @keyframes enter-anim { from { opacity: 0; transform: translateY(20px); filter: blur(5px); } to { opacity: 1; transform: translateY(0); filter: blur(0); } }
                .animate-enter { animation: enter-anim 0.8s ease-out both; }
            `}</style>
        </div>
    );
};


const SougnaEuropePage: React.FC = () => {
    const { t } = useLocalization();
    const navigate = useNavigate();

    const handleSearch = useCallback((filters: ListingFilters) => {
        const searchParams = new URLSearchParams();
        Object.entries(filters).forEach(([key, value]) => {
            if (value) {
                searchParams.set(key, String(value));
            }
        });
        navigate(`/category/all?${searchParams.toString()}`);
    }, [navigate]);

    const handleCarouselClick = useCallback((slug: string) => {
        const params = new URLSearchParams();
        params.set('market', 'europe');
        navigate(`/category/${slug}?${params.toString()}`);
    }, [navigate]);

    return (
        <div className="bg-black">
            <EuropeHeroSection onSearch={handleSearch} />
            <Guestbook />
            <VisitedPreviously market="europe" />
            <ForYouGrid market="europe" />

            <ListingCarousel
                title={t('sougnaCatVoituresEurope')}
                filters={{ market: 'europe', category: 'Automobiles & Véhicules' }}
                onViewAllClick={() => handleCarouselClick('marche-des-vehicules-et-autos')}
            />
            <ListingCarousel
                title={t('sougnaCatHighTech')}
                filters={{ market: 'europe', category: 'Téléphones & Accessoires' }}
                onViewAllClick={() => handleCarouselClick('smartphones-neufs-occasion')}
            />
            <ListingCarousel
                title={t('sougnaCatMaisonMeubles')}
                filters={{ market: 'europe', category: 'Meubles & Maison' }}
                onViewAllClick={() => handleCarouselClick('decoration-meubles')}
            />
        </div>
    );
};

export default SougnaEuropePage;
