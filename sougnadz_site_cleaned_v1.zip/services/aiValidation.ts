import { GoogleGenAI } from "@google/genai";

const askGeminiSimpleValidation = async (prompt: string): Promise<boolean> => {
    try {
        if (!process.env.API_KEY) {
            console.warn("Gemini API key not set. Validation will be skipped.");
            return true; // In a dev environment without a key, bypass validation.
        }
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        const text = response.text.trim().toUpperCase();
        console.log(`Validation prompt: "${prompt}" -> AI Response: "${text}" -> Valid: ${text.includes('YES')}`);
        return text.includes('YES');
    } catch (error) {
        console.error("Gemini validation failed:", error);
        return false; // Fail safely in case of an API error
    }
};

export const validateCarBrand = async (brand: string): Promise<boolean> => {
    const prompt = `Is "${brand}" a real-world car manufacturing brand? Respond with only "YES" or "NO".`;
    return askGeminiSimpleValidation(prompt);
};

export const validateCarModel = async (brand: string, model: string): Promise<boolean> => {
    const prompt = `Is "${model}" a real car model produced by the brand "${brand}"? Respond with only "YES" or "NO".`;
    return askGeminiSimpleValidation(prompt);
};

export const validateCarEngine = async (engine: string): Promise<boolean> => {
    const prompt = `Is "${engine}" a plausible and correctly formatted name for a car engine (e.g., "1.6 TDI", "V6 3.0L", "2.0 TFSI")? It doesn't have to be from a specific brand, just a valid-looking engine name. Respond with only "YES" or "NO".`;
    return askGeminiSimpleValidation(prompt);
};
