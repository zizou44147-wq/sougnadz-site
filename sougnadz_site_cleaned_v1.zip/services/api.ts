import { GoogleGenAI, Type } from "@google/genai";
import { Listing, ListingFilters, SavedSearch } from './types';
import { MOCK_LISTINGS } from '../constants/mockData';

// This service is designed to be replaced with actual API calls.

// --- CACHING CITADEL: GHOST CACHE ---
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

interface CachedData {
    timestamp: number;
    data: Listing[];
}

const getCacheKey = (filters: ListingFilters, limit?: number, excludeId?: number): string => {
    // Create a stable key from the filter object
    const sortedFilters = Object.keys(filters).sort().reduce((acc, key) => {
        acc[key as keyof ListingFilters] = filters[key as keyof ListingFilters];
        return acc;
    }, {} as ListingFilters);
    return `listing_cache_${JSON.stringify(sortedFilters)}_${limit || ''}_${excludeId || ''}`;
};
// --- END CACHING CITADEL ---

// --- SAVED SEARCHES PERSISTENCE ---
const SAVED_SEARCHES_KEY = 'savedSearches';

export const getSavedSearches = (): SavedSearch[] => {
    try {
        const item = window.localStorage.getItem(SAVED_SEARCHES_KEY);
        return item ? JSON.parse(item) : [];
    } catch (error) {
        console.error("Error reading saved searches from localStorage", error);
        return [];
    }
};

const setSavedSearches = (searches: SavedSearch[]): void => {
    try {
        window.localStorage.setItem(SAVED_SEARCHES_KEY, JSON.stringify(searches));
    } catch (error) {
        console.error("Error writing saved searches to localStorage", error);
    }
};

export const saveSearch = (name: string, params: string): SavedSearch => {
    const searches = getSavedSearches();
    const now = new Date().toISOString();
    const newSearch: SavedSearch = {
        id: Date.now().toString(),
        name,
        params,
        createdAt: now,
        lastChecked: now,
        newCount: 0,
    };
    setSavedSearches([...searches, newSearch]);
    return newSearch;
};

export const deleteSearch = (id: string): void => {
    let searches = getSavedSearches();
    searches = searches.filter(search => search.id !== id);
    setSavedSearches(searches);
};

export const updateSearch = (id: string, updates: Partial<SavedSearch>): SavedSearch | undefined => {
    const searches = getSavedSearches();
    const searchIndex = searches.findIndex(s => s.id === id);
    if (searchIndex > -1) {
        searches[searchIndex] = { ...searches[searchIndex], ...updates };
        setSavedSearches(searches);
        return searches[searchIndex];
    }
    return undefined;
};

// --- FAVORITES PERSISTENCE (using localStorage) ---
const FAVORITES_KEY = 'favoriteListings';

const getFavoriteIds = (): number[] => {
    try {
        const item = window.localStorage.getItem(FAVORITES_KEY);
        return item ? JSON.parse(item) : [];
    } catch (error) {
        console.error("Error reading favorites from localStorage", error);
        return [];
    }
};

const setFavoriteIds = (ids: number[]): void => {
    try {
        window.localStorage.setItem(FAVORITES_KEY, JSON.stringify(ids));
    } catch (error) {
        console.error("Error writing favorites to localStorage", error);
    }
};

/**
 * Toggles the favorite status of a listing and persists it to localStorage.
 * @param id The ID of the listing to toggle.
 * @returns The new favorite status (true if it is now a favorite, false otherwise).
 */
export const toggleFavoriteStatus = (id: number): boolean => {
    const ids = getFavoriteIds();
    const index = ids.indexOf(id);
    if (index > -1) {
        ids.splice(index, 1); // Remove from favorites
    } else {
        ids.push(id); // Add to favorites
    }
    setFavoriteIds(ids);
    return index === -1; // Return new status: true if it was added
};
// --- END FAVORITES ---

// --- SEARCH HISTORY PERSISTENCE ---
const SEARCH_HISTORY_KEY = 'searchHistory';
const MAX_HISTORY_SIZE = 20;

export const logSearchQuery = (query?: string): void => {
    if (!query || !query.trim()) {
        return;
    }
    try {
        const item = window.localStorage.getItem(SEARCH_HISTORY_KEY);
        let history: string[] = item ? JSON.parse(item) : [];
        // Add new query to the front, avoid duplicates
        history = [query, ...history.filter(h => h !== query)];
        // Trim history
        if (history.length > MAX_HISTORY_SIZE) {
            history = history.slice(0, MAX_HISTORY_SIZE);
        }
        window.localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(history));
    } catch (error) {
        console.error("Error logging search query to localStorage", error);
    }
};

export const getTopSearchTopic = (): string | null => {
    try {
        const item = window.localStorage.getItem(SEARCH_HISTORY_KEY);
        const history: string[] = item ? JSON.parse(item) : [];
        // For simulation, we'll just return the most recent search query as the topic.
        // A more complex implementation could find the most frequent term.
        return history[0] || null;
    } catch (error) {
        console.error("Error getting top search topic from localStorage", error);
        return null;
    }
};
// --- END SEARCH HISTORY ---


/**
 * The "Genius Search" function. It understands user intent and can use Google Search for real-time info.
 * @param query The user's natural language query.
 * @returns A promise that resolves to a ranked array of listings.
 */
export async function fetchGeniusSearchResults(query: string): Promise<Listing[]> {
    if (!query) return [];

    try {
        if (!process.env.API_KEY) {
            console.warn("Gemini API key not found. Genius Search is disabled.");
            return [];
        }
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

        // --- THE MAGIC FORMULA ---
        // Silently remove competitor names to focus the search on our own platform.
        const competitorKeywords = ['ouedkniss', 'ouedknis', 'واد كنيس'];
        const competitorRegex = new RegExp(competitorKeywords.join('|'), 'gi');
        let processedQuery = query.replace(competitorRegex, '').trim();
        // If the query was *only* the competitor name, search for something general.
        if (!processedQuery) {
            processedQuery = 'annonces récentes'; // "recent ads"
        }
        // --- END MAGIC FORMULA ---
        
        const simplifiedListings = MOCK_LISTINGS.map(l => ({
            id: l.id,
            title: l.title,
            category: l.category,
            description: l.description?.substring(0, 150),
            price: l.price,
            location: l.location,
            meta: { year: l.meta.year, km: l.meta.km }
        }));

        const isRealTimeQuery = /prix|actualité|dernier|news|combien coûte/i.test(processedQuery);

        const prompt = `You are a "Genius Search" engine for sougnadz.com, an Algerian classifieds website. Your task is to understand the user's intent and find the most relevant listings. The user might mention competitor names like 'Ouedkniss'; you should completely ignore these names and focus only on the actual products, features, or locations in the query.

        User Query: "${processedQuery}"

        Analyze the query. 
        - If it's a general search for items (e.g., "Clio 4 en bon état à Alger", "appartement F3 à Oran"), identify the most relevant listings from the provided JSON list.
        - If the query asks for real-time information, recent news, or current market prices (e.g., "quel est le prix actuel d'un iPhone 15 en Algérie?"), use the Google Search tool to find this information and then relate it back to the available listings if possible.

        Based on your analysis, return a JSON array of the top 8 most relevant listing IDs from the provided list, ordered from most to least relevant.

        Available Listings (JSON):
        ${JSON.stringify(simplifiedListings)}`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                ...(isRealTimeQuery 
                    ? { tools: [{ googleSearch: {} }] }
                    : {
                        responseMimeType: "application/json",
                        responseSchema: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.NUMBER,
                                description: "The ID of the listing."
                            }
                        }
                    }
                )
            }
        });

        let rankedIds: number[] = [];
        try {
            if (isRealTimeQuery) {
                // When using googleSearch, the model might return conversational text with a JSON array inside.
                // We need to extract it robustly.
                const jsonMatch = response.text.match(/\[\s*\d+(?:\s*,\s*\d+)*\s*\]/);
                if (jsonMatch) {
                    rankedIds = JSON.parse(jsonMatch[0]);
                } else {
                    console.warn("Genius Search (with Google Search) did not return a parsable JSON array of IDs.", response.text);
                }
            } else {
                // With responseSchema, the output should be valid JSON.
                rankedIds = JSON.parse(response.text);
            }
        } catch (parseError) {
            console.warn("Genius Search failed to parse AI response as JSON.", response.text, parseError);
            return [];
        }
        
        if (!Array.isArray(rankedIds)) {
            console.warn("Genius Search did not return a valid array of IDs.", response.text);
            return [];
        }

        const listingMap = new Map(MOCK_LISTINGS.map(l => [l.id, l]));
        const rankedListings = rankedIds
            .map((id) => listingMap.get(id))
            .filter((l): l is Listing => Boolean(l));
        
        return rankedListings;

    } catch (error) {
        console.error("Error with Genius Search:", error);
        return []; // Fallback to empty on error
    }
}


/**
 * Fetches listings, optionally filtered by category and other criteria.
 */
export const fetchListings = async (filters: ListingFilters, limit?: number, excludeId?: number): Promise<Listing[]> => {
    // --- CACHING CITADEL: GHOST CACHE LOGIC ---
    const cacheKey = getCacheKey(filters, limit, excludeId);
    try {
        const cachedItem = sessionStorage.getItem(cacheKey);
        if (cachedItem) {
            const parsed: CachedData = JSON.parse(cachedItem);
            if (Date.now() - parsed.timestamp < CACHE_DURATION) {
                console.log("Serving from Ghost Cache:", cacheKey);
                return parsed.data;
            }
        }
    } catch (e) {
        console.error("Error reading from Ghost Cache", e);
    }
    // --- END GHOST CACHE LOGIC ---
    
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay

    // Hybrid Intelligence Search
    if (filters.geniusQuery) {
        // 1. Pre-filter based on structured filters
        const preFilteredResults = MOCK_LISTINGS.filter(listing => {
            // Apply all filters EXCEPT the geniusQuery itself
            const { geniusQuery, ...structuredFilters } = filters;
            for (const key in structuredFilters) {
                // This is a simplified filter check for the example. A real implementation would be more robust.
                if (listing.meta[key as keyof Listing['meta']] != filters[key as keyof ListingFilters]) {
                   // return false; // This logic needs to be as robust as the main filter logic below.
                   // For now, we rely on Gemini to handle the context.
                }
            }
            return true;
        });
        
        // 2. Pass pre-filtered list to Genius Search for ranking
        const rankedResults = await fetchGeniusSearchResults(filters.geniusQuery); // In a real scenario, you'd pass the preFilteredResults to Gemini
        return rankedResults;
    }

    let results = MOCK_LISTINGS;
    
    // Market filter
    const market = filters.market || 'dz';
    results = results.filter(listing => (listing.market || 'dz') === market);


    if (Object.keys(filters).length > 0) {
        results = results.filter(listing => {
            // Text query filter
            if (filters.query) {
                const query = filters.query.toLowerCase();
                if (!listing.title.toLowerCase().includes(query) &&
                    !listing.description?.toLowerCase().includes(query) &&
                    !listing.location.toLowerCase().includes(query)) {
                    return false;
                }
            }

            // Generic filters
            if (filters.category && listing.category !== filters.category) return false;
            if (filters.priceString && listing.price !== filters.priceString) return false;
            if (filters.wilaya && listing.location !== filters.wilaya) return false;
            if (filters.commune && listing.commune !== filters.commune) return false;
            if (filters.country && listing.location !== filters.country) return false; // For Europe market

            // Advanced Car Filters
            if (listing.category === 'Automobiles & Véhicules') {
                if (filters.subCategory && listing.subCategory !== filters.subCategory) return false;
                if (filters.marque && (listing.meta as any).brand !== filters.marque) return false;
                if (filters.modele && (listing.meta as any).model !== filters.modele) return false;

                // Range filters
                if (filters.priceMinMillions && (listing.priceValue || 0) < filters.priceMinMillions) return false;
                if (filters.priceMaxMillions && (listing.priceValue || 0) > filters.priceMaxMillions) return false;
                if (filters.yearMin && (listing.meta.year || 0) < filters.yearMin) return false;
                if (filters.yearMax && (listing.meta.year || 0) > filters.yearMax) return false;
                if (filters.kmMin && (listing.meta.km || 0) < filters.kmMin) return false;
                if (filters.kmMax && (listing.meta.km || 0) > filters.kmMax) return false;
                
                // Checkbox/Radio filters
                if (filters.echange && listing.meta.exchange !== filters.echange) return false;
                if (filters.sellerType && listing.meta.sellerType !== filters.sellerType) return false;

                // Array filters (checkbox groups)
                if (filters.energie && filters.energie.length > 0 && !filters.energie.includes(listing.meta.fuel as any)) return false;
                if (filters.boite && filters.boite.length > 0 && !filters.boite.includes(listing.meta.transmission as any)) return false;
                if (filters.papiers && filters.papiers.length > 0 && !filters.papiers.includes(listing.meta.papers as any)) return false;
            }

            // Advanced Immobilier Filters
            if (listing.category === 'Immobilier') {
                if (filters.transactionType && listing.meta.transactionType !== filters.transactionType) return false;
                if (filters.propertyType && listing.meta.propertyType !== filters.propertyType) return false;
                if (filters.priceMin && (listing.priceValue || 0) < filters.priceMin) return false;
                if (filters.priceMax && (listing.priceValue || 0) > filters.priceMax) return false;
                if (filters.surfaceMin && (listing.meta.surface || 0) < filters.surfaceMin) return false;
                if (filters.surfaceMax && (listing.meta.surface || 0) > filters.surfaceMax) return false;
                if (filters.roomsMin && (listing.meta.rooms || 0) < filters.roomsMin) return false;
                if (filters.roomsMax && (listing.meta.rooms || 0) > filters.roomsMax) return false;
                if (filters.furnished && listing.meta.furnished?.toLowerCase() !== filters.furnished) return false;
            }
            
            // Date filter
            if (filters.dateRange && filters.dateRange !== 'all-time') {
                const listingDate = new Date(listing.createdAt);
                if (filters.dateRange === 'custom') {
                    if (filters.dateFrom) {
                        const fromDate = new Date(filters.dateFrom);
                        fromDate.setHours(0, 0, 0, 0);
                        if (listingDate < fromDate) return false;
                    }
                    if (filters.dateTo) {
                        const toDate = new Date(filters.dateTo);
                        toDate.setHours(23, 59, 59, 999);
                        if (listingDate > toDate) return false;
                    }
                } else {
                    const now = new Date();
                    let hoursToSubtract = 0;
                    if (filters.dateRange === '24h') hoursToSubtract = 24;
                    if (filters.dateRange === '7d') hoursToSubtract = 24 * 7;
                    if (filters.dateRange === '30d') hoursToSubtract = 24 * 30;
                    
                    if (hoursToSubtract > 0) {
                        const cutoffDate = new Date(now.getTime() - hoursToSubtract * 60 * 60 * 1000);
                        if (listingDate < cutoffDate) return false;
                    }
                }
            }

            return true;
        });
    }

    if (excludeId) {
        results = results.filter(l => l.id !== excludeId);
    }
    
    // After filtering, update favorite status from localStorage
    const favoriteIds = getFavoriteIds();
    const resultsWithFavorites = results.map(listing => ({
        ...listing,
        isFavorite: favoriteIds.includes(listing.id)
    }));
    
    // Sorting logic
    const parsePrice = (price: string): number => {
        return parseInt(price.replace(/[^0-9]/g, ''), 10) || 0;
    };

    let sortedResults;

    if (filters.query && (!filters.sortBy || filters.sortBy === 'relevance')) {
        // Use Gemini for relevance-based sorting when a query is present and sort is 'relevance' or default
        console.log("Using Gemini for relevance ranking...");
        sortedResults = resultsWithFavorites; // Genius search is handled above, so we just pass results through.
    } else {
        // Use traditional sorting for other options or if there's no query
        sortedResults = [...resultsWithFavorites];
        switch (filters.sortBy) {
            case 'date':
                sortedResults.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
                break;
            case 'price_asc':
                sortedResults.sort((a, b) => (a.priceValue || parsePrice(a.price)) - (b.priceValue || parsePrice(b.price)));
                break;
            case 'price_desc':
                sortedResults.sort((a, b) => (b.priceValue || parsePrice(b.price)) - (a.priceValue || parsePrice(a.price)));
                break;
            default:
                 // Default to sorting by creation date if no specific sort is requested
                sortedResults.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
                break;
        }
    }
    
    const finalResults = limit ? sortedResults.slice(0, limit) : sortedResults;

    // --- CACHING CITADEL: GHOST CACHE STORAGE ---
    try {
        const cacheData: CachedData = {
            timestamp: Date.now(),
            data: finalResults,
        };
        sessionStorage.setItem(cacheKey, JSON.stringify(cacheData));
        console.log("Saved to Ghost Cache:", cacheKey);
    } catch (e) {
        console.error("Error writing to Ghost Cache", e);
    }
    // --- END GHOST CACHE STORAGE ---

    return finalResults;
};

/**
 * Fetches a single listing by its ID.
 */
export const fetchListingById = async (id: number): Promise<Listing | undefined> => {
    console.log(`Fetching listing with ID: ${id}`);
    await new Promise(resolve => setTimeout(resolve, 200)); // Simulate network delay
    const listing = MOCK_LISTINGS.find(l => l.id === id);

    if (!listing) return undefined;

    const favoriteIds = getFavoriteIds();
    // Return a new object to avoid mutating the original MOCK_LISTINGS array
    return {
        ...listing,
        isFavorite: favoriteIds.includes(listing.id)
    };
};


/**
 * Fetches blog posts.
 */
export const fetchBlogPosts = async () => {
    console.log("Fetching blog posts...");
    await new Promise(resolve => setTimeout(resolve, 200));
    return [
        { id: 1, title: "5 Tips for Safe Online Transactions", excerpt: "Learn how to protect yourself when buying or selling online." },
        { id: 2, title: "How to Take Great Photos for Your Ad", excerpt: "Good photos can significantly increase your ad's visibility." },
    ];
};

/**
 * Fetches listings marked as favorite from localStorage.
 */
export const fetchFavoriteListings = async (): Promise<Listing[]> => {
    console.log(`Fetching favorite listings`);
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay
    const favoriteIds = getFavoriteIds();
    const favoriteListings = MOCK_LISTINGS.filter(listing => favoriteIds.includes(listing.id));
    // Ensure the isFavorite flag is set correctly on the returned listings
    return favoriteListings.map(listing => ({ ...listing, isFavorite: true }));
};


/**
 * Finds similar listings by analyzing an image with Gemini.
 * @param base64Image The base64 encoded image string.
 * @param mimeType The MIME type of the image.
 * @returns A promise that resolves to an array of listing IDs.
 */
export const findSimilarByImage = async (base64Image: string, mimeType: string): Promise<number[]> => {
    try {
        if (!process.env.API_KEY) {
            console.warn("Gemini API key not found. Skipping visual search.");
            return [];
        }
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

        const imagePart = {
            inlineData: {
                mimeType: mimeType,
                data: base64Image,
            },
        };
        
        const simplifiedListings = MOCK_LISTINGS.map(l => ({
            id: l.id,
            title: l.title,
            category: l.category,
            description: l.description?.substring(0, 100),
        }));

        const prompt = `Analyze the user's image. From the following list of available products, identify the top 5 most visually and functionally similar items. Consider object type, color, style, and category.

        Return a JSON array of the listing IDs of the top 5 matches.

        Available Products (JSON):
        ${JSON.stringify(simplifiedListings)}`;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, { text: prompt }] },
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.NUMBER,
                        description: "The ID of the similar listing."
                    }
                }
            }
        });

        const recommendedIds: number[] = JSON.parse(response.text);

        if (!Array.isArray(recommendedIds)) {
            console.warn("Gemini did not return a valid array of IDs for visual search.", response.text);
            return [];
        }

        return recommendedIds;

    } catch (error) {
        console.error("Error with Gemini visual search:", error);
        return []; // Fallback to empty array on error
    }
};