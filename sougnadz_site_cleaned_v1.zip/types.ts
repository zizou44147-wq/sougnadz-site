/*
  This file appears to be part of an unintegrated chat feature and conflicts with 'services/types.ts'.
  The content has been commented out to prevent potential build issues and confusion.
*/

/*
export enum Sender {
  USER = 'user',
  AI = 'ai',
}

export interface Message {
  id: string;
  text: string;
  sender: Sender;
}
*/
