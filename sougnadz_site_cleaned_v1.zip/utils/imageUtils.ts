export const imageUrlToBase64 = async (url: string): Promise<{ base64: string; mimeType: string }> => {
    // The proxy was causing 403 Forbidden errors. Removing it for a direct fetch.
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Failed to fetch image: ${response.statusText}`);
    }
    const blob = await response.blob();
    const mimeType = blob.type;

    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            // result is the full data URI, e.g., "data:image/jpeg;base64,..."
            // We need to extract just the base64 part for the API
            const base64 = (reader.result as string).split(',')[1];
            if (base64) {
                 resolve({ base64, mimeType });
            } else {
                reject(new Error("Failed to read base64 from image."));
            }
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};


/**
 * Applies a text watermark styled like the logo to an image.
 * @param imageUrl The URL of the image to watermark.
 * @returns A promise that resolves to a base64 data URL of the watermarked image.
 */
export const applyWatermark = (imageUrl: string): Promise<string> => {
    return new Promise((resolve, reject) => {
        const img = new Image();
        // Allow cross-origin images to be loaded onto the canvas
        img.crossOrigin = "Anonymous";
        img.src = imageUrl;

        img.onload = () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                return reject(new Error('Could not get canvas context'));
            }

            canvas.width = img.width;
            canvas.height = img.height;

            // Draw the original image
            ctx.drawImage(img, 0, 0);

            // --- Watermark Logic ---
            const diagonal = Math.sqrt(canvas.width * canvas.width + canvas.height * canvas.height);
            // Reduced size significantly as requested (original was / 13)
            const fontSize = diagonal / 26;

            ctx.save();
            
            // Center and rotate
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate(-Math.PI / 12);
            
            // Base styles
            ctx.font = `900 ${fontSize}px Nunito, Arial`;
            ctx.textBaseline = "middle";
            ctx.textAlign = "left"; // Set alignment for sequential drawing
            ctx.globalAlpha = 0.65; // Make it semi-transparent
            
            // Subtle shadow for depth
            ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
            ctx.shadowBlur = 10;
            ctx.shadowOffsetX = fontSize / 15;
            ctx.shadowOffsetY = fontSize / 15;

            // Text parts
            const sougnaText = 'sougna';
            const dzText = 'dz';
            const comText = '.com';
            
            // Measure text parts to calculate total width for centering
            const sougnaWidth = ctx.measureText(sougnaText).width;
            const dzWidth = ctx.measureText(dzText).width;
            const comWidth = ctx.measureText(comText).width;
            const totalWidth = sougnaWidth + dzWidth + comWidth;

            let currentX = -totalWidth / 2;
            const y = 0;

            const drawPart = (text: string, x: number, fill: string, stroke: string, strokeWidth: number) => {
                ctx.lineWidth = strokeWidth;
                ctx.strokeStyle = stroke;
                ctx.fillStyle = fill;
                // Draw stroke first, then fill on top
                ctx.strokeText(text, x, y);
                ctx.fillText(text, x, y);
            };
            
            // Draw "sougna"
            drawPart(sougnaText, currentX, '#0d244f', '#f97316', fontSize / 20);
            currentX += sougnaWidth;
            
            // Draw "dz"
            drawPart(dzText, currentX, '#f97316', 'rgba(255, 255, 255, 0.9)', fontSize / 20);
            currentX += dzWidth;
            
            // Draw ".com"
            drawPart(comText, currentX, '#e5e7eb', 'rgba(0, 0, 0, 0.8)', fontSize / 22);
            
            ctx.restore(); // Restore the original state

            resolve(canvas.toDataURL('image/jpeg', 0.9));
        };

        img.onerror = (error) => {
            console.error("Failed to load image for watermarking:", error);
            // Fallback to the original image URL if watermarking fails
            resolve(imageUrl);
        };
    });
};

/**
 * Converts a File object to a base64 encoded string, without the data URI prefix.
 * @param file The file to convert.
 * @returns A promise that resolves to the base64 string.
 */
export const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const base64 = (reader.result as string).split(',')[1];
            if (base64) {
                resolve(base64);
            } else {
                reject(new Error("Failed to convert file to base64."));
            }
        };
        reader.onerror = error => reject(error);
    });
};