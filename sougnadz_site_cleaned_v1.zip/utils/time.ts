import { Language } from '../services/types';
import { TranslationKey } from '../hooks/useLocalization';

type TFunction = (key: TranslationKey, replacements?: string | { [key: string]: string | number }) => string;

export const formatTimeAgo = (dateString: string, t: TFunction, lang: Language): string => {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (seconds < 60) {
        return t('justNow');
    }

    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) {
        return t('minutesAgo', { count: minutes });
    }

    const hours = Math.floor(minutes / 60);
    if (hours < 24) {
        return t('hoursAgo', { count: hours });
    }

    const days = Math.floor(hours / 24);
    if (days === 1) {
        return t('yesterday');
    }
    
    if (days < 7) {
        return t('daysAgo', { count: days });
    }

    // For older dates, return the date format with the full month name.
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    const localeMap = {
        fr: 'fr-FR',
        ar: 'ar-DZ',
        en: 'en-GB'
    };
    return date.toLocaleDateString(localeMap[lang] || 'fr-FR', options);
};
